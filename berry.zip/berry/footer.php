<section id="contacts">
	</section>

	<footer>

		<div class="container">

			<div class="row" data-appear-top-offset="-200" data-animated="fadeInUp">
				
				<div class="col-lg-4 col-md-4 col-sm-6 padbot30">

		        
<h4><?php _e('Recently', 'Detox'); ?></h4>
<div class="cat">
<ul><?php wp_get_archives('type=postbypost&limit=4'); ?></ul>
</div>


				</div>
				
				<div class="col-lg-4 col-md-4 col-sm-6 padbot30 foot_about_block">
         <?php $aOptions = berry::initOptions(false); ?>
					<h4><?php echo($aOptions['featured4-title']); ?></h4>
					<p><?php echo($aOptions['featured4-text']); ?></p>
					<ul class="social">
						<li><a href="javascript:void(0);" ><i class="fa fa-twitter"></i></a></li>
						<li><a href="javascript:void(0);" ><i class="fa fa-facebook"></i></a></li>
						<li><a href="javascript:void(0);" ><i class="fa fa-google-plus"></i></a></li>
						<li><a href="javascript:void(0);" ><i class="fa fa-pinterest-square"></i></a></li>
						<li><a href="javascript:void(0);" ><i class="fa fa-map-marker"></i></a></li>
					</ul>
				</div>
				
				<div class="respond_clear"></div>
				
				<div class="col-lg-4 col-md-4 padbot30">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column2') ) : ?>

<h4><?php _e('Inside', 'Detox'); ?></h4>
<div class="cat">
<ul><?php wp_list_pages('title_li=&depth=0&number=4'); ?></ul>
</div>
<div class="sez"></div>

<?php endif; ?>
				</div>
        
        <div class="c"><?php _e('Copyright', 'Detox'); ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> | <a class="no-link" href="https://3oneseven.com/">Website design by milo</a>
      <br /><div id="gnavigation" style="font-size:10px"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/berry-ecommerce-theme/" >Theme</a> <span>Berry theme</span>
</span>
</span>
</span>
</div>
        </div>
			</div>
		</div>
	</footer>
	
</div>


<script type="text/javascript">
var scrolltotop={
	setting: {startline:100, scrollto: 0, scrollduration:1000, fadeduration:[500, 100]},
	controlHTML: '<div class="fa sfa-search fa-lg" style="font-size:19px;">&uarr;</div>', 
	controlattrs: {offsetx:5, offsety:40}, 
	anchorkeyword: '#top', 
	state: {isvisible:false, shouldvisible:false},
	scrollup:function(){
		if (!this.cssfixedsupport) 
			this.$control.css({opacity:0}) 
		var dest=isNaN(this.setting.scrollto)? this.setting.scrollto : parseInt(this.setting.scrollto)
		if (typeof dest=="string" && jQuery('#'+dest).length==1) 
			dest=jQuery('#'+dest).offset().top
		else
			dest=0
		this.$body.animate({scrollTop: dest}, this.setting.scrollduration);
	},
	keepfixed:function(){
		var $window=jQuery(window)
		var controlx=$window.scrollLeft() + $window.width() - this.$control.width() - this.controlattrs.offsetx
		var controly=$window.scrollTop() + $window.height() - this.$control.height() - this.controlattrs.offsety
		this.$control.css({left:controlx+'px', top:controly+'px'})
	},
	togglecontrol:function(){
		var scrolltop=jQuery(window).scrollTop()
		if (!this.cssfixedsupport)
			this.keepfixed()
		this.state.shouldvisible=(scrolltop>=this.setting.startline)? true : false
		if (this.state.shouldvisible && !this.state.isvisible){
			this.$control.stop().animate({opacity:1}, this.setting.fadeduration[0])
			this.state.isvisible=true
		}
		else if (this.state.shouldvisible==false && this.state.isvisible){
			this.$control.stop().animate({opacity:0}, this.setting.fadeduration[1])
			this.state.isvisible=false
		}
	},	
	init:function(){
		jQuery(document).ready(function($){
			var mainobj=scrolltotop
			var iebrws=document.all
			mainobj.cssfixedsupport=!iebrws || iebrws && document.compatMode=="CSS1Compat" && window.XMLHttpRequest 
			mainobj.$body=(window.opera)? (document.compatMode=="CSS1Compat"? $('html') : $('body')) : $('html,body')
			mainobj.$control=$('<div id="topcontrol">'+mainobj.controlHTML+'</div>')
				.css({position:mainobj.cssfixedsupport? 'fixed' : 'absolute', bottom:mainobj.controlattrs.offsety, right:mainobj.controlattrs.offsetx, opacity:0, cursor:'pointer'})
				.attr({title:'back to top'})
				.click(function(){mainobj.scrollup(); return false})
				.appendTo('body')
			if (document.all && !window.XMLHttpRequest && mainobj.$control.text()!='') 
				mainobj.$control.css({width:mainobj.$control.width()}) 
			mainobj.togglecontrol()
			$('a[href="' + mainobj.anchorkeyword +'"]').click(function(){
				mainobj.scrollup()
				return false
			})
			$(window).bind('scroll resize', function(e){
				mainobj.togglecontrol()
			})
		})
	}
}
scrolltotop.init()
</script>
<script src="<?php echo get_template_directory_uri(); ?>/js/instant.js" type="text/javascript"></script>


</body>
</html>