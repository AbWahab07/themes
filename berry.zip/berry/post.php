		<section id="projects" class="padbot20">
		
			<!-- CONTAINER -->
			<div class="container">
				<h2><b>Featured</b> Articles</h2>
			</div><!-- //CONTAINER -->
			
				
			<div class="projects-wrapper" data-appear-top-offset="-200" data-animated="fadeInUp">
				<!-- PROJECTS SLIDER -->
				<div class="owl-demo owl-carousel projects_slider">
					
<?php 
	$my_query = new WP_Query('showposts=8&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
					<div class="item">
						<div class="work_item">
							<div class="work_img">
								<img src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" />
								<a class="zoom" href="<?php the_permalink() ?>" rel="prettyPhoto[portfolio1]" ></a>
							</div>
							<div class="work_description">
								<div class="work_descr_cont">
									<a href="<?php the_permalink() ?>" ><?php the_title(); ?></a>
								
								</div>
							</div>
						</div>
					</div>
<?php endwhile; ?> 

				</div>
			</div>
			
			

			<div class="our_clients">
			
	
				<div class="container" data-appear-top-offset="-200" data-animated="fadeInUp">
					
		
					<div class="row">
          <?php $aOptions = berry::initOptions(false); ?>  
						<div class="col-lg-2 col-md-2 col-sm-2 client_img">
						<a href="<?php echo($aOptions['featured12-link']); ?>"><img src="<?php echo($aOptions['featured12-image']); ?>" alt="media partners" /></a>
						</div>
						<div class="col-lg-2 col-md-2 col-sm-2 client_img">
						<a href="<?php echo($aOptions['featured13-link']); ?>"><img src="<?php echo($aOptions['featured13-image']); ?>" alt="media partners" /></a>
						</div>
						<div class="col-lg-2 col-md-2 col-sm-2 client_img">
							<a href="<?php echo($aOptions['featured14-link']); ?>"><img src="<?php echo($aOptions['featured14-image']); ?>" alt="media partners" /></a>
						</div>
						<div class="col-lg-2 col-md-2 col-sm-2 client_img">
						<a href="<?php echo($aOptions['featured15-link']); ?>"><img src="<?php echo($aOptions['featured15-image']); ?>" alt="media partners" /></a>
						</div>
						<div class="col-lg-2 col-md-2 col-sm-2 client_img">
							<a href="<?php echo($aOptions['featured16-link']); ?>"><img src="<?php echo($aOptions['featured16-image']); ?>" alt="media partners" /></a>
						</div>
						<div class="col-lg-2 col-md-2 col-sm-2 client_img">
						<a href="<?php echo($aOptions['featured17-link']); ?>"><img src="<?php echo($aOptions['featured17-image']); ?>" alt="media partners" /></a>
						</div>
					</div>
				</div>
			</div>
		</section>