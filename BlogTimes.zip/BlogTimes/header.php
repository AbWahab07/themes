<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="shortcut icon" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" />
<?php if(is_front_page()): ?><?php elseif (is_singular()): ?>
<link rel="prefetch" href="<?php echo get_permalink(get_adjacent_post(false,'',true)); ?>">
<link rel="prerender" href="<?php echo get_permalink(get_adjacent_post(false,'',false)); ?>">
<?php else: ?>
<link rel="prefetch" href="<?php echo home_url(); ?>">
<link rel="prerender" href="<?php echo home_url(); ?>">
<?php endif; ?>
<link rel="author" type="text/plain" href="https://wp.3oneseven.com/humans.txt" />

<script src="<?php echo get_template_directory_uri(); ?>/js/contentslider.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/misc.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/modernizr.custom.js"></script>

<?php wp_head(); ?>

</head>

<body <?php body_class(); ?> id="blogtimes_theme_by_milo317">
<progress value="0" id="progressBar"><div class="progress-container"><span class="progress-bar"></span></div></progress>

<div id="navi" class="animated fadeInDown">
<div id="menu">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'top-nav',
'container' => '',
'container_id' => 'top-nav',
'menu_id' => 'nav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>
<div id="search">
<form id="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e('Search...', 'Detox'); ?>" name="s" id="s" onfocus="if (this.value == 'Search...', 'Detox') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search anything', 'Detox';}" /></form>
</div>

<div class="xtow2 animated slideInDown">
<div id="xnavbar" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
<button id="trigger-overlay" type="button"><span style="display:none"><?php _e('Menu', 'Detox') ?></span></button>
</div>
</div>

</div>
</div>

<div id="content">

<div id="header">	

<div class="head">
<div class="de">{ &#183;Established <?php echo strftime("%T"); ?>&#183; }</div>
<h1><a href="<?php home_url(); ?>/"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt"<?php bloginfo('name'); ?>" /></a></h1>
<div class="description"><?php bloginfo('description'); ?></div>
</div>

<div class="clock">
</div>

<div id="login">
<a id="open" class="open" href=""><?php _e('Log In', 'Detox') ?></a> | <a href=""><?php _e('Register', 'Detox') ?></a>

</div>

</div>

<div id="cat">
<ul id="pnav">
<li><a href=""><?php echo strftime("%a"); ?>,&nbsp;
<?php echo strftime("%b"); ?>&nbsp;
<?php echo strftime("%d"); ?>,&nbsp;<?php echo strftime("%y"); ?>&nbsp;&nbsp;<?php echo strftime("%T"); ?></a></li>
</ul>
<div class="cl">
<small>Price</small> &#8381;1/19/11&#190; | <small>Vol. N<sup>o</sup>.</small> <span><?php echo strftime("%d"); ?><?php echo strftime("%y"); ?></span>
</div>
</div>