<?php get_header(); ?>
<div id="front"><?php get_template_part('front', 'Detox') ?></div>
<?php get_template_part('slide', 'Detox') ?>
<?php get_template_part('middle', 'Detox') ?>
<div id="xfront"><?php get_template_part('front', 'Detox') ?></div>
<?php get_template_part('middle', 'Detox') ?>
<div id="xfront"><?php get_template_part('front', 'Detox') ?></div>
<?php get_template_part('middle', 'Detox') ?>
<?php get_template_part('footer', 'Detox') ?>