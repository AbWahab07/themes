<div id="xyz">
<div class="break">

<?php $my_query = new WP_Query('showposts=4&offset=12'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>

<div class="hc1">

<div class="inner">
<span class="macky"><?php the_category(', ') ?></span>

<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="hp">
<a class="thumb" href="<?php the_permalink() ?>"><img src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></a>
</div>

<div class="sentry"><?php the_excerpt(); ?></div>
<div class="more"><span class="bigdate">{</span> 
<a href="<?php the_permalink() ?>"><?php _e('View more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
</div>

</div>

<?php endwhile; ?>

</div>
</div>