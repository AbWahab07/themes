<?php
/*
Template Name: error
*/
?>
<?php get_header(); ?>

<div id="smain">
<div class="xwrap">

<h2>An error occured</h2>

<div class="entry">

<h3>Please fill in the required fields. <a href="javascript:history.back()">Back</a></h3>

<div class="clearfix"></div><hr class="clear" />

<div id="navigation">
<div class="alignleft">
<a href="/">Home</a> | <?php the_title(); ?>
</div>
<div class="alignright">
<a accesskey="s" title="Sitemap will help you find your interests at this site." href="/sitemap/">Sitemap</a>
</div>
</div>

</div>
</div>
<?php get_template_part('footer'); ?>