<div id="middle">
<div class="sl"></div>
<?php 
	$my_query = new WP_Query('showposts=1&offset=11');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="florida"><?php the_category(', ') ?></div>
<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>

<?php endwhile; ?>
</div>

<div id="lbar">

<div class="sl"></div>
<?php 
	$my_query = new WP_Query('showposts=1&offset=12');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_category(', ') ?></div>
<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>

<?php endwhile; ?>
</div>

<div id="lrbar">

<div class="sl"></div>
<?php 
	$my_query = new WP_Query('showposts=1&offset=13');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="orlando"><?php the_category(', ') ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>

<?php endwhile; ?>
</div>