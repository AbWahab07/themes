<?php get_header(); ?>

<div id="content">
<div id="middle">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="ctitle"><?php the_category(' <span>, </span> '); ?></div>
<div id="teaser">
<h1><?php the_title(); ?><?php edit_post_link(' | Edit','',' '); ?></h1>
</div>
<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="h-fs" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<span class="hdate"><?php the_time('M'); ?><span class="hbigdate"><?php the_time('j'); ?></span></span>
</div>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 	
<div class="entry">
<div class="sentry"><?php the_content(__('Read more', 'Detox'));?></div>
</div>
</div>

<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div class="navigation">&after=</div>'); ?>

<div class="clearfix"></div><hr class="clear" />

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>

<div id="navigation">
<p><?php _e('You are here', 'Detox') ?>: <a href="<?php home_url(); ?>/">Home</a> >> <?php the_category(' <span>>> </span> '); ?> >> <?php the_title(); ?></p>
</div>
            
<div class="ren"></div><div class="ren"></div>
<div class="hen"><h2>Related</h2></div>

<div id="tfeatured"> 	
<div id="slider2" class="sliderwrapper">

<?php
  $orig_post = $post;
  global $post;
  $tags = wp_get_post_tags($post->ID);   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>1, // Number of related posts to display.
  'caller_get_posts'=>1
  );   
  $my_query = new wp_query( $args ); 
  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>

<div class="contentdiv"> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="h-f" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>
<div class="cis">
<div class="h-t">
<div class="ctitle"><?php the_category(' <span>, </span> '); ?></div>
<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
<div itemprop="text"><?php the_excerpt(); ?></div>
</div>
<span class="hdate"><?php the_time('M'); ?><span class="hbigdate"><?php the_time('j'); ?></span></span>
<a href="<?php the_permalink() ?>"></a>

<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>
</div> 
                                
</div>
 <? }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>

</div>

<div class="postspace"></div>
<?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>	
            
</div>
</div>
</div>
<?php get_template_part('ny'); ?>
<?php get_template_part('bar'); ?>
</div>
</div>
<nav class="nav-slide">
<?php 
$prev_post = get_adjacent_post(false, '', true);
if(!empty($prev_post)) {
echo '<a class="prev" href="' . get_permalink($prev_post->ID) . '"><span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>' . $prev_post->post_title . ' <span> Previously</span></h3></div></a>'; }
 ?>
<?php
$next_post = get_adjacent_post(false, '', false);
if(!empty($next_post)) {
echo '<a class="next" href="' . get_permalink($next_post->ID) . '">	<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>' . $next_post->post_title . ' <span>Next</span></h3></div></a>'; }
?>
</nav>
<?php get_footer(); ?>