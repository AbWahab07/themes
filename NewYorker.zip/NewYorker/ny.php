<div class="ren"></div>  	
<div class="hen"><h2>The NewYorker</h2></div>

<div id="stfeatured"> 		

<div class="tl">
<h1>New Yorker Magazine Theme</h1>
<div class="ssread"><a class="a-btn" href="https://3oneseven.com/new-yorker-magazine-theme/">Download</a></div>
<div class="ssread"><a class="a-btn" href="https://wp.3oneseven.com/?wptheme=NewYorker">Demo</a></div>
</div>
<div class="tr"><a href="https://3oneseven.com/new-yorker-magazine-theme/"><img src="<?php echo get_template_directory_uri(); ?>/images/nyer-theme.png" alt="newyorker template" /></a></div>

</div>