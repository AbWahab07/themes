<?php get_header(); ?>
<div id="content">
<div id="middle">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="ctitle">Inside</div>
<div id="teaser">
<h1><?php the_title(); ?><?php edit_post_link(' | Edit','',' '); ?></h1>
</div>

	
<div class="entry">
<?php the_content(__('Read more', 'Detox'));?>
<div class="clearfix"></div>
</div>


<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>
<div class="clearfix"></div>
<div id="navigation">
<p><?php _e('You are here', 'Detox') ?>: <a href="<?php home_url(); ?>/">Home</a> >> <?php the_title(); ?></p>
</div>
<div class="sl"></div>
<div class="postspace"></div>
</div>
</div>

</div>
<?php get_footer(); ?>