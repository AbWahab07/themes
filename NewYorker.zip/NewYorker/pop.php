<div class="ren"></div><div class="ren"></div>
<div class="hen"><h2>Most Popular</h2></div>
<div class="ren"></div>
<div id="steaser">
<div class="wrap animated fadeInLeftBig">

<div class="rap animated fadeInLeftBig">
<?php 
	$my_query = new WP_Query('showposts=1&offset=0&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?> 	
<span>1.</span><h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h2>
<?php endwhile; ?>
</div>
<div class="rap animated fadeInLeftBig">
<?php 
	$my_query = new WP_Query('showposts=1&offset=1&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?> 	
<span>2.</span><h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h2>
<?php endwhile; ?>
</div>

<div class="rap animated fadeInLeftBig">
<?php 
	$my_query = new WP_Query('showposts=1&offset=2&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?> 	
<span>3.</span><h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h2>
<?php endwhile; ?>
</div>

<div class="rap animated fadeInLeftBig">
<?php 
	$my_query = new WP_Query('showposts=1&offset=3&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?> 	
<span>4.</span><h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h2>
<?php endwhile; ?>
</div>

<div class="rap animated fadeInLeftBig">
<?php 
	$my_query = new WP_Query('showposts=1&offset=4&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?> 	
<span>5.</span><h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h2>
<?php endwhile; ?>
</div>

</div>
</div>