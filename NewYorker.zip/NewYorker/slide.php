<div id="mow">
<div class="hen"><h2>Latest</h2></div>
<div class="ren"></div>
<ul class="ca-menu">

                    <?php 
	$slidecat = get_option('NewYorker_slicer_category'); 
	$my_query = new WP_Query('showposts=1&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
                    <li class="one" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
                        <a href="<?php the_permalink() ?>">
                           
                            <div class="ca-content">
                                <h2 class="ca-main"><?php the_title() ?></h2>
                                <h3 class="ca-sub"><?php the_title() ?></h3>
                            </div>
                             <span class="ca-icon"><?php
  $posttags = get_the_tags();
  if ($posttags) {
    foreach($posttags as $tag) {
      echo $tag->name . ' '; 
    }
  }
?></span>
<div class="crong"></div>
                        </a>
                    </li>
                    <?php endwhile; ?>
                    
                    <?php 
	$slidecat = get_option('NewYorker_slicer_category'); 
	$my_query = new WP_Query('showposts=1&offset=1');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
                    <li class="two" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
                        <a href="<?php the_permalink() ?>">
                            
                            <div class="ca-content">
                                <h2 class="ca-main"><?php the_title() ?></h2>
                                <h3 class="ca-sub"><?php the_title() ?></h3>
                            </div>
                            <span class="ca-icon"><?php
  $posttags = get_the_tags();
  if ($posttags) {
    foreach($posttags as $tag) {
      echo $tag->name . ' '; 
    }
  }
?></span><div class="crong"></div>
                        </a>
                    </li>
                    <?php endwhile; ?>
                    
                    <?php 
	$slidecat = get_option('NewYorker_slicer_category'); 
	$my_query = new WP_Query('showposts=1&offset=2');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
                    <li class="three" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
                        <a href="<?php the_permalink() ?>">
                            
                            <div class="ca-content">
                                <h2 class="ca-main"><?php the_title() ?></h2>
                                <h3 class="ca-sub"><?php the_title() ?></h3>
                            </div>
                            <span class="ca-icon"><?php
  $posttags = get_the_tags();
  if ($posttags) {
    foreach($posttags as $tag) {
      echo $tag->name . ' '; 
    }
  }
?></span><div class="crong"></div>
                        </a>
                    </li>
                    <?php endwhile; ?>
                    
                    <?php 
	$slidecat = get_option('NewYorker_slicer_category'); 
	$my_query = new WP_Query('showposts=1&offset=3');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
                    <li class="four" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
                        <a href="<?php the_permalink() ?>">
                            
                            <div class="ca-content">
                                <h2 class="ca-main"><?php the_title() ?></h2>
                                <h3 class="ca-sub"><?php the_title() ?></h3>
                            </div>
                            <span class="ca-icon"><?php
  $posttags = get_the_tags();
  if ($posttags) {
    foreach($posttags as $tag) {
      echo $tag->name . ' '; 
    }
  }
?></span><div class="crong"></div>
                        </a>
                    </li>
                    <?php endwhile; ?>
                    
</ul>

</div>