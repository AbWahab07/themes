<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="https://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" title="default" media="screen" />

<link rel="shortcut icon" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico" />

<?php if(is_front_page()): ?><?php elseif (is_singular()): ?>
<link rel="prefetch" href="<?php echo get_permalink(get_adjacent_post(false,'',true)); ?>">
<link rel="prerender" href="<?php echo get_permalink(get_adjacent_post(false,'',false)); ?>">
<?php else: ?>
<link rel="prefetch" href="<?php echo home_url(); ?>">
<link rel="prerender" href="<?php echo home_url(); ?>">
<?php endif; ?>



<?php wp_head(); ?>        

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/modernizr.custom.js"></script>
</head>

<body <?php body_class() ?> id="newyorker_theme_by_milo317">
<progress value="0" id="progressBar"><div class="progress-container"><span class="progress-bar"></span></div></progress>


<div id="navi">
<div class="wrap animated fadeInLeftBig">

<div class="xtow2">
<div id="xnavbar" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<button id="trigger-overlay" type="button"><span style="display:none"><?php _e('Menu', 'Detox') ?></span></button>
</div>
</div>

<div id="pnavi">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'topnav',
'container' => '',
'container_id' => 'top',
'menu_id' => 'pnav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>
</div>
<form id="searchform" method="get" action="<?php echo home_url(); ?>/">
<input type="text" value="<?php _e( 'Search...', 'Detox') ?>" name="s" id="s" onfocus="if (this.value == '<?php _e( 'Search...', 'Detox') ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e( 'Search anything', 'Detox') ?>';}" />
</form>

</div>
</div>

<div class="wrap animated fadeInLeftBig">
<div id="header">
<div id="head">
<h1><a title="<?php _e( 'Get back to the frontpage', 'Detox') ?>" href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1>
</div>

<div id="des">
<div class="int">
<div class="nt">{</div>
<p><?php bloginfo('description'); ?></p>
<div class="nt2">}</div>
</div>
</div>

<div id="tags">
<div class="int">
<div class="nt">{</div>
<p>
<?php echo strftime("%A"); ?>,&nbsp;
<?php echo strftime("%B"); ?>&nbsp;
<?php echo strftime("%d"); ?>,
<?php echo strftime("%Y"); ?><br />
<?php echo strftime("%T"); ?>
</p>
<div class="nt2">}</div>
</div>
</div>
</div>