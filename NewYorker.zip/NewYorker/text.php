<div class="ren"></div><div class="ren"></div>
<div class="hen"><h2>Most Shared</h2></div>


<?php 
	$my_query = new WP_Query('showposts=1&offset=4&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div id="teaser">
<div class="wrap animated fadeInLeftBig">
 	
<div class="entry">
<div class="msentry"><b><?php the_category(' <span>, </span> '); ?></b>  <?php the_content_rss('', FALSE, ' ', 22); ?></div>
</div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h2>

<div class="entry">
<div class="sentry"><p><?php the_content_rss('', FALSE, ' ', 72); ?></p></div>
</div>
</div>
</div>
<?php endwhile; ?>
