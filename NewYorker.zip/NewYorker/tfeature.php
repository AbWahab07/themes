<div class="ren"></div>  	
<div class="hen"><h2>Video</h2></div>

<div id="tfeatured"> 		
<div id="slider2" class="sliderwrapper">

<?php 
	$my_query = new WP_Query('showposts=1&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
                
<div class="contentdiv"> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="h-f" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>
<div class="cis">
<div class="h-t">
<div class="ctitle"><?php the_category(' <span>, </span> '); ?></div>
<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
<div itemprop="text"><?php the_excerpt(); ?></div>
</div>
<a href="<?php the_permalink() ?>"></a>

<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>
</div>
<span class="hdate"><?php the_time('M'); ?><span class="hbigdate"><?php the_time('j'); ?></span></span>
 
</div> 
               
<?php endwhile; ?>                           
                
<div id="paginate-slider2" class="pagination"></div>

</div>

</div>