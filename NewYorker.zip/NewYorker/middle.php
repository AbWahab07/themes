<div id="middle">

<div class="sl"></div>
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('right-column') ) : ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=4&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="florida"><?php the_category(', ') ?></div>
<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>
<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>

<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>

<?php endwhile; ?>


<?php endif; ?>

</div>

<div id="lbar">

<div class="sl"></div>
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('left-column') ) : ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=5&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_category(', ') ?></div>
<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>
<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>

<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>

<?php endwhile; ?>


<?php endif; ?>

</div>

<div id="lrbar">

<div class="sl"></div>
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('center-column') ) : ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=6&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="orlando"><?php the_category(', ') ?></div>
<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>
<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>

<div class="hc">{ <em><?php _e('on', 'Detox') ?> <?php the_time('M'); ?><?php the_time('j'); ?> <?php the_time('Y'); ?> | <?php _e('in', 'Detox') ?>: <?php the_category(' | ') ?></em> }</div>

<?php endwhile; ?>


<?php endif; ?>

</div>