<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>  
	<section class="breadcrumbs_block clearfix parallax" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
			<div class="container center">
				<h2><?php the_category(' <span> | </span> '); ?></h2>
			</div>
		</section>
		

		<!-- BLOG -->
		<section id="blog">
			
			<!-- CONTAINER -->
			<div class="container">
				
				<!-- ROW -->
				<div class="row">
				
					<!-- BLOG BLOCK -->
					<div class="blog_block col-lg-9 col-md-9 padbot50">
						
						<!-- SINGLE BLOG POST -->
						<div class="single_blog_post clearfix" data-animated="fadeInUp">
							<div class="single_blog_post_descr">
								<div class="single_blog_post_date"><?php the_time('M'); ?> <?php the_time('j'); ?></div>
								<div class="single_blog_post_title"><?php the_title() ?><?php edit_post_link(' <b>Edit</b>','',''); ?></div>
								<ul class="single_blog_post_info">
									<li><?php the_author_posts_link(); ?></li>
									<li><?php the_category(' <span> | </span> '); ?></li>
									<li><?php comments_popup_link(__('No Comment', 'Detox'), __('1 Comment', 'Detox'), __('% Comments', 'Detox'), '', __('Closed', 'Detox')); ?></li>
								</ul>
							</div>
							
							<div class="single_blog_post_content">
<?php the_content(__('Read more', 'Detox'));?>
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
              	</div>
							
						</div><!-- //SINGLE BLOG POST -->
						
						
						<!-- SINGLE BLOG POST TAG -->
						<div class="single_blog_post_tags margbot50" data-animated="fadeInUp">
							<ul>
						<li><?php the_category(' <span> | </span> '); ?></li>
							</ul>
              
              <div class="sidepanel widget_info">							
<ul class="shared pull-right">
								<li><a href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink(); ?>" ><i class="fa fa-twitter"></i></a></li>
								<li><a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" ><i class="fa fa-facebook"></i></a></li>
								<li><a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>" ><i class="fa fa-pinterest-square"></i></a></li>
</ul>
</div><!-- //INFO WIDGET -->

<div class="sowl-demo sowl-carousel sowl-theme">              
<div class="sowl-controls clickable container sowl-theme">
<div class="sowl-buttons">
<?php
                    $prev_post = get_adjacent_post(false, '', true);
                    $next_post = get_adjacent_post(false, '', false); ?>
<?php if ($prev_post) : $prev_post_url = get_permalink($prev_post->ID); $prev_post_title = $prev_post->post_title; ?>
<div class="sowl-prev"><a href="<?php echo $prev_post_url; ?>"><em>Previous post</em></a></div>
<?php endif; ?>
<?php if ($next_post) : $next_post_url = get_permalink($next_post->ID); $next_post_title = $next_post->post_title; ?>
<div class="sowl-next"><a href="<?php echo $next_post_url; ?>"><em>Next post</em></a></div>
   <?php endif; ?>
</div>
</div>
</div>

						</div><!-- //SINGLE BLOG POST TAG -->
						
						<hr>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>	

<?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>					

					</div><!-- //BLOG BLOCK -->

				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //BLOG -->
	</div><!-- //PAGE -->

<?php get_footer(); ?>