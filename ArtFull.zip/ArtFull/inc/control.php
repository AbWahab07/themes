<?php

function get_upload_field($id, $std = '', $desc = '') {

  $field = '<input id="' . $id . '" type="file" name="attachment_' . $id . '" />' .
           '<span class="submit"><input name="ArtFull_upload" type="submit" value="Upload" class="button panel-upload-save" />
		   </span> <span class="description"> '. __($desc,'detox') .' </span>';

  return $field;
}

load_theme_textdomain('ArtFull');
class ArtFull {
	function addOptions () {
	
		if (isset($_POST['ArtFull_reset'])) { ArtFull::initOptions(true); }
		if (isset($_POST['ArtFull_save'])) {

			$aOptions = ArtFull::initOptions(false);
		
		$aOptions['featured1-image'] = stripslashes($_POST['featured1-image']);
        
    $aOptions['featured2-image'] = stripslashes($_POST['featured2-image']);
    
    $aOptions['featured3-image'] = stripslashes($_POST['featured3-image']);
		
    $aOptions['featured4-image'] = stripslashes($_POST['featured4-image']);
    $aOptions['featured4-text'] = stripslashes($_POST['featured4-text']);
    $aOptions['featured4-title'] = stripslashes($_POST['featured4-title']);
    $aOptions['featured4-link'] = stripslashes($_POST['featured4-link']);
    
    $aOptions['featured5-image'] = stripslashes($_POST['featured5-image']);
    $aOptions['featured5a-image'] = stripslashes($_POST['featured5a-image']);
		$aOptions['featured5-title'] = stripslashes($_POST['featured5-title']);
		$aOptions['featured5-link'] = stripslashes($_POST['featured5-link']);
    
    $aOptions['featured6-image'] = stripslashes($_POST['featured6-image']);
    $aOptions['featured6a-image'] = stripslashes($_POST['featured6a-image']);
    $aOptions['featured6-title'] = stripslashes($_POST['featured6-title']);
    $aOptions['featured6-link'] = stripslashes($_POST['featured6-link']);
    
    $aOptions['featured7-image'] = stripslashes($_POST['featured7-image']);
    $aOptions['featured7a-image'] = stripslashes($_POST['featured7a-image']);
		$aOptions['featured7-title'] = stripslashes($_POST['featured7-title']);
		$aOptions['featured7-link'] = stripslashes($_POST['featured7-link']);
    
    $aOptions['featured8-image'] = stripslashes($_POST['featured8-image']);
		$aOptions['featured8a-image'] = stripslashes($_POST['featured8a-image']);
    $aOptions['featured8-title'] = stripslashes($_POST['featured8-title']);
		$aOptions['featured8-link'] = stripslashes($_POST['featured8-link']);
    
    $aOptions['featured9-image'] = stripslashes($_POST['featured9-image']);
    $aOptions['featured9a-image'] = stripslashes($_POST['featured9a-image']);
    $aOptions['featured9-title'] = stripslashes($_POST['featured9-title']);
		$aOptions['featured9-link'] = stripslashes($_POST['featured9-link']);
    
    $aOptions['featured10-image'] = stripslashes($_POST['featured10-image']);
    $aOptions['featured10a-image'] = stripslashes($_POST['featured10a-image']);
    $aOptions['featured10-title'] = stripslashes($_POST['featured10-title']);
    $aOptions['featured10-link'] = stripslashes($_POST['featured10-link']);
    
    $aOptions['featured11-image'] = stripslashes($_POST['featured11-image']);
    $aOptions['featured11a-image'] = stripslashes($_POST['featured11a-image']);
		$aOptions['featured11-title'] = stripslashes($_POST['featured11-title']);
		$aOptions['featured11-link'] = stripslashes($_POST['featured11-link']);
    
    $aOptions['featured94-image'] = stripslashes($_POST['featured94-image']);
    $aOptions['featured94a-image'] = stripslashes($_POST['featured94a-image']);
    $aOptions['featured94-title'] = stripslashes($_POST['featured94-title']);
    $aOptions['featured94-link'] = stripslashes($_POST['featured94-link']);
    
    $aOptions['featured95-image'] = stripslashes($_POST['featured95-image']);
    $aOptions['featured95a-image'] = stripslashes($_POST['featured95a-image']);
		$aOptions['featured95-title'] = stripslashes($_POST['featured95-title']);
		$aOptions['featured95-link'] = stripslashes($_POST['featured95-link']);
    
    $aOptions['featured96-image'] = stripslashes($_POST['featured96-image']);
    $aOptions['featured96a-image'] = stripslashes($_POST['featured96a-image']);
    $aOptions['featured96-title'] = stripslashes($_POST['featured96-title']);
    $aOptions['featured96-link'] = stripslashes($_POST['featured96-link']);
    
    $aOptions['featured97-image'] = stripslashes($_POST['featured97-image']);
    $aOptions['featured97a-image'] = stripslashes($_POST['featured97a-image']);
		$aOptions['featured97-title'] = stripslashes($_POST['featured97-title']);
		$aOptions['featured97-link'] = stripslashes($_POST['featured97-link']);
    
    $aOptions['featured98-image'] = stripslashes($_POST['featured98-image']);
		$aOptions['featured98a-image'] = stripslashes($_POST['featured98a-image']);
    $aOptions['featured98-title'] = stripslashes($_POST['featured98-title']);
		$aOptions['featured98-link'] = stripslashes($_POST['featured98-link']);
    
    $aOptions['featured99-image'] = stripslashes($_POST['featured99-image']);
    $aOptions['featured99a-image'] = stripslashes($_POST['featured99a-image']);
    $aOptions['featured99-title'] = stripslashes($_POST['featured99-title']);
		$aOptions['featured99-link'] = stripslashes($_POST['featured99-link']);
    
    $aOptions['featured910-image'] = stripslashes($_POST['featured910-image']);
    $aOptions['featured910a-image'] = stripslashes($_POST['featured910a-image']);
    $aOptions['featured910-title'] = stripslashes($_POST['featured910-title']);
    $aOptions['featured910-link'] = stripslashes($_POST['featured910-link']);
    
    $aOptions['featured911-image'] = stripslashes($_POST['featured911-image']);
    $aOptions['featured911a-image'] = stripslashes($_POST['featured911a-image']);
		$aOptions['featured911-title'] = stripslashes($_POST['featured911-title']);
		$aOptions['featured911-link'] = stripslashes($_POST['featured911-link']);
    
    $aOptions['featured12-image'] = stripslashes($_POST['featured12-image']);
		$aOptions['featured12-link'] = stripslashes($_POST['featured12-link']);
    $aOptions['featured12b-image'] = stripslashes($_POST['featured12b-image']);
    
    $aOptions['featured13-image'] = stripslashes($_POST['featured13-image']);
		$aOptions['featured13-link'] = stripslashes($_POST['featured13-link']);
    
    $aOptions['featured14-image'] = stripslashes($_POST['featured14-image']);
		$aOptions['featured14-link'] = stripslashes($_POST['featured14-link']);
    
    $aOptions['featured15-image'] = stripslashes($_POST['featured15-image']);
		$aOptions['featured15-link'] = stripslashes($_POST['featured15-link']);
    
    $aOptions['featured16-image'] = stripslashes($_POST['featured16-image']);
		$aOptions['featured16-link'] = stripslashes($_POST['featured16-link']);
    
    $aOptions['featured17-image'] = stripslashes($_POST['featured17-image']);
		$aOptions['featured17-link'] = stripslashes($_POST['featured17-link']);
    
    $aOptions['featured18-image'] = stripslashes($_POST['featured18-image']);
		$aOptions['featured18-link'] = stripslashes($_POST['featured18-link']);
    $aOptions['featured18-text'] = stripslashes($_POST['featured18-text']);
    $aOptions['featured18-title'] = stripslashes($_POST['featured18-title']);
    
    $aOptions['featured19-image'] = stripslashes($_POST['featured19-image']);
		$aOptions['featured19-link'] = stripslashes($_POST['featured19-link']);
    $aOptions['featured19-text'] = stripslashes($_POST['featured19-text']);
    $aOptions['featured19-title'] = stripslashes($_POST['featured19-title']);
    
    $aOptions['featured20-image'] = stripslashes($_POST['featured20-image']);
		$aOptions['featured20-link'] = stripslashes($_POST['featured20-link']);
    $aOptions['featured20-text'] = stripslashes($_POST['featured20-text']);
    $aOptions['featured20-title'] = stripslashes($_POST['featured20-title']);
    
    $aOptions['featured21-image'] = stripslashes($_POST['featured21-image']);
		$aOptions['featured21-link'] = stripslashes($_POST['featured21-link']);
    $aOptions['featured21-text'] = stripslashes($_POST['featured21-text']);
    $aOptions['featured21-title'] = stripslashes($_POST['featured21-title']);
    
    $aOptions['featured21-image'] = stripslashes($_POST['featured21-image']);
		$aOptions['featured21-link'] = stripslashes($_POST['featured21-link']);
    $aOptions['featured23-text'] = stripslashes($_POST['featured23-text']);
    $aOptions['featured23-title'] = stripslashes($_POST['featured23-title']);
    
    $aOptions['featured22-image'] = stripslashes($_POST['featured22-image']);
		$aOptions['featured22-link'] = stripslashes($_POST['featured22-link']);
    
    $aOptions['featured23-image'] = stripslashes($_POST['featured23-image']);
		$aOptions['featured23-link'] = stripslashes($_POST['featured23-link']);
    
    $aOptions['featured24-image'] = stripslashes($_POST['featured24-image']);
		$aOptions['featured24-link'] = stripslashes($_POST['featured24-link']);
    
    $aOptions['featured25-image'] = stripslashes($_POST['featured25-image']);
		$aOptions['featured25-link'] = stripslashes($_POST['featured25-link']);
    
    $aOptions['featured26-image'] = stripslashes($_POST['featured26-image']);
		$aOptions['featured26-link'] = stripslashes($_POST['featured26-link']);
    
    $aOptions['featured27-image'] = stripslashes($_POST['featured27-image']);
		$aOptions['featured27-link'] = stripslashes($_POST['featured27-link']);
    
    $aOptions['featured28-image'] = stripslashes($_POST['featured28-image']);
		$aOptions['featured28-link'] = stripslashes($_POST['featured28-link']);
    $aOptions['featured281-text'] = stripslashes($_POST['featured281-text']);
    $aOptions['featured281-number'] = stripslashes($_POST['featured281-number']);
    $aOptions['featured282-text'] = stripslashes($_POST['featured282-text']);
    $aOptions['featured282-number'] = stripslashes($_POST['featured282-number']);
    $aOptions['featured283-text'] = stripslashes($_POST['featured283-text']);
    $aOptions['featured283-number'] = stripslashes($_POST['featured283-number']);
    $aOptions['featured284-text'] = stripslashes($_POST['featured284-text']);
    $aOptions['featured284-number'] = stripslashes($_POST['featured284-number']);
    
    $aOptions['featured29-image'] = stripslashes($_POST['featured29-image']);
		$aOptions['featured29-link'] = stripslashes($_POST['featured29-link']);
    $aOptions['featured291-text'] = stripslashes($_POST['featured291-text']);
    $aOptions['featured291-number'] = stripslashes($_POST['featured291-number']);
    $aOptions['featured292-text'] = stripslashes($_POST['featured292-text']);
    $aOptions['featured292-number'] = stripslashes($_POST['featured292-number']);
    $aOptions['featured293-text'] = stripslashes($_POST['featured293-text']);
    $aOptions['featured293-number'] = stripslashes($_POST['featured293-number']);
    $aOptions['featured294-text'] = stripslashes($_POST['featured294-text']);
    $aOptions['featured294-number'] = stripslashes($_POST['featured294-number']);
    
    $aOptions['featured30-image'] = stripslashes($_POST['featured30-image']);
		$aOptions['featured30-link'] = stripslashes($_POST['featured30-link']);
    $aOptions['featured30-text'] = stripslashes($_POST['featured30-text']);
    $aOptions['featured30-title'] = stripslashes($_POST['featured30-title']);
    
    $aOptions['featured31-image'] = stripslashes($_POST['featured31-image']);
		$aOptions['featured31-link'] = stripslashes($_POST['featured31-link']);
    $aOptions['featured31-text'] = stripslashes($_POST['featured31-text']);
    $aOptions['featured31-title'] = stripslashes($_POST['featured31-title']);
    			
			update_option('ArtFull_theme', $aOptions);
		}
		if (isset($_POST['ArtFull_upload'])) {

			$aOptions = ArtFull::initOptions(false);

            $whitelist = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			
			if (!$_FILES['attachment_featured1-image']['type']=='') { 
				$up_file = 'featured1-image'; 
			}
			
			if (!$_FILES['attachment_featured2-image']['type']=='') { 
				$up_file = 'featured2-image'; 
			}
			
			if (!$_FILES['attachment_featured3-image']['type']=='') { 
				$up_file = 'featured3-image'; 
			}
       	if (!$_FILES['attachment_featured4-image']['type']=='') { 
				$up_file = 'featured4-image'; 
			}
        	if (!$_FILES['attachment_featured4a-image']['type']=='') { 
				$up_file = 'featured4a-image'; 
			}
        	if (!$_FILES['attachment_featured5-image']['type']=='') { 
				$up_file = 'featured5-image'; 
			}
      	if (!$_FILES['attachment_featured5a-image']['type']=='') { 
				$up_file = 'featured5a-image'; 
			}
      if (!$_FILES['attachment_featured6-image']['type']=='') { 
				$up_file = 'featured6-image'; 
			}
        	if (!$_FILES['attachment_featured6a-image']['type']=='') { 
				$up_file = 'featured6a-image'; 
			}
        	if (!$_FILES['attachment_featured7-image']['type']=='') { 
				$up_file = 'featured7-image'; 
			}
      	if (!$_FILES['attachment_featured7a-image']['type']=='') { 
				$up_file = 'featured7a-image'; 
			}
				if (!$_FILES['attachment_featured8-image']['type']=='') { 
				$up_file = 'featured8-image'; 
			}	
      		if (!$_FILES['attachment_featured8a-image']['type']=='') { 
				$up_file = 'featured8a-image'; 
			}	
      if (!$_FILES['attachment_featured9-image']['type']=='') { 
				$up_file = 'featured9-image'; 
			}
        	if (!$_FILES['attachment_featured9a-image']['type']=='') { 
				$up_file = 'featured9a-image'; 
			}
        	if (!$_FILES['attachment_featured10-image']['type']=='') { 
				$up_file = 'featured10-image'; 
			}
      	if (!$_FILES['attachment_featured10a-image']['type']=='') { 
				$up_file = 'featured10a-image'; 
			}
      if (!$_FILES['attachment_featured11-image']['type']=='') { 
				$up_file = 'featured11-image'; 
			}
        	if (!$_FILES['attachment_featured11a-image']['type']=='') { 
				$up_file = 'featured11a-image'; 
			}	
       	if (!$_FILES['attachment_featured94-image']['type']=='') { 
				$up_file = 'featured94-image'; 
			}
        	if (!$_FILES['attachment_featured94a-image']['type']=='') { 
				$up_file = 'featured94a-image'; 
			}
        	if (!$_FILES['attachment_featured95-image']['type']=='') { 
				$up_file = 'featured95-image'; 
			}
      	if (!$_FILES['attachment_featured95a-image']['type']=='') { 
				$up_file = 'featured95a-image'; 
			}
      if (!$_FILES['attachment_featured96-image']['type']=='') { 
				$up_file = 'featured96-image'; 
			}
        	if (!$_FILES['attachment_featured96a-image']['type']=='') { 
				$up_file = 'featured96a-image'; 
			}
        	if (!$_FILES['attachment_featured97-image']['type']=='') { 
				$up_file = 'featured97-image'; 
			}
      	if (!$_FILES['attachment_featured97a-image']['type']=='') { 
				$up_file = 'featured97a-image'; 
			}
				if (!$_FILES['attachment_featured98-image']['type']=='') { 
				$up_file = 'featured98-image'; 
			}	
      		if (!$_FILES['attachment_featured98a-image']['type']=='') { 
				$up_file = 'featured98a-image'; 
			}	
      if (!$_FILES['attachment_featured99-image']['type']=='') { 
				$up_file = 'featured99-image'; 
			}
        	if (!$_FILES['attachment_featured99a-image']['type']=='') { 
				$up_file = 'featured99a-image'; 
			}
        	if (!$_FILES['attachment_featured910-image']['type']=='') { 
				$up_file = 'featured910-image'; 
			}
      	if (!$_FILES['attachment_featured910a-image']['type']=='') { 
				$up_file = 'featured910a-image'; 
			}
      if (!$_FILES['attachment_featured911-image']['type']=='') { 
				$up_file = 'featured911-image'; 
			}
        	if (!$_FILES['attachment_featured911a-image']['type']=='') { 
				$up_file = 'featured911a-image'; 
			}	
      if (!$_FILES['attachment_featured12-image']['type']=='') { 
				$up_file = 'featured12-image'; 
			}
			 if (!$_FILES['attachment_featured12b-image']['type']=='') { 
				$up_file = 'featured12b-image'; 
			}
			if (!$_FILES['attachment_featured13-image']['type']=='') { 
				$up_file = 'featured13-image'; 
			}
			
			if (!$_FILES['attachment_featured14-image']['type']=='') { 
				$up_file = 'featured14-image'; 
			}
       	if (!$_FILES['attachment_featured15-image']['type']=='') { 
				$up_file = 'featured15-image'; 
			}
        	if (!$_FILES['attachment_featured16-image']['type']=='') { 
				$up_file = 'featured16-image'; 
			}
        	if (!$_FILES['attachment_featured17-image']['type']=='') { 
				$up_file = 'featured17-image'; 
			}
      	if (!$_FILES['attachment_featured18-image']['type']=='') { 
				$up_file = 'featured18-image'; 
			}
      if (!$_FILES['attachment_featured19-image']['type']=='') { 
				$up_file = 'featured19-image'; 
			}
        	if (!$_FILES['attachment_featured20-image']['type']=='') { 
				$up_file = 'featured20-image'; 
			}
        	if (!$_FILES['attachment_featured21-image']['type']=='') { 
				$up_file = 'featured21-image'; 
			}
      	if (!$_FILES['attachment_featured22-image']['type']=='') { 
				$up_file = 'featured22-image'; 
			}
				if (!$_FILES['attachment_featured23-image']['type']=='') { 
				$up_file = 'featured23-image'; 
			}	
      		if (!$_FILES['attachment_featured24-image']['type']=='') { 
				$up_file = 'featured24-image'; 
			}	
      if (!$_FILES['attachment_featured25-image']['type']=='') { 
				$up_file = 'featured25-image'; 
			}
        	if (!$_FILES['attachment_featured26-image']['type']=='') { 
				$up_file = 'featured26-image'; 
			}
        	if (!$_FILES['attachment_featured27-image']['type']=='') { 
				$up_file = 'featured27-image'; 
			}
      	if (!$_FILES['attachment_featured28-image']['type']=='') { 
				$up_file = 'featured28-image'; 
			}
      if (!$_FILES['attachment_featured29-image']['type']=='') { 
				$up_file = 'featured29-image'; 
			}
        	if (!$_FILES['attachment_featured30-image']['type']=='') { 
				$up_file = 'featured30-image'; 
			}	
       	if (!$_FILES['attachment_featured31-image']['type']=='') { 
				$up_file = 'featured31-image'; 
			}					
            $filetype = $_FILES['attachment_' . $up_file]['type'];

            if (in_array($filetype, $whitelist)) {
              $upload = wp_handle_upload($_FILES['attachment_' . $up_file], array('test_form' => false));
			  $aOptions[$up_file] = stripslashes($upload['url']);
			  update_option('ArtFull_theme', $aOptions);
            }
		}
		add_theme_page(" ArtFull Options", "ArtFull Options", 'edit_themes', basename(__FILE__), array('ArtFull', 'displayOptions'));
	}
	function initOptions ($bReset) {
		$aOptions = get_option('ArtFull_theme');
		if (!is_array($aOptions) || $bReset) {
 
			$aOptions['featured1-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/logo.png';              
      $aOptions['featured2-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/favicon.ico';      
      $aOptions['featured3-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/eames-lounge-chair-mit-ottoman-kirschbaum-leder-premium-schwarz.png';
           		
      $aOptions['featured4-link'] = get_bloginfo('url') . '/about/';
      $aOptions['featured4-title'] = 'About';
      $aOptions['featured4-text'] = 'Typography style responsive two column layout featuring white & black colorscheme with beautiful typography, WooCommerce theme.';
      $aOptions['featured4-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/louboutin-heels-black.png';
      
      $aOptions['featured122-link'] = get_bloginfo('url') . '/brands/';
    
      $aOptions['featured12-link'] = get_bloginfo('url') . '/';
      $aOptions['featured12-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/1.png';
      $aOptions['featured12b-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/cake.png';
       
      $aOptions['featured13-link'] = get_bloginfo('url') . '/';
      $aOptions['featured13-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/2.png';
      
      $aOptions['featured14-link'] = get_bloginfo('url') . '/';
      $aOptions['featured14-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/3.png';
      
      $aOptions['featured14-link'] = get_bloginfo('url') . '/';
      $aOptions['featured14-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/4.png';
      
      $aOptions['featured15-link'] = get_bloginfo('url') . '/';
      $aOptions['featured15-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/5.png';
      
      $aOptions['featured16-link'] = get_bloginfo('url') . '/';
      $aOptions['featured16-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/6.png';
      
      $aOptions['featured17-link'] = get_bloginfo('url') . '/';
      $aOptions['featured17-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/7.png';
      
      $aOptions['featured18-link'] = get_bloginfo('url') . '/';
      $aOptions['featured18-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/8.png';
      $aOptions['featured18-title'] = 'Versace';
      $aOptions['featured18-text'] = 'Gianni Versace, usually referred to as Versace, is a world famous Italian luxury fashion company and trade name founded by Gianni Versace in 1978.';
      
      $aOptions['featured19-link'] = get_bloginfo('url') . '/';
      $aOptions['featured19-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/9.png';
      $aOptions['featured19-title'] = 'Kenzo';
      $aOptions['featured19-text'] = 'Kenzo is a French luxury house founded in 1970 by Japanese designer Kenzo Takada. Kenzo Takada was born in Japan and moved to Paris in 1964 to start his fashion career.';
          
      $aOptions['featured20-link'] = get_bloginfo('url') . '/';
      $aOptions['featured20-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/10.png';
      $aOptions['featured20-title'] = 'Issey Miyake';
      $aOptions['featured20-text'] = 'Issey Miyake (三宅 一生) is a Japanese fashion designer. He is known for his technology-driven clothing designs, exhibitions and fragrances.';
     
      $aOptions['featured21-link'] = get_bloginfo('url') . '/';
      $aOptions['featured21-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/11.png';
      $aOptions['featured21-title'] = 'YSL';
      $aOptions['featured21-text'] = 'Yves Saint Laurent YSL, also known as Saint Laurent Paris) is a luxury fashion house founded by Yves Saint Laurent and his partner, Pierre Bergé. ';
          
      $aOptions['featured22-link'] = get_bloginfo('url') . '/';
      $aOptions['featured22-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/12.png';
      $aOptions['featured22-title'] = 'Prada';
      $aOptions['featured22-text'] = 'Prada is an Italian luxury fashion house, specializing in leather handbags, travel accessories, shoes, ready-to-wear, perfumes and other fashion accessories, founded in 1913 by Mario Prada.';
     
      $aOptions['featured23-link'] = get_bloginfo('url') . '/';
      $aOptions['featured23-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/13.png';
      $aOptions['featured23-title'] = 'Gucci';
      $aOptions['featured23-text'] = 'Gucci was founded by Guccio Gucci in Florence in 1921.';
     
      $aOptions['featured24-link'] = get_bloginfo('url') . '/';
      $aOptions['featured24-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/14.png';
      
      $aOptions['featured25-link'] = get_bloginfo('url') . '/';
      $aOptions['featured25-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/15.png';

      
      $aOptions['featured28-link'] = get_bloginfo('url') . '/';
      $aOptions['featured28-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/orange-chair.jpg';
      $aOptions['featured281-text'] = 'Modern<br /> Cozy';
      $aOptions['featured281-number'] = '73';
      $aOptions['featured282-text'] = 'Unique<br /> Shopping';
      $aOptions['featured282-number'] = '92';
      $aOptions['featured283-text'] = 'Vital<br /> Fun';
      $aOptions['featured283-number'] = '82';
      $aOptions['featured284-text'] = 'Informative<br /> Details';
      $aOptions['featured284-number'] = '98';
      
      $aOptions['featured29-link'] = get_bloginfo('url') . '/';
      $aOptions['featured29-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/payments.jpg';
      $aOptions['featured291-text'] = 'Paypal<br /> Payment';
      $aOptions['featured291-number'] = '99';
      $aOptions['featured292-text'] = 'Card<br /> Payment';
      $aOptions['featured292-number'] = '99';
      $aOptions['featured293-text'] = 'Secure<br /> Transactions';
      $aOptions['featured293-number'] = '99';
      $aOptions['featured294-text'] = 'Secure<br /> Payments';
      $aOptions['featured294-number'] = '99';
      
      $aOptions['featured30-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/london.jpg';
			$aOptions['featured30-link'] = get_bloginfo('url') . '/';
      $aOptions['featured30-text'] = 'London has a diverse range of peoples and cultures, and more than 300 languages are spoken within Greater London. The Office for National Statistics estimated its mid-2014 population to be 8,538,689.';
      $aOptions['featured30-title'] = 'London';
            
      $aOptions['featured31-image'] = get_bloginfo('url') . '/wp-content/themes/ArtFull/img/paris.jpg';
			$aOptions['featured31-link'] = get_bloginfo('url') . '/';
      $aOptions['featured31-text'] = 'Paris was founded in the 3rd century BC by a Celtic people called the Parisii, who gave the city its name. By the 12th century, Paris was the largest city in the western world, a prosperous trading centre.';
      $aOptions['featured31-title'] = 'Paris';
      
			update_option('ArtFull_theme', $aOptions);
		}
		return $aOptions;
	}
	function displayOptions () {
		$aOptions = ArtFull::initOptions(false);
?>
<div class="wrap">

<script type="text/javascript">
var scrolltotop={
	setting: {startline:100, scrollto: 0, scrollduration:1000, fadeduration:[500, 100]},
	controlHTML: '<img src="<?php echo get_template_directory_uri(); ?>/img/up.png" style="filter:alpha(opacity=70); -moz-opacity:0.7;" width="37" height="37"/>', 
	controlattrs: {offsetx:5, offsety:40}, 
	anchorkeyword: '#top', 
	state: {isvisible:false, shouldvisible:false},
	scrollup:function(){
		if (!this.cssfixedsupport) 
			this.$control.css({opacity:0}) 
		var dest=isNaN(this.setting.scrollto)? this.setting.scrollto : parseInt(this.setting.scrollto)
		if (typeof dest=="string" && jQuery('#'+dest).length==1) 
			dest=jQuery('#'+dest).offset().top
		else
			dest=0
		this.$body.animate({scrollTop: dest}, this.setting.scrollduration);
	},
	keepfixed:function(){
		var $window=jQuery(window)
		var controlx=$window.scrollLeft() + $window.width() - this.$control.width() - this.controlattrs.offsetx
		var controly=$window.scrollTop() + $window.height() - this.$control.height() - this.controlattrs.offsety
		this.$control.css({left:controlx+'px', top:controly+'px'})
	},
	togglecontrol:function(){
		var scrolltop=jQuery(window).scrollTop()
		if (!this.cssfixedsupport)
			this.keepfixed()
		this.state.shouldvisible=(scrolltop>=this.setting.startline)? true : false
		if (this.state.shouldvisible && !this.state.isvisible){
			this.$control.stop().animate({opacity:1}, this.setting.fadeduration[0])
			this.state.isvisible=true
		}
		else if (this.state.shouldvisible==false && this.state.isvisible){
			this.$control.stop().animate({opacity:0}, this.setting.fadeduration[1])
			this.state.isvisible=false
		}
	},	
	init:function(){
		jQuery(document).ready(function($){
			var mainobj=scrolltotop
			var iebrws=document.all
			mainobj.cssfixedsupport=!iebrws || iebrws && document.compatMode=="CSS1Compat" && window.XMLHttpRequest 
			mainobj.$body=(window.opera)? (document.compatMode=="CSS1Compat"? $('html') : $('body')) : $('html,body')
			mainobj.$control=$('<div id="topcontrol">'+mainobj.controlHTML+'</div>')
				.css({position:mainobj.cssfixedsupport? 'fixed' : 'absolute', bottom:mainobj.controlattrs.offsety, right:mainobj.controlattrs.offsetx, opacity:0, cursor:'pointer'})
				.attr({title:'back to top'})
				.click(function(){mainobj.scrollup(); return false})
				.appendTo('body')
			if (document.all && !window.XMLHttpRequest && mainobj.$control.text()!='') 
				mainobj.$control.css({width:mainobj.$control.width()}) 
			mainobj.togglecontrol()
			$('a[href="' + mainobj.anchorkeyword +'"]').click(function(){
				mainobj.scrollup()
				return false
			})
			$(window).bind('scroll resize', function(e){
				mainobj.togglecontrol()
			})
		})
	}
}
scrolltotop.init()</script>
<style type="text/css">
.pnav{cursor:pointer;font:100 15px "Open Sans",helvetica,verdana,arial,sans-serif;margin:30px 0 0 0;text-transform:uppercase;}
.pnav input{cursor:pointer;font:100 15px "Open Sans",helvetica,verdana,arial,sans-serif;padding:14px 18px;width:200px;height:60px;margin:30px 0 0 0;text-transform:uppercase;color:#fff;background:#E6443F;border:3px solid #ccc;text-decoration:none;}
.pnav input:hover{text-decoration:none;background:#6B9263;transition:all .45s linear;-o-transition:all .45s linear;-moz-transition:all .45s linear;-webkit-transition:all .45s linear}
</style>

	<h2>ArtFull Theme Options</h2>
	<p>You can edit frontpage options by using the fields below.</p>

<div id="sideblock" style="float:right;width:220px;margin-left:10px;position:fixed;top:30px;right:0;z-index:9999;background:#fff;padding:20px;border:3px solid #ccc;"> 
     <h3>Information</h3>
     <div id="dbx-content" style="text-decoration:none;">       
 		 <img src="<?php bloginfo('stylesheet_directory'); ?>/img/theme/favicon.ico" width="20px" style="margin:10px 10px 0 0" /><a style="text-decoration:none;" href="http://3oneseven.com/"> 3oneseven</a><br /><br />
		<div class="pna" style="padding:14px 18px;border:1px solid #E6443F"><a target="blank" href="/wp-admin/media-new.php"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/arrr.png" width="20px" style="margin-right:10px;" /><a style="font:100 15px 'Open Sans',helvetica,verdana,arial,sans-serif!important;text-transform:uppercase!important;text-decoration:none;color:#E6443F" target="blank" href="/wp-admin/media-new.php">New images here</a></div>	
    <br />		
    <div class="pna" style="padding:14px 18px;border:1px solid #E6443F"><a href="#save"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/theme/save.png" width="20px" style="margin-right:10px;" /><a style="font:100 15px 'Open Sans',helvetica,verdana,arial,sans-serif!important;text-transform:uppercase!important;text-decoration:none;color:#E6443F" href="#save">Save all options</a></div>			
</div>
</div> 
 
    <div style="margin-left:0px;">
    <form action="#" method="post" enctype="multipart/form-data" name="massive_form" id="massive_form">
		<fieldset name="general_options" class="options">
        <div style="border-bottom:1px solid #333;"></div>
        <h3 style="margin-bottom:0px;"Options:</h3>
        <p style="margin-top:0px;">You can add links, images or text by filling out the fields below.</p>

<div style="border-top:1px solid #ff3300;padding-top:10px;"></div>

<h4><a style="text-decoration:none;" href="#logo">Logo</a> | <a style="text-decoration:none;" href="#about">About</a> | <a style="text-decoration:none;" href="#brands">Brands</a> | 
<a style="text-decoration:none;" href="#info">Info</a> | <a style="text-decoration:none;" href="#location">Location</a></h4>

<div style="border-bottom:1px solid #ff3300;padding-bottom:10px;"></div>

<h2><a style="color:#000;text-decoration:none;" title="Click to open" href="javascript:expandIt(document.getElementById('link1'))">Logo area</a></h2>
<div style="border-bottom:1px solid #ff3300;"></div>     
<div id="hero" >
                 	        
		<h3>Logo</h3>
             
       Image Location (Optimal size: 202px X 101px):<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured1-image" id="featured1-image" size="30" value="<?php echo($aOptions['featured1-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured1-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured1-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured1-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
	                 
<div style="border-bottom:1px solid #ff3300;"></div>

<h3>Favicon</h3>
             
       Image Location (Optimal size: 50px X 50px):<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured2-image" id="featured2-image" size="30" value="<?php echo($aOptions['featured2-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured2-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured2-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured2-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
                  		       
</div> 
<div style="border-top:1px solid #ff3300;"></div>
<h3><a style="color:#000;text-decoration:none;" title="Click to open" href="javascript:expandIt(document.getElementById('link2'))">About box</a></h3>
<div style="border-bottom:1px solid #ff3300;"></div>
<div id="conference" >
    
        Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured4-title" id="featured4-title" value="<?php echo($aOptions['featured4-title']); ?>"></input>
        </div><br />
               
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured4-link" id="featured4-link" size="30" value="<?php echo($aOptions['featured4-link']); ?>"></input>   
        </div><br />
        
          Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured4-text" cols="30" rows="2" id="featured3-text"><?php echo($aOptions['featured4-text']); ?></textarea>
		</div><br />
	 
         Image Location (Optimal size: 600px X 400px):<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured4-image" id="featured4-image" size="50" value="<?php echo($aOptions['featured4-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured4-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured4-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured4-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

</div> 

<div style="border-top:1px solid #ff3300;"></div>
<h3><a style="color:#000;text-decoration:none;" title="Click to open" href="javascript:expandIt(document.getElementById('link5'))">Brands</a></h3>
<div style="border-bottom:1px solid #ff3300;"></div>
<div id="brands" >
 
 		<h2>Brands <b>(Optimal image size: 125px X 125px, place logo in center)</b></h2>

 Shop now! button Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured122-link" id="featured122-link" size="30" value="<?php echo($aOptions['featured122-link']); ?>"></input>   
        </div><br />
        

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Your logo in grey</h2>  
      
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured12b-image" id="featured12b-image" size="50" value="<?php echo($aOptions['featured12b-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured12b-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured12b-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured12b-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
            
<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 1</h2>  
      
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured12-link" id="featured12-link" size="30" value="<?php echo($aOptions['featured12-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured12-image" id="featured12-image" size="50" value="<?php echo($aOptions['featured12-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured12-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured12-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured12-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>

    <h2>Box 2</h2>  
      
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured13-link" id="featured13-link" size="30" value="<?php echo($aOptions['featured13-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured13-image" id="featured13-image" size="50" value="<?php echo($aOptions['featured13-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured13-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured13-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured13-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 3</h2>  
      
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured14-link" id="featured14-link" size="30" value="<?php echo($aOptions['featured14-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured14-image" id="featured14-image" size="50" value="<?php echo($aOptions['featured14-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured14-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured14-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured14-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 4</h2>  
      
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured15-link" id="featured15-link" size="30" value="<?php echo($aOptions['featured15-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured15-image" id="featured15-image" size="50" value="<?php echo($aOptions['featured15-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured15-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured15-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured15-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 5</h2>  
      
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured16-link" id="featured16-link" size="30" value="<?php echo($aOptions['featured16-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured16-image" id="featured16-image" size="50" value="<?php echo($aOptions['featured16-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured16-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured16-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured16-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 6</h2>  
      
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured17-link" id="featured17-link" size="30" value="<?php echo($aOptions['featured17-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured17-image" id="featured17-image" size="50" value="<?php echo($aOptions['featured17-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured17-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured17image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured17-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 7</h2>  
      
            Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured18-title" id="featured18-title" value="<?php echo($aOptions['featured18-title']); ?>"></input>
        </div><br />
               
        Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured18-text" cols="30" rows="2" id="featured18-text"><?php echo($aOptions['featured18-text']); ?></textarea>
		</div><br />
    
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured18-link" id="featured18-link" size="30" value="<?php echo($aOptions['featured18-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured18-image" id="featured18-image" size="50" value="<?php echo($aOptions['featured18-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured18-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured18-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured18-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 8</h2>  
      
           Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured19-title" id="featured19-title" value="<?php echo($aOptions['featured19-title']); ?>"></input>
        </div><br />
               
        Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured19-text" cols="30" rows="2" id="featured19-text"><?php echo($aOptions['featured19-text']); ?></textarea>
		</div><br />
    
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured19-link" id="featured19-link" size="30" value="<?php echo($aOptions['featured19-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured19-image" id="featured19-image" size="50" value="<?php echo($aOptions['featured19-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured19-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured19-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured19-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 9</h2>  
      
            Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured20-title" id="featured20-title" value="<?php echo($aOptions['featured20-title']); ?>"></input>
        </div><br />
               
        Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured20-text" cols="30" rows="2" id="featured20-text"><?php echo($aOptions['featured20-text']); ?></textarea>
		</div><br />
    
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured20-link" id="featured20-link" size="30" value="<?php echo($aOptions['featured20-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured20-image" id="featured20-image" size="50" value="<?php echo($aOptions['featured20-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured20-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured20-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured20-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 10</h2>  
      
            Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured21-title" id="featured21-title" value="<?php echo($aOptions['featured21-title']); ?>"></input>
        </div><br />
               
        Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured21-text" cols="30" rows="2" id="featured21-text"><?php echo($aOptions['featured21-text']); ?></textarea>
		</div><br />
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured21-link" id="featured21-link" size="30" value="<?php echo($aOptions['featured21-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured21-image" id="featured21-image" size="50" value="<?php echo($aOptions['featured21-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured21-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured21-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured21-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 11</h2>  
      
            Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured22-title" id="featured22-title" value="<?php echo($aOptions['featured22-title']); ?>"></input>
        </div><br />
               
        Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured22-text" cols="30" rows="2" id="featured22-text"><?php echo($aOptions['featured22-text']); ?></textarea>
		</div><br />
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured22-link" id="featured22-link" size="30" value="<?php echo($aOptions['featured22-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured22-image" id="featured22-image" size="50" value="<?php echo($aOptions['featured22-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured22-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured22-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured22-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Box 12</h2>  
      
            Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured23-title" id="featured23-title" value="<?php echo($aOptions['featured23-title']); ?>"></input>
        </div><br />
               
        Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured23-text" cols="30" rows="2" id="featured23-text"><?php echo($aOptions['featured23-text']); ?></textarea>
		</div><br />
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured23-link" id="featured23-link" size="30" value="<?php echo($aOptions['featured23-link']); ?>"></input>   
        </div><br />
                
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured23-image" id="featured23-image" size="50" value="<?php echo($aOptions['featured23-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured23-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured23-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured23-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

</div> 
<div style="border-top:1px solid #ff3300;"></div>
<h3><a style="color:#000;text-decoration:none;" title="Click to open" href="javascript:expandIt(document.getElementById('link6'))">InfoSection</a></h3>
<div style="border-bottom:1px solid #ff3300;"></div>
<div id="agenda" >
 
 		<h2>Info box</h2>

<div style="border-top:1px solid #ff3300;"></div>    
    <h2>Info Box </h2>  
      
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured28-link" id="featured28-link" size="30" value="<?php echo($aOptions['featured28-link']); ?>"></input>   
        </div><br />
                
         Image Location (Optimal image size: 600px X 400px) <br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured28-image" id="featured28-image" size="50" value="<?php echo($aOptions['featured28-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured28-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured28-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured28-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
        
        1st Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured281-text" id="featured281-text"><?php echo($aOptions['featured281-text']); ?></textarea>
		</div><br />
    
        1st Percentage Number:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured281-number" id="featured281-number"><?php echo($aOptions['featured281-number']); ?></textarea>
		</div><br />
    
      2nd Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured282-text" id="featured282-text"><?php echo($aOptions['featured282-text']); ?></textarea>
		</div><br />
    
        2nd Percentage Number:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured282-number" id="featured282-number"><?php echo($aOptions['featured282-number']); ?></textarea>
		</div><br />
    
     3rd Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured283-text" id="featured283-text"><?php echo($aOptions['featured283-text']); ?></textarea>
		</div><br />
    
        3rd Percentage Number:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured283-number" id="featured283-number"><?php echo($aOptions['featured283-number']); ?></textarea>
		</div><br />
    
     4th Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured284-text" id="featured284-text"><?php echo($aOptions['featured284-text']); ?></textarea>
		</div><br />
    
        4th Percentage Number:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured284-number" id="featured284-number"><?php echo($aOptions['featured284-number']); ?></textarea>
		</div><br />

<div style="border-top:1px solid #ff3300;"></div>

 <h2>Payment Box </h2>  
      
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured29-link" id="featured29-link" size="30" value="<?php echo($aOptions['featured29-link']); ?>"></input>   
        </div><br />
                
         Image Location (Optimal image size: 600px X 400px) <br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured29-image" id="featured29-image" size="50" value="<?php echo($aOptions['featured29-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured29-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured29-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured29-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

        1st Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured291-text" id="featured291-text"><?php echo($aOptions['featured291-text']); ?></textarea>
		</div><br />
           1st Percentage Number:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured291-number" id="featured291-number"><?php echo($aOptions['featured291-number']); ?></textarea>
		</div><br />
    
      2nd Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured292-text" id="featured292-text"><?php echo($aOptions['featured292-text']); ?></textarea>
		</div><br />
    
        2nd Percentage Number:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured292-number" id="featured292-number"><?php echo($aOptions['featured292-number']); ?></textarea>
		</div><br />
    
     3rd Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured293-text" id="featured293-text"><?php echo($aOptions['featured293-text']); ?></textarea>
		</div><br />
    
        3rd Percentage Number:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured293-number" id="featured293-number"><?php echo($aOptions['featured293-number']); ?></textarea>
		</div><br />
    
     4th Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured294-text" id="featured294-text"><?php echo($aOptions['featured294-text']); ?></textarea>
		</div><br />
    
        4th Percentage Number:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" cols="30" rows="2" name="featured294-number" id="featured294-number"><?php echo($aOptions['featured294-number']); ?></textarea>
		</div><br />
    
</div> 
<div style="border-top:1px solid #ff3300;"></div>
<h3><a style="color:#000;text-decoration:none;" title="Click to open" href="javascript:expandIt(document.getElementById('link7'))">Location</a></h3>
<div style="border-bottom:1px solid #ff3300;"></div>
<div id="location" >
 
 		<h2>Location</h2>
    
     <h3>London</h3>
     
         Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured30-title" id="featured30-title" value="<?php echo($aOptions['featured30-title']); ?>"></input>
        </div><br />
               
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured30-link" id="featured30-link" size="30" value="<?php echo($aOptions['featured30-link']); ?>"></input>   
        </div><br />
        
          Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured30-text" cols="30" rows="2" id="featured30-text"><?php echo($aOptions['featured30-text']); ?></textarea>
		</div><br />
	 
         Image Location (Optimal image size: 600px X 400px) <br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured30-image" id="featured30-image" size="50" value="<?php echo($aOptions['featured30-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured30-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured30-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured30-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-top:1px solid #ff3300;"></div>

     <h3>Paris</h3>
     
         Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured31-title" id="featured31-title" value="<?php echo($aOptions['featured31-title']); ?>"></input>
        </div><br />
               
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured31-link" id="featured31-link" size="30" value="<?php echo($aOptions['featured31-link']); ?>"></input>   
        </div><br />
        
          Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured31-text" cols="31" rows="2" id="featured31-text"><?php echo($aOptions['featured31-text']); ?></textarea>
		</div><br />
	 
         Image Location (Optimal image size: 600px X 400px) <br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured31-image" id="featured31-image" size="50" value="<?php echo($aOptions['featured31-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured31-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured31-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured31-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
        
</div>

		</fieldset>    		
		<div id="save"><div class="pnav"><input type="submit" name="ArtFull_save" value="Save" /></div></div>
    <br /><br />
    <div class="pnav"><input type="submit" name="ArtFull_reset" value="Reset" /></div>
	</form>      
</div>
<?php
	}
}
// Register functions
add_action('admin_menu', array('ArtFull', 'addOptions'));
?>