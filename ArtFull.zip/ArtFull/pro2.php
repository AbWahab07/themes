		<!-- TEAM -->
		<section id="team">
		
			<!-- CONTAINER -->
			<div class="container">
				<h2><b>Latest</b> Items</h2>
				
				<!-- ROW -->
				<div class="row" data-appear-top-offset="-200" data-animated="fadeInUp">
						
					<!-- TEAM SLIDER -->
					<div class="owl-demo owl-carousel team_slider">
				
<?php $loop = new WP_Query( array( 'post_type' => 'product', 'posts_per_page' => 8, 'offset' => 4 ) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>
	<div class="item">
							<div class="crewman_item">
								<div class="crewman">
									 <?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
								</div>
								<div class="crewman_descr center">
									<div class="crewman_descr_cont">
										<p>	<a href="<?php the_permalink() ?>" ><?php echo get_the_title(); ?></a></p>
										<span><?php echo $product->get_price_html(); ?></span>
									</div>
								</div>
								<div class="crewman_social">
									<a href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink(); ?>" ><i class="fa fa-twitter"></i></a>
									<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" ><i class="fa fa-facebook-square"></i></a>
								</div>
							</div>
						</div>
               
<?php endwhile; wp_reset_query(); ?>    

					</div><!-- TEAM SLIDER -->
				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //TEAM -->