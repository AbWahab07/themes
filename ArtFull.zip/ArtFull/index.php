<?php get_template_part('headerhome'); ?>

<?php get_template_part('item'); ?>	


		<section id="about">

			<div class="services_block padbot40" data-appear-top-offset="-200" data-animated="fadeInUp">

				<div class="container">

					<div class="row">
          <?php 
	$my_query = new WP_Query('showposts=4&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-ss-12 margbot30">
							<a class="services_item" href="<?php the_permalink() ?>" >
								<p><?php the_title(); ?></p>
								<span><?php the_content_rss('', FALSE, ' ', 10); ?></span>
							</a>
						</div>
<?php endwhile; ?>            
			
					</div>
				</div>
			</div>

<?php get_template_part('brands'); ?>			
			

			<div class="purpose_block">
				

				<div class="container">

					<div class="row">
					  <?php $aOptions = ArtFull::initOptions(false); ?>
						<div class="col-lg-7 col-md-7 col-sm-7" data-appear-top-offset="-200" data-animated="fadeInLeft">
							<h2><?php echo($aOptions['featured4-title']); ?></h2>
							<p><?php echo($aOptions['featured4-text']); ?></p>
							<a class="btn btn-active" href="<?php echo($aOptions['featured4-link']); ?>" ><?php _e('View more', 'Detox'); ?></a>
						</div>
						
						<div class="col-lg-5 col-md-5 col-sm-5 ipad_img_in" data-appear-top-offset="-200" data-animated="fadeInRight">
							<img class="ipad_img1" src="<?php echo($aOptions['featured4-image']); ?>" alt="<?php echo($aOptions['featured4-title']); ?>" />
						</div>
					</div>
				</div>
			</div>
		</section>
		

<?php
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('pro');
} else {
get_template_part('post');
}
?>

<?php
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('pro2');
} else {
}
?>

		<section id="news">

			<div class="container">
				<h2><b>Latest</b> News</h2>

				<div class="testimonials" data-appear-top-offset="-200" data-animated="fadeInUp">

					<div class="owl-demo owl-carousel testim_slider">
						
<?php 
	$my_query = new WP_Query('showposts=3&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
						<div class="item">
							<div class="testim_content">“<?php the_content_rss('', FALSE, ' ', 20); ?>”</div>
							<div class="testim_author"><?php the_title(); ?></div>
						</div>
<?php endwhile; ?>
					</div>
				</div>

				<div class="row recent_posts" data-appear-top-offset="-200" data-animated="fadeInUp">
<?php 
	$my_query = new WP_Query('showposts=3&offset=3');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>        
					<div class="col-lg-4 col-md-4 col-sm-4 padbot30 post_item_block">
						<div class="post_item">
                                    <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>  
							<div class="post_item_img" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
            
							
								<a class="link" href="<?php the_permalink() ?>" ></a>
							</div>
							<div class="post_item_content">
								<a class="title" href="<?php the_permalink() ?>" ><?php the_title(); ?></a>
								<ul class="post_item_inf">
									<li><?php the_author_posts_link(); ?> |</li>
									<li><?php the_category(' <span> | </span> '); ?> |</li>
									<li><?php comments_popup_link(__('No Comment', 'Detox'), __('1 Comment', 'Detox'), __('% Comments', 'Detox'), '', __('Closed', 'Detox')); ?></li>
								</ul>
							</div>
						</div>
					</div>
<?php endwhile; ?>
				</div>
			</div>
		</section>
	</div>
  
<?php get_template_part('footer'); ?>