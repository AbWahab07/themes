<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<section id="blog">
			
			<!-- CONTAINER -->
			<div class="container">
				
				<!-- ROW -->
				<div class="row">
				
					<!-- BLOG BLOCK -->
					<div class="blog_block col-lg-9 col-md-9 padbot50">
						
						<!-- SINGLE BLOG POST -->
						<div class="single_blog_post clearfix" data-animated="fadeInUp">
							<div class="single_blog_post_descr">
								<div class="single_blog_post_date"><?php the_time('M'); ?> <?php the_time('j'); ?></div>
								<div class="single_blog_post_title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></div>
							
							</div>
							
							<div class="single_blog_post_content">
<?php the_content(__('Read more', 'Detox'));?>
              	</div>
							
						</div><!-- //SINGLE BLOG POST -->
						
						
						<!-- SINGLE BLOG POST TAG -->
						<div class="single_blog_post_tags margbot50" data-animated="fadeInUp">
							<ul>
						<li><?php the_category(' <span> | </span> '); ?></li>
							</ul>
						</div><!-- //SINGLE BLOG POST TAG -->
						
						<hr>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>	
				
					</div><!-- //BLOG BLOCK -->

				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //BLOG -->
	</div><!-- //PAGE -->

<?php get_footer(); ?>