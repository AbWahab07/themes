<div class="cleancode_block">

<div class="container" data-appear-top-offset="-200" data-animated="fadeInUp">

<div id="myTabContent" class="tab-content">      
<?php $aOptions = ArtFull::initOptions(false); ?>  

					<div id="myTabContent" class="tab-content">
						<div class="tab-pane fade in active clearfix" id="tab1">
							<p class="title"><?php echo($aOptions['featured18-title']); ?></p>
							<span><?php echo($aOptions['featured18-text']); ?></span>
						</div>
						<div class="tab-pane fade clearfix" id="tab2">
							<p class="title"><?php echo($aOptions['featured19-title']); ?></p>
							<span><?php echo($aOptions['featured19-text']); ?></span>
						</div>
						<div class="tab-pane fade clearfix" id="tab3">
							<p class="title"><?php echo($aOptions['featured20-title']); ?></p>
							<span><?php echo($aOptions['featured20-text']); ?></span>
						</div>
						<div class="tab-pane fade clearfix" id="tab4">
							<p class="title"><?php echo($aOptions['featured21-title']); ?></p>
							<span><?php echo($aOptions['featured21-text']); ?></span>
						</div>
						<div class="tab-pane fade clearfix" id="tab5">
							<p class="title"><?php echo($aOptions['featured22-title']); ?></p>
							<span><?php echo($aOptions['featured22-text']); ?></span>
						</div>
						<div class="tab-pane fade clearfix" id="tab6">
							<p class="title"><?php echo($aOptions['featured23-title']); ?></p>
							<span><?php echo($aOptions['featured23-text']); ?></span>
						</div>
					</div>
					<ul id="myTab" class="nav nav-tabs">
						<li class="active"><a class="i1" href="#tab1" data-toggle="tab" ><i><img src="<?php echo($aOptions['featured18-image']); ?>" alt="<?php echo($aOptions['featured18-title']); ?>" /></i><span><?php echo($aOptions['featured18-title']); ?></span></a></li>
						<li><a class="i2" href="#tab2" data-toggle="tab" ><i><img src="<?php echo($aOptions['featured19-image']); ?>" alt="<?php echo($aOptions['featured19-title']); ?>" /></i><span><?php echo($aOptions['featured19-title']); ?></span></a></li>
						<li><a class="i3" href="#tab3" data-toggle="tab" ><i><img src="<?php echo($aOptions['featured20-image']); ?>" alt="<?php echo($aOptions['featured20-title']); ?>" /></i><span><?php echo($aOptions['featured20-title']); ?></span></a></li>
						<li><a class="i4" href="#tab4" data-toggle="tab" ><i><img src="<?php echo($aOptions['featured21-image']); ?>" alt="<?php echo($aOptions['featured21-title']); ?>" /></i><span><?php echo($aOptions['featured21-title']); ?></span></a></li>
						<li><a class="i5" href="#tab5" data-toggle="tab" ><i><img src="<?php echo($aOptions['featured22-image']); ?>" alt="<?php echo($aOptions['featured22-title']); ?>" /></i><span><?php echo($aOptions['featured22-title']); ?></span></a></li>
						<li><a class="i6" href="#tab6" data-toggle="tab" ><i><img src="<?php echo($aOptions['featured23-image']); ?>" alt="<?php echo($aOptions['featured23-title']); ?>" /></i><span><?php echo($aOptions['featured23-title']); ?></span></a></li>
					</ul><!-- CASTOM TAB -->
				</div><!-- //CONTAINER -->
			</div><!-- //CLEAN CODE -->
      </div>