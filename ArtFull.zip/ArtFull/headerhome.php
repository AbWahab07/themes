<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="https://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="dns-prefetch" href="//statcounter.com" />
<link rel="dns-prefetch" href="//fonts.googleapis.com/" />
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com" />

<link href="<?php echo get_template_directory_uri(); ?>/css/style.css" rel="stylesheet" type="text/css" />

<link href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet" />	
<!--[if IE]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]--><!--[if IE]><html class="ie" lang="en"><![endif]-->


	
	<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/plugins.js" type="text/javascript"></script>	
  <script src="<?php echo get_template_directory_uri(); ?>/js/artfull.js" type="text/javascript"></script>
<?php $aOptions = ArtFull::initOptions(false); ?>
<link rel="icon" href="<?php echo($aOptions['featured2-image']); ?>" />
<meta name="generator" content="Nexus-6 ver 2019" />

<?php if(is_front_page()): ?><?php elseif (is_singular()): ?>
<link rel="prefetch" href="<?php echo get_permalink(get_adjacent_post(false,'',true)); ?>">
<link rel="prerender" href="<?php echo get_permalink(get_adjacent_post(false,'',false)); ?>">
<?php else: ?>
<link rel="prefetch" href="<?php echo home_url(); ?>">
<link rel="prerender" href="<?php echo home_url(); ?>">
<?php endif; ?>

<link rel="author" type="text/plain" href="https://wp.3oneseven.com/humans.txt" />

</head>

<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="http://schema.org/WebPage">

<div class="preloader_hidel">

	<div id="page">

		<header>

			<div class="menu_block">

				<div class="container clearfix">

					<div class="logo pull-left">
						<a href="<?php echo get_settings('home'); ?>/" ><img src="<?php echo($aOptions['featured1-image']); ?>" alt="<?php bloginfo('name'); ?>" /></a>
					</div>

					<div id="search-form" class="pull-right">
             <form id="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e('Search...', 'Detox'); ?>" name="s" id="s" onfocus="if (this.value == 'Search...', 'Detox') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search', 'Detox';}" />
</form>
					</div>
          
<div class="pull-right">
<nav class="navmenu center">
<ul id="nav" class="menu">
<li id="menu-item-183689099" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-183689099"><a href="/">Home</a></li>
<li id="menu-item-183689116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-183689116"><a href="/nature/">Nature</a></li>
<li id="menu-item-183689117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-183689117"><a href="/level-3/">Level 3</a></li>
<li id="menu-item-183689118" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-183689118"><a href="/level-2/">Level 2</a></li>
<li id="menu-item-183688767" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-183688767"><a href="/about/">About</a></li>
</ul>             
</nav>
</div>
				</div>
			</div>
		</header>