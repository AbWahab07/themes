<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml">
<head profile="https://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1">
  
<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<?php if ( is_singular() ) wp_enqueue_script( "comment-reply" ); ?>
<?php if(is_front_page()): ?><?php elseif (is_singular()): ?>
<link rel="prefetch" href="<?php echo get_permalink(get_adjacent_post(false,'',true)); ?>">
<link rel="prerender" href="<?php echo get_permalink(get_adjacent_post(false,'',false)); ?>">
<?php else: ?>
<link rel="prefetch" href="<?php echo home_url(); ?>">
<link rel="prerender" href="<?php echo home_url(); ?>">
<?php endif; ?>
<link rel="dns-prefetch" href="//netdna.bootstrapcdn.com" />
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/js/global.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/js/contentslider.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/js/misc.js"></script>
<script type="text/javascript" >
        if(!(('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch)) {
	        	var html = document.documentElement;
	        	html.classList.add('no-touch');
        }
</script>
       
<link href="<?php bloginfo('template_url'); ?>/assets/css/global.css" media="screen" rel="stylesheet" type="text/css">
<link href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet" />	
<link rel="shortcut icon" type="image/ico" href="<?php bloginfo('template_url'); ?>/images/icon/favicon.png" />


<?php wp_head(); ?>        

</head>

<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="https://schema.org/WebPage">

<div class="page ">

<?php if ( (is_home())  ) { ?>
<header class="global-header theme-transparent animated fadeIn">
<?php } else { ?>
<header class="global-header theme-light">
<?php } ?>
			<div class="global-header_action-bar">
				<h1><a href="<?php echo get_settings('home'); ?>/" class="global-header_logo-link"><?php bloginfo('name'); ?></a></h1>
				<p><?php bloginfo('description'); ?></p>
				<button class="icon-menu js-global-icon-menu">
					<span>menu</span>
				</button>
				
				<div class="global-header_search">
					<div class="icon-search js-global-search"></div>


          <form class="global-header_search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
						<input class="global-header_search-input" placeholder="<?php _e( 'Enter search term...', 'Detox') ?>" name="s" id="s" autocomplete="off" type="text">
						<div class="icon-x js-close-search">✕</div>
					</form>
				</div>	
			</div>

			<nav class="global-header_nav" role="navigation">
<div class="nav-primary js-global-nav-control">

<div class="nav-section nav-section--theme-1">
<ul class="menu1 one"><?php wp_list_pages('title_li=&depth=1&sort_column,post_title=ID&number=1&offset=0'); ?></ul>

<div class="nav-menu">

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level1-1') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Recently', 'Detox') ?></div>
<ul><?php wp_get_archives('type=weekly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level1-2') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Topics', 'Detox') ?></div>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li=&number=4'); ?></ul>
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level1-3') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Calendar', 'Detox') ?></div>
<ul><?php get_calendar(); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level1-4') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Archives', 'Detox') ?></div>
<ul><?php wp_get_archives('type=yearly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level1-5') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Monthly', 'Detox') ?></div>
<ul><?php wp_get_archives('type=monthly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

</div>
</div>

<div class="nav-section nav-section--theme-2">
<ul class="menu2 two"><?php wp_list_pages('title_li=&depth=1&sort_column,post_title=ID&number=1&offset=1'); ?></ul>

<div class="nav-menu">

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level2-1') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Calendar', 'Detox') ?></div>
<ul><?php get_calendar(); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level2-2') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Topics', 'Detox') ?></div>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li=&number=4'); ?></ul>
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level2-3') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Inside', 'Detox') ?></div>
<ul><?php wp_list_pages('title_li=&depth=0&number=4'); ?></ul>
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level2-4') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Archives', 'Detox') ?></div>
<ul><?php wp_get_archives('type=yearly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level2-5') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Monthly', 'Detox') ?></div>
<ul><?php wp_get_archives('type=monthly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

</div>

</div>
<div class="nav-section nav-section--theme-3">
<ul class="menu3 three"><?php wp_list_pages('title_li=&depth=1&sort_column,post_title=ID&number=1&offset=2'); ?></ul>

<div class="nav-menu">

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level3-1') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Monthly', 'Detox') ?></div>
<ul><?php wp_get_archives('type=monthly&limit=4&offset=4&show_post_count=true'); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level3-2') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Topics', 'Detox') ?></div>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li=&number=4'); ?></ul>
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level3-3') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Inside', 'Detox') ?></div>
<ul><?php wp_list_pages('title_li=&depth=0&number=4'); ?></ul>
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level3-4') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Archives', 'Detox') ?></div>
<ul><?php wp_get_archives('type=yearly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level3-5') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Monthly', 'Detox') ?></div>
<ul><?php wp_get_archives('type=monthly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

</div>

</div>

<div class="nav-section nav-section--theme-4">
<ul class="menu4 four"><?php wp_list_pages('title_li=&depth=1&sort_column,post_title=ID&number=1&offset=3'); ?></ul>

<div class="nav-menu">

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level4-1') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Monthly', 'Detox') ?></div>
<ul><?php wp_get_archives('type=weekly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level4-2') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Topics', 'Detox') ?></div>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li=&number=1'); ?></ul>
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level4-3') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Inside', 'Detox') ?></div>
<ul><?php wp_list_pages('title_li=&depth=0&number=4'); ?></ul>
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level4-4') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Archives', 'Detox') ?></div>
<ul><?php wp_get_archives('type=yearly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('level4-5') ) : ?>
<div class="nav-sub-section">
<div class="iglobal-footer_title"><?php _e( 'Monthly', 'Detox') ?></div>
<ul><?php wp_get_archives('type=monthly&limit=4&offset=4'); ?></ul> 
</div>
<?php endif; ?>

</div>

</div>
</div>

<div class="nav-secondary">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'secnav',
'container' => '',
'container_id' => 'sec-nav',
'menu_id' => 'inav',
'fallback_cb' => 'secnav_fallback',
));
} else {
?>
<?php
}
?>
</div>

</nav>
</header>