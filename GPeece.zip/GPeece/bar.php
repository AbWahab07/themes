<div id="sidebar">
<div class="xwoo">

<?php
/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('shop');
} else {
get_template_part('featured');
}
?>


<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebar') ) : ?>

<div class="widget">
<div id="b">
<div id="sidebar-me">
<h4><?php _e('About', 'Detox'); ?></h4>
<p>
<?php query_posts('pagename=about');?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php if ( get_the_author_meta( 'description' ) ) :  ?>
<div class="author-avatar alignright">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 90 ) ); ?>
</div>
<?php endif; ?>
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<div class="more"><span class="bigdate">{</span> <a href="<?php home_url(); ?>/about/"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
<?php endwhile; endif; ?>  		 
</p>
</div>
</div>
</div>

<div class="widget">
<div class="cat">
<h4><?php _e('Categories', 'Detox'); ?></h4>
<ul>
<?php wp_list_categories('sort_column=name&hierarchical=0&title_li='); ?>
</ul>
</div>
</div>

<div class="widget">
<h4><?php _e('Latest', 'Detox'); ?></h4>
<div id="slide">
<a href="javascript:hightlighted('switch1', 'link1');" class="hightlighted_down" id="link1" title="<?php _e('View recent posts', 'Detox'); ?>" ><?php _e('Recently', 'Detox'); ?></a> 
<a href="javascript:hightlighted('switch2', 'link2');" class="hightlighted" id="link2" title="<?php _e('View the archives', 'Detox'); ?>"><?php _e('Archives', 'Detox'); ?></a>
<a href="javascript:hightlighted('switch3', 'link3');" class="hightlighted" id="link3" title="<?php _e('View Tags', 'Detox'); ?>"><?php _e('Tags', 'Detox'); ?></a>

<div style="display:block;" id="switch1">
<div id="recent">
<ul class="dates">

<?php $my_query = new WP_Query('showposts=3'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<li><a href="<?php the_permalink() ?>"><?php the_title() ?>   
<small><?php _e('on', 'Detox'); ?></small> <?php the_time('M', 'Detox'); ?>{<span class="bigdate"><?php the_time('j', 'Detox'); ?></span>}</a></li>
<?php endwhile; ?>

</ul>
</div>
</div>

<div id="switch2" style="display: none;">
<div id="recent2">
<ul class="dates"><?php wp_get_archives('type=monthly&limit=4'); ?></ul>
</div>
</div>

<div id="switch3" style="display: none;">
<div id="simtag2">
<?php wp_tag_cloud('smallest=8&largest=22&number=30&orderby=count'); ?>
</div>
</div>

</div>
</div>
<?php endif; ?>
</div>
</div>