<?php get_header(); ?>

<div class="grid-control animated fadeInDown">
<div class="col-12 ">

<?php 
	$my_query = new WP_Query('showposts=1&offset=0&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="hero-block hero-block--top-gradient js-hero-video-clip hero-block--tall animated fadeInDown">
<div class="full" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>    	    
<div class="hero-block_content">

                <div class="hero-block_category sub-title"></div>
        <h1 class="hero-block_title"><?php the_title(); ?></h1>
        <div class="button-container">
	        					<a href="<?php the_permalink() ?>" class="button ljs-open-modal">
						<?php _e( 'Read Article', 'Detox') ?>					</a>
				        </div>
    </div>
</div>
<?php endwhile; ?>
</div>

<?php 
	$my_query = new WP_Query('showposts=1&offset=1');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="col-4  animated fadeIn">
<div class="feature-block js-feature-video-clip ">
<a href="<?php the_permalink() ?>" class="feature-block_link ljs-open-modal">
<div class="fill" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>  
     
        <div class="feature-block_content">
            <div class="feature-block_category sub-title"><?php the_category(' <span> | </span> '); ?></div>
        <h3 class="feature-block_title"><?php the_title(); ?></h3>
        </div>
    </a>
   
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=2');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="col-4  animated fadeIn">	
<div class="cta-block cta-block--bg-image">
<div class="fills" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div> 		
    <div class="cta-block_content">

			<h3 class="cta-block_title"><?php the_title(); ?></h3>	
      <p><?php the_content_rss('', FALSE, ' ', 10); ?></p>		
      <div class="button-container">
				<a href="<?php the_permalink() ?>" class="button"><?php _e( 'Read Article', 'Detox') ?></a>
			</div>
		</div>
    

	</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=3');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="col-4  animated fadeIn">
<div class="cta-block cta-block--bg-light">
	<div class="cta-block_content">
					<div class="cta-block_category sub-title"><?php the_category(' <span> | </span> '); ?></div>
				<h3 class="cta-block_title">“<?php the_content_rss('', FALSE, ' ', 8); ?>”</h3>				
        <p><strong><?php the_title(); ?></strong></p>
				<div class="button-container"><a href="<?php the_permalink() ?>" class="button"><?php _e( 'Read Article', 'Detox') ?></a></div>	</div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="col-4  animated fadeIn">
<div class="cta-block cta-block--theme">
	<div class="cta-block_content">
				<h3 class="cta-block_title">
       <?php the_title(); ?>
        </h3>				
        <div class="button-container"><a href="<?php the_permalink() ?>" class="button"><?php _e( 'Read Article', 'Detox') ?></a></div>	
        </div>
</div>
</div>
<?php endwhile; ?>

<div class="col-8  m-whole animated fadeIn">
<div class="feature-block ">
	<div class="feature-block_slideshow">
	
		<div class="glide__arrows">
			<span class="glide__arrow prev" data-glide-dir="&lt;"><span class="icon-left-open"></span></span>
			<span class="glide__arrow next" data-glide-dir="&gt;"><span class="icon-right-open"></span></span>
		</div>
		
		<div class="glide__wrapper">
			<ul class="glide__track">
<?php 
	$my_query = new WP_Query('showposts=8&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>      
							<li class="glide__slide">
				    <a class="feature-block_link" href="<?php the_permalink() ?>">
				        <img src="<?php if ($thumb!='') echo $thumb; ?>" class="feature-block_image js-img-swapss" alt=" <?php the_title(); ?>" />
                </a>
                	<div class="feature-block_content">
		<div class="feature-block_category sub-title"><?php the_category(' <span> | </span> '); ?></div>
		<h3 class="feature-block_title"> <?php the_title(); ?></h3>
	</div><!-- End .feature-block_content -->
		        </li>
<?php endwhile; ?>							
						</ul>
		</div>
		
	</div>
	

</div><!-- End .feature-block -->


</div>

<?php 
	$my_query = new WP_Query('showposts=1&offset=12');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="col-4 ">
<div class="feature-block">
	<a href="<?php the_permalink() ?>" class="feature-block_link">
<div class="fill" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div> 		
    <div class="feature-block_content">
								<div class="feature-block_category sub-title"><?php the_category(' <span> | </span> '); ?></div>
							<h3 class="feature-block_title"><?php the_title(); ?></h3>
		</div>
	</a>
</div>
</div>
<?php endwhile; ?>

<div class="col-4 ">
<div class="cta-block cta-block--bg-light">	<div class="cta-block_content">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('subscribe') ) : ?>
<h3 class="cta-block_title">WordPress Edition</h3>
<p>For a limited time, you can sign up for a 12 month subscription to <?php bloginfo('name'); ?> and receive a free special edition GitHub account.<b>*</b></p>
<div class="button-container"><a href="" class="button">Subscribe</a></div>
<p><br /><br /><small><b>*</b> Placeholder content</small></p>
    <?php endif; ?>
	</div><!-- End .cta-block_content -->
</div></div>

<?php 
	$my_query = new WP_Query('showposts=1&offset=13');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="col-4 ">
<div class="cta-block cta-block--bg-image">
<div class="fills" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div> 
<div class="cta-block_content">
				<h3 class="cta-block_title"><?php the_title(); ?></h3>				
        <div class="button-container"><a href="<?php the_permalink() ?>" class="button"><?php _e( 'Read Article', 'Detox') ?></a></div>	
        </div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=14');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="col-4 ">
<div class="cta-block cta-block--bg-image">
<div class="fills" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div> 
<div class="cta-block_content">
<h3 class="cta-block_title"><?php the_title(); ?></h3>
<p><?php the_category(' <span> | </span> '); ?></p>
 <div class="button-container"><a href="<?php the_permalink() ?>" class="button"><?php _e( 'Read Article', 'Detox') ?></a></div>
</div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=15');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="col-4 ">
<div class="feature-block">
	<a href="<?php the_permalink() ?>" class="feature-block_link">
<div class="fill" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div> 
    		<div class="feature-block_content">
								<div class="feature-block_category sub-title"><?php the_category(' <span> | </span> '); ?></div>
							<h3 class="feature-block_title"><?php the_title(); ?></h3>
		</div>
	</a>
</div>
</div>
<?php endwhile; ?>

<div class="col-4 ">    
<div class="cta-block cta-block--bg-light">
<div class="cta-block_content">
<?php 
	$my_query = new WP_Query('showposts=1&offset=1');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<h3 class="cta-block_title"><?php the_title(); ?></h3>
<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
<div class="button-container"><a href="<?php the_permalink() ?>" class="button"><?php _e( 'Read Article', 'Detox') ?></a></div>
<?php endwhile; ?>
</div>
</div>
</div>

<?php 
	$my_query = new WP_Query('showposts=1&offset=16');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="col-4  animated fadeIn">
<div class="feature-block js-feature-video-clip ">
<a href="<?php the_permalink() ?>" class="feature-block_link ljs-open-modal">
<div class="fill" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>  
     
        <div class="feature-block_content">
            <div class="feature-block_category sub-title"><?php the_category(' <span> | </span> '); ?></div>
        <h3 class="feature-block_title"><?php the_title(); ?></h3>
        </div>
    </a>
   
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=17');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="col-4  animated fadeIn">
<div class="cta-block cta-block--bg-light">
	<div class="cta-block_content">
					<div class="cta-block_category sub-title"><?php the_category(' <span> | </span> '); ?></div>
				<h3 class="cta-block_title">“<?php the_content_rss('', FALSE, ' ', 8); ?>”</h3>				
        <p><strong><?php the_title(); ?></strong></p>
				<div class="button-container"><a href="<?php the_permalink() ?>" class="button"><?php _e( 'Read Article', 'Detox') ?></a></div>	</div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=18');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="col-4  animated fadeIn">	
<div class="cta-block cta-block--bg-image">
<div class="fills" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div> 		
    <div class="cta-block_content">

			<h3 class="cta-block_title"><?php the_title(); ?></h3>	
      <p><?php the_content_rss('', FALSE, ' ', 10); ?></p>		
      <div class="button-container">
				<a href="<?php the_permalink() ?>" class="button"><?php _e( 'Read Article', 'Detox') ?></a>
			</div>
		</div>
    

	</div>
</div>
<?php endwhile; ?>

</div>

<?php get_footer(); ?>