<?php
/*
Template Name: blog template
*/
?>
<?php get_header(); ?>

<div id="sow">

<h1 class="serve"><?php the_title(); ?></h1>

<div class="wrapx">
<div id="content">

<div id="middle">
<?php 
	$my_query = new WP_Query('showposts=8&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="clearfix"></div><hr class="clear" />
<?php $link = get_post_meta($post->ID, 'link', true); if ($link) { ?>
<h3><a title="<?php the_title(); ?>" href="<?php echo $link; ?>"><?php the_title(); ?></a></h3>
<?php } else { ?>
<h3><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<?php } ?>
<div class="content-title">
            <?php the_category(' <span>/</span> '); ?>
            <a href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;t=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="f" title="Share on Facebook"></a>
            <a href="http://twitter.com/home?status=<?php the_title(); ?> <?php echo getTinyUrl(get_permalink($post->ID)); ?>" target="_blank" class="t" title="Spread the word on Twitter"></a>
            <a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" class="di" title="Bookmark on Del.icio.us"></a>
            <a href="http://stumbleupon.com/submit?url=<?php the_permalink() ?>&amp;title=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="su" title="Share on StumbleUpon"></a>
</div>
<div class="entry">
<div class="alignleft"><a href="<?php the_permalink() ?>"><?php $img = get_the_post_thumbnail($post->ID, 'browse'); ?><?php echo $img; ?></a></div> 
<?php the_content_rss('', FALSE, ' ', 12); ?>
</div>

<div class="clearfix"></div><hr class="clear" />
<?php endwhile; ?>

</div>

<?php get_template_part('bar'); ?>
</div>

</div>
</div>
</div>
<?php get_footer(); ?>