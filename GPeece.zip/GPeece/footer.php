<footer class="global-footer grid-control">

<div class="col-4">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column1') ) : ?>

<h3><?php _e( 'Topi', 'Detox') ?><span><?php _e( 'cs', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_list_categories('orderby=name&show_count=0&title_li=&number=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>

<div class="col-4">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column2') ) : ?>

<h3><?php _e( 'Page', 'Detox') ?><span><?php _e( 's', 'Detox') ?></span></h3>
<ul>
  <?php wp_list_pages('sort_column=menu_order&title_li=&number=8'); ?>
</ul>

<?php endif; ?>
</div>

<div class="col-4">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column3') ) : ?>

<h3><?php _e( 'Pop', 'Detox') ?><span><?php _e( 'ular', 'Detox') ?></span></h3>

<ul id="popular-comments">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>

<li>
<?php the_title(); ?> <small>&#38; <?php comments_popup_link('No Comments;', '1 Comment', '% Comments'); ?></small>
</li>

<?php endwhile; ?>
</ul>


<?php endif; ?>
</div>

<hr>
<div class="col-12">
<h1><a href="<?php echo get_settings('home'); ?>/" class="global-footer_link-logo"><?php bloginfo('name'); ?></a></h1>
<p><?php bloginfo('description'); ?></p>

<p style="font-size:10px!important"><a href="<?php echo get_settings('home'); ?>/"  class="no-link" ><?php _e( 'Copyright', 'Detox') ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?></a> 
<a class="no-link" href="https://3oneseven.com/">Website design by milo</a>
<br /><div id="gnavigation" style="font-size:10px"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/gpeece-magazine-theme/" >Themes</a> <span style="color:#ccc">GPeece theme</span>
</span>
</span>
</span>
</div>
</p>
</div>

</footer>	
</div>

<?php wp_footer(); ?>
<script type="text/javascript">
var scrolltotop={
	setting: {startline:100, scrollto: 0, scrollduration:1000, fadeduration:[500, 100]},
	controlHTML: '<div class="fa sfa-search fa-lg" style="font-size:19px;">&uarr;</div>', 
	controlattrs: {offsetx:5, offsety:40}, 
	anchorkeyword: '#top', 
	state: {isvisible:false, shouldvisible:false},
	scrollup:function(){
		if (!this.cssfixedsupport) 
			this.$control.css({opacity:0}) 
		var dest=isNaN(this.setting.scrollto)? this.setting.scrollto : parseInt(this.setting.scrollto)
		if (typeof dest=="string" && jQuery('#'+dest).length==1) 
			dest=jQuery('#'+dest).offset().top
		else
			dest=0
		this.$body.animate({scrollTop: dest}, this.setting.scrollduration);
	},
	keepfixed:function(){
		var $window=jQuery(window)
		var controlx=$window.scrollLeft() + $window.width() - this.$control.width() - this.controlattrs.offsetx
		var controly=$window.scrollTop() + $window.height() - this.$control.height() - this.controlattrs.offsety
		this.$control.css({left:controlx+'px', top:controly+'px'})
	},
	togglecontrol:function(){
		var scrolltop=jQuery(window).scrollTop()
		if (!this.cssfixedsupport)
			this.keepfixed()
		this.state.shouldvisible=(scrolltop>=this.setting.startline)? true : false
		if (this.state.shouldvisible && !this.state.isvisible){
			this.$control.stop().animate({opacity:1}, this.setting.fadeduration[0])
			this.state.isvisible=true
		}
		else if (this.state.shouldvisible==false && this.state.isvisible){
			this.$control.stop().animate({opacity:0}, this.setting.fadeduration[1])
			this.state.isvisible=false
		}
	},	
	init:function(){
		jQuery(document).ready(function($){
			var mainobj=scrolltotop
			var iebrws=document.all
			mainobj.cssfixedsupport=!iebrws || iebrws && document.compatMode=="CSS1Compat" && window.XMLHttpRequest 
			mainobj.$body=(window.opera)? (document.compatMode=="CSS1Compat"? $('html') : $('body')) : $('html,body')
			mainobj.$control=$('<div id="topcontrol">'+mainobj.controlHTML+'</div>')
				.css({position:mainobj.cssfixedsupport? 'fixed' : 'absolute', bottom:mainobj.controlattrs.offsety, right:mainobj.controlattrs.offsetx, opacity:0, cursor:'pointer'})
				.attr({title:'back to top'})
				.click(function(){mainobj.scrollup(); return false})
				.appendTo('body')
			if (document.all && !window.XMLHttpRequest && mainobj.$control.text()!='') 
				mainobj.$control.css({width:mainobj.$control.width()}) 
			mainobj.togglecontrol()
			$('a[href="' + mainobj.anchorkeyword +'"]').click(function(){
				mainobj.scrollup()
				return false
			})
			$(window).bind('scroll resize', function(e){
				mainobj.togglecontrol()
			})
		})
	}
}
scrolltotop.init()
</script>


   

</body>
</html>