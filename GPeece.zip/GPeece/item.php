<div id="item">
<div id="slider">
<ul>
<li>
<div class="simg"></div>

<div class="itemtxt">
<h2><a title="GPeece portfolio theme" href="http://3oneseven.com/gpeece-portfolio-theme/">GPeece portfolio theme</a></h2>
<p>Beautiful portfolio theme with clean grid design, jParallax effect , built-in custom fonts, tabbed frontpage with custom jQuery slider
Featuring on a two column responsive width layout.</p>

</div>
</li>
<?php 
	$my_query = new WP_Query('showposts=4&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<li>
<div class="simg"></div>

<div class="itemtxt">
<h2><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<p><?php the_content_rss('', FALSE, ' ', 24); ?></p>

</div>
</li>
<?php endwhile; ?>

</ul>
</div>
</div>