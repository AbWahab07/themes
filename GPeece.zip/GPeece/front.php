<div class="mews">

<?php 
	$my_query = new WP_Query('showposts=3&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="col22">
<div class="entry">
<h3><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<p><?php the_content_rss('', FALSE, ' ', 12); ?></p>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'slider');
}
?>
<div class="slideimg"><img itemprop="image" property="contentURL" src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=1&offset=7');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="col23">
<div class="entry">
<h3><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<p><?php the_content_rss('', FALSE, ' ', 12); ?></p>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'slider');
}
?>
<div class="slideimg"><img itemprop="image" property="contentURL" src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></div>
</div>
</div>
<?php endwhile; ?>

<div class="clearfix"></div><hr class="clear" />

</div>