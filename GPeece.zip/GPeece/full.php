<?php
/*
Template Name: full width template
*/
?>
<?php get_header(); ?>

<div id="sow">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h1 class="serve"><?php the_title(); ?></h1>

<div class="wrap">
<div id="content">

<div class="entry">

<div class="gal">

<ul class="tabs center">
<li><a href="#tabr1">Gallerie</a></li>
<li><a href="#tabr2">Karte</a></li>
</ul>

<div id="tabr1" class="tab-content">
<?php the_content(__('Read more'));?>

<div id="gallery">
<div id="slider1" class="sliderwrapper">

<?php
$attachments = get_children(array('post_parent' => $post->ID,
						'post_status' => 'inherit',
						'post_type' => 'attachment',
						'post_mime_type' => 'image',
						'order' => 'ASC',
						'orderby' => 'menu_order ID'));
foreach($attachments as $att_id => $attachment) {
	$full_img_url = wp_get_attachment_url($attachment->ID);
        $split_pos = strpos($full_img_url, 'wp-content');
        $split_len = (strlen($full_img_url) - $split_pos);
        $abs_img_url = substr($full_img_url, $split_pos, $split_len);
        $full_info = @getimagesize(ABSPATH.$abs_img_url);
        ?>
<div class="contentdiv">
<div class="slideimg">
<img src="<?php echo $full_img_url; ?>" alt="<?php the_title(); ?>" />
</div>
</div>
<?php
}
?>

<div id="paginate-slider1" class="pagination"></div>
<script type="text/javascript">
featuredcontentslider.init({
id: "slider1", 
contentsource: ["inline", ""], 
toc: "#increment", 
nextprev: ["", ""], 
revealtype: "mouseover", 
enablefade: [true, 0.6], 
autorotate: [true, 6000], 
onChange: function(previndex, curindex){ 
}
})
</script>
</div>
</div>
</div>

<div id="tabr2" class="tab-content">
<?php $map = get_post_meta($post->ID, 'map', true); if ($map) { ?>
<?php echo $map; ?><?php } else { ?><h3>Leider keine Karte.</h3><?php } ?>
</div>

</div>
<h3><?php edit_post_link('Edit','',''); ?></h3>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>

<div class="clearfix"></div><hr class="clear" />
<img src="/wp-content/themes/gala/images/gala-leistungen.jpg" alt="gala natur" class="aligncenter" />
</div>

</div>
</div>
</div>
<?php get_footer(); ?>