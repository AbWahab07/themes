<div id="featured">
<span class="mackys"><?php _e('For your consideration', 'Detox'); ?></span>
<h4><?php _e('Featured', 'Detox'); ?></h4> 
 		
<div id="slider1" class="sliderwrapper">

<?php 
	$my_query = new WP_Query('showposts=6');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="contentdiv">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'browse');
}
?>

<div class="roll">
<a class="thumb" href="<?php the_permalink() ?>"><img src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></a>
</div>

<div class="text">
<span class="macky"><?php the_category(', ') ?></span>
<h4><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h4>
<?php the_excerpt(__('', 'Detox'));?>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
</div>

</div>

<?php endwhile; ?>

<div id="paginate-slider1" class="pagination"></div>
<script type="text/javascript">
featuredcontentslider.init({
id: "slider1", 
contentsource: ["inline", ""], 
toc: "#increment", 
nextprev: ["", ""], 
revealtype: "mouseover", 
enablefade: [true, 0.6], 
autorotate: [true, 12500], 
onChange: function(previndex, curindex){ 
}
})
</script>

</div>

</div>