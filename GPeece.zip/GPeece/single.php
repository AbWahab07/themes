<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="hero-block hero-block--top-gradient js-hero-video-clip hero-block--tall animated fadeInDown">
<div class="full" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>    	    
<div class="hero-block_content">
<div class="hero-block_category sub-title"></div>
<h1 class="hero-block_title"><?php the_title(); ?></h1>
<div class="button-container">
<?php the_category(' <span> | </span> '); ?>
</div>
</div>
</div>

<div class="col-12  pm-whole animated fadeInDown">
<div class="content-block ">
<div class="content-block_width-control">

<div class="wrapx">
<div id="content">

<div id="middle">


<div class="entry">
<?php the_content(__('Read more'));?>
<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
<div class="clearfix"></div><hr class="clear" />
<h3><?php edit_post_link('Edit','',''); ?></h3>
</div>

<div class="postspace"></div>

<div class="single_blog_post_tags margbot50" data-animated="fadeInUp">

<div class="sidepanel widget_info">							
<ul class="shared pull-right">
								<li><a href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink(); ?>" ><i class="fa fa-twitter"></i></a></li>
								<li><a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" ><i class="fa fa-facebook"></i></a></li>
								<li><a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>" ><i class="fa fa-pinterest-square"></i></a></li>
</ul>
</div>

<div class="sowl-demo sowl-carousel sowl-theme">              
<div class="sowl-controls clickable container sowl-theme">
<div class="sowl-buttons">
<?php
                    $prev_post = get_adjacent_post(false, '', true);
                    $next_post = get_adjacent_post(false, '', false); ?>
<?php if ($prev_post) : $prev_post_url = get_permalink($prev_post->ID); $prev_post_title = $prev_post->post_title; ?>
<div class="sowl-prev"><a href="<?php echo $prev_post_url; ?>"><em>Previous post</em></a></div>
<?php endif; ?>
<?php if ($next_post) : $next_post_url = get_permalink($next_post->ID); $next_post_title = $next_post->post_title; ?>
<div class="sowl-next"><a href="<?php echo $next_post_url; ?>"><em>Next post</em></a></div>
   <?php endif; ?>
</div>
</div>
</div>

</div>

</div>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>       
 <?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>
<div class="clearfix"></div><hr class="clear" />

</div>
<?php get_template_part('bar'); ?>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>