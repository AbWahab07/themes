<?php get_header(); ?>

<div class="dotmag-control dotmag-control--article animated fadeInDown">
<div class="grid-control"><div class="col-12 ">
<div class="dotmag-header dotmag-header--bottom-border">
<h3>Search</h3>
</div>
</div>
</div>
</div>

<div class="col-12s">

<?php if (have_posts()) : ?>

<div class="content-block ">
<div class="content-block_width-control">
<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
<?php /* If this is a category archive */ if (is_category()) { ?>
<h1 class="serve"><?php echo single_cat_title(); ?> <?php _e('Article'); ?></h1>
<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
<h1 class="serve"><?php _e('Archive'); ?> <?php the_time('F jS, Y'); ?></h1>
<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
<h1 class="serve"><?php _e('Archive'); ?> <?php the_time('F, Y'); ?></h1>
<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
<h1 class="serve"><?php _e('Archive'); ?> <?php the_time('Y'); ?></h1>
<?php /* If this is an author archive */ } elseif (is_author()) { ?>
<h1 class="serve"><?php _e('Author Archive'); ?></h1>
<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
<h1 class="serve"><?php _e('Archive'); ?></h1>
<?php } ?>
</div>
</div>

<div class="wrapx">
<div id="content">

<div id="middle">

<?php while (have_posts()) : the_post(); ?>

<div class="col-4  animated fadeIn">
<div class="cta-block cta-block--bg-image">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="fills" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>  
<div class="cta-block_content">

<div class="content-title"><?php the_category(' <span>/</span> '); ?></div>
<h3 class="cta-block_title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>

<div class="entry">
<p><?php the_content_rss('', FALSE, '', 14); ?></p>
</div>

<div class="button-container">
<a class="button" href="<?php the_permalink() ?>" title="<?php _e('Read on'); ?>"><?php _e('Read on'); ?></a>
</div>

</div>
</div>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?> 

<div class="clearfix"></div><hr class="clear" />
<div class="navigation">
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
</div>

</div>

</div>
</div>
 
</div>
</div>
<?php get_footer(); ?>