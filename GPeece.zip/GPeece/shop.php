<div id="featured">
<span class="mackys"><?php _e('For your consideration', 'Detox'); ?></span>
<h4><?php _e('Featured', 'Detox'); ?></h4> 
 		
<div id="slider1" class="sliderwrapper">

<?php $loop = new WP_Query( array( 'post_type' => 'product', 'posts_per_page' => 6 ) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>

<div class="contentdiv">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'browse');
}
?>

<div class="roll">
<a class="thumb" href="<?php the_permalink() ?>"><img src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></a>
</div>

<div class="text">
<span class="macky"><?php echo $product->get_categories( ', ', '<span class="posted_in">' . _n( '', '', sizeof( get_the_terms( $post->ID, 'product_cat' ) ), 'woocommerce' ) . ' ', '.</span>' ); ?></span>
<h4><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h4>
<?php echo apply_filters( 'woocommerce_short_description', $post->post_excerpt ) ?>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('View item', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
</div>

</div>

<?php endwhile; wp_reset_query(); ?>

<div id="paginate-slider1" class="pagination"></div>
<script type="text/javascript">
featuredcontentslider.init({
id: "slider1", 
contentsource: ["inline", ""], 
toc: "#increment", 
nextprev: ["", ""], 
revealtype: "mouseover", 
enablefade: [true, 0.6], 
autorotate: [true, 12500], 
onChange: function(previndex, curindex){ 
}
})
</script>

</div>

</div>