<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="dotmag-control dotmag-control--article animated fadeInDown">
<div class="grid-control"><div class="col-12 ">
<div class="dotmag-header dotmag-header--bottom-border">
<h3>You are here: <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?></h3>
</div>
</div>
</div>
</div>

<div class="col-12">
<div class="content-block ">
<div class="content-block_width-control">
<h1 class="serve"><?php the_title(); ?></h1>

<div class="wrapx">
<div id="content">

<div id="middle">

<div class="entry">
<?php the_content(__('Read more'));?>
<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
<div class="clearfix"></div><hr class="clear" />
<h3><?php edit_post_link('Edit','',''); ?></h3>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>

<div class="clearfix"></div><hr class="clear" />
</div>

<?php get_template_part('bar'); ?>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>