<?php get_header(); ?>

<section class="app-brief grey-bg" id="concept">

<div class="container">
	
	<div class="row">
		
		<div class="col-md-6 wow fadeInRight animated" data-wow-offset="10" data-wow-duration="1.5s">
			<div class="phone-image">
				<?php $aOptions = DarkHorizon::initOptions(false); ?>
        <img src="<?php echo($aOptions['featured5-image']); ?>" alt="<?php echo($aOptions['featured5-title']); ?>" />
			</div>
		</div>

		<div class="col-md-6 left-align wow fadeInLeft animated" data-wow-offset="10" data-wow-duration="1.5s">

			<h2 class="dark-text"><?php echo($aOptions['featured5-title']); ?></h2>
			
			<div class="colored-line-left">
			</div>
			
			<p><?php echo($aOptions['featured5-desc']); ?></p>
			
<div class="buttons" id="download-button">
<a href="<?php echo($aOptions['featured5-link']); ?>" class="btn btn-default btn-lg standard-button"><?php echo($aOptions['featured5-text']); ?></a>
</div>

		</div>

		
	</div>

	
</div>

</section>

<section class="screenshots grey-bg" id="shop">

<div class="container">
	
	<div class="section-header wow fadeIn animated" data-wow-offset="10" data-wow-duration="1.5s">
		
		<h2 class="dark-text"><?php echo($aOptions['featured6-title']); ?></h2>
		
		<div class="colored-line">
		</div>
		<div class="section-description">
		<?php echo($aOptions['featured6-desc']); ?>
		</div>
		<div class="colored-line">
		</div>
		
	</div>
	
	<div class="row wow bounceIn animated" data-wow-offset="10" data-wow-duration="1.5s">
		
<?php
/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('shop');
} else {
get_template_part('blog');
}
?>
		
	</div>
	
</div>

</section>

<section class="app-brief" id="abouts">

<div class="container">
	
	<div class="row">

		<div class="col-md-6 left-align wow fadeInLeft animated" data-wow-offset="10" data-wow-duration="1.5s">

			<h2 class="dark-text"><?php echo($aOptions['featured8-title']); ?></h2>
			
			<div class="colored-line-left">
			</div>
			
			<p><?php echo($aOptions['featured8-desc']); ?></p>
			
      <div class="buttons" id="download-button">
<a href="<?php echo($aOptions['featured8-link']); ?>" class="btn btn-default btn-lg standard-button"><?php echo($aOptions['featured8-text']); ?></a>
</div>
		</div>

		<div class="col-md-6 wow fadeInRight animated" data-wow-offset="10" data-wow-duration="1.5s">
			<div class="phone-image">
				<img src="<?php echo($aOptions['featured8-image']); ?>" alt="<?php echo($aOptions['featured8-title']); ?>" />
			</div>
		</div>
		
	</div>
	
</div>

</section>

<section class="testimonials" id="news">

<div class="color-overlay">
	
	<div class="container wow fadeIn animated" data-wow-offset="10" data-wow-duration="1.5s">
		
		<div id="feedbacks" class="owl-carousel owl-theme">
 	  <div id="slider1" class="sliderwrapper">
			<?php 
	$my_query = new WP_Query('showposts=4&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
			<div class="contentdiv"> 
      <div class="feedback">

				<div class="image">
					<img src="https://milo317.com/wp-content/uploads/2013/07/modern-red-hair.jpg" alt="milo" />
				</div>
				
				<div class="message">
					<?php the_content_rss('', FALSE, '', 54); ?>
          </div>
				
				<div class="white-line">
				</div>
				
				<div class="name">
					<?php printf( esc_attr__( '%s' ), get_the_author() ); ?>
				</div>
				<div class="company-info">
				<a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
				</div>
				
			</div>
      </div>
               
<?php endwhile; ?>                                           
<div id="paginate-slider1" class="pagination"></div>
<script type="text/javascript">featuredcontentslider.init({id: "slider1", contentsource: ["inline", ""], toc: "#increment", nextprev: ["", ""], revealtype: "mouseover", enablefade: [true, 0.9], autorotate: [true, 9000], onChange: function(previndex, curindex){ }})</script>
			
		</div>
    </div>
		
	</div>
	
</div>

</section>

<section class="app-brief grey-bg" id="about">

<div class="container">
	
	<div class="row">

		<div class="col-md-6 wow fadeInRight animated" data-wow-offset="10" data-wow-duration="1.5s">
			<div class="video-container">
								
				<div class="video">
					
					<img src=<?php echo($aOptions['featured4-text']); ?>" alt="darkhorizon" />
				</div>
				
			</div>

		</div>

		<div class="col-md-6 left-align wow fadeInLeft animated" data-wow-offset="10" data-wow-duration="1.5s">

			<h2 class="dark-text"><?php echo($aOptions['featured4-title']); ?></h2>
			
			<div class="colored-line-left">
			</div>
			
			<p>
			<?php echo($aOptions['featured4-desc']); ?>
			</p>
			         <div class="buttons" id="download-button">
<a href="<?php echo($aOptions['featured4-link']); ?>" class="btn btn-default btn-lg standard-button">More</a>
</div>
			
		</div>
		
	</div>
	
</div>

</section>

<?php get_footer(); ?>