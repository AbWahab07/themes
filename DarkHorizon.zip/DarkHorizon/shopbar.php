<div id="shopbar">

<div class="scol1">
<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('shopbar1') ) : ?>
	        
<h3>Widgetized area</h3>
<ul>
<li><a title="Follow on Twitter" href="http://twitter.com/milo317">Twitter</a></li>
<li><a title="Follow on Facebook" href="http://www.facebook.com/milo317">Facebook</a></li> 
<li><a href="http://milo317.com/">milo317</a></li>
</ul>
        
<?php endif; ?>
</div>

<div class="scol2">
<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('shopbar2') ) : ?>
	        
<h3>Widgetized area</h3>
<ul>
<li><a rel="nofollow" href="mailto:milo@3oneseven.com" title="Email me">3oneseven</a></li>
<li><a href="http://goo.gl/AAoFS" title="View on maps">Echinger str 80805 Munich | Germany</a></li>
<li><a rel="nofollow" href="tel:+49 173 4298898" title="Phone through">+49 173 4298898</a></li>
</ul>
          
<?php endif; ?>
</div>

</div>