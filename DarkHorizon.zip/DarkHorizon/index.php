<?php
/*
Template Name: index
*/
?>
<?php get_header(); ?>

<div id="content" role="main">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="col7 animated fadeIn">

<figure class="effect-layla">  
<div class="xxframe view view-first">
<a href="<?php the_permalink(); ?>">
<div class="xxy xk1" >
<?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'xsliders'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/sl/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</div>

<figcaption>
<div class="xdetails mask">
<h2><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
<div class="xlistview">
<p ><?php the_content_rss('', FALSE, '', 14); ?></p>
<form action="<?php the_permalink(); ?>" method="post" class="shopp productz">
<h4 class="addtocart"><?php _e('View more', 'Detox') ?></h4>
</form> 
</div>
</div>
</figcaption>
</a>
</div>
</figure>

<div class="xcenter">
<div class="ycenter">
<h4 itemprop="name"><a itemprop="url" href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
</div>
</div>

</div>

<?php endwhile; endif; ?>

<hr class="clear" /><div class="postspace"></div>
<div class="navigation">
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
</div>
</div>

<?php get_footer(); ?>