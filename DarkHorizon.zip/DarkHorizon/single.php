<?php
/*
Template Name: single
*/
?>
<?php get_header(); ?>

<div id="content" role="main">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="content-title">
            <?php the_category(' <span>/</span> '); ?>
           
</div>

<h1><?php the_title(); ?></h1>

<div class="entry">

<div id="sent">
<?php the_content(__('Read more'));?>
<div class="clearfix"></div><hr class="clear" />
<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
<h3><?php edit_post_link('Edit','',''); ?></h3>
</div>

<div id="sidebar">
<div class="scol1">
<div class="post-date">
<span class="post-day"><?php the_time('d') ?></span>
<span class="post-month"><?php the_time('M') ?></span> 
<span class="post-day"><?php comments_number('{0}', '{1}', '{%}' );?></span>
<span class="post-tags"><?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "Tags: None";} }?>
<?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?></span>
</div>
</div>

<div class="scol2">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebar') ) : ?>
<h3>Widgetized area</h3>
<ul>
<li><a title="Follow on Twitter" href="http://twitter.com/milo317">Twitter</a></li>
<li><a title="Follow on Facebook" href="http://www.facebook.com/milo317">Facebook</a></li> 
<li><a href="http://milo317.com/">milo317</a></li>
</ul>

<?php endif; ?>
</div>
</div>
</div>

<hr class="clear" />

<div class="postspace"></div>

<div class="meta">
<div class="scol1">
<div class="rel">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('about') ) : ?>
<?php if ( get_the_author_meta( 'description' ) ) :  ?>
<div class="author-avatar alignright">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 90 ) ); ?>
</div>

<div id="author-description">
<h4><?php printf( esc_attr__( 'About %s', 'Bruce' ), get_the_author() ); ?> :</h4>
<?php the_author_meta( 'description' ); ?> | <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'View all posts by %s <span class="meta-nav">&rarr;</span>', 'Bruce' ), get_the_author() ); ?></a>
</div>
<?php endif; ?>
<?php endif; ?>
</div>
</div>

<div class="scol2">
<div class="rell">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('related') ) : ?>
<h4>Related Posts</h4>
<?php 
$max_articles = 4; // How many articles to display 
echo '<ul class="list columns">'; 
$cnt = 0; $article_tags = get_the_tags(); 
$tags_string = ''; 
if ($article_tags) { 
foreach ($article_tags as $article_tag) { 
$tags_string .= $article_tag->slug . ','; 
} 
} 
$tag_related_posts = get_posts('exclude=' . $post->ID . '&numberposts=' . $max_articles . '&tag=' . $tags_string); 
if ($tag_related_posts) { 
foreach ($tag_related_posts as $related_post) { 
$cnt++; 
echo '<li class="child-' . $cnt . '">'; 
echo '<a href="' . get_permalink($related_post->ID) . '">'; 
echo $related_post->post_title . '</a></li>'; 
} 
} 
if ($cnt < $max_articles) { 
$article_categories = get_the_category($post->ID); 
$category_string = ''; 
foreach($article_categories as $category) { 
$category_string .= $category->cat_ID . ','; 
} 
$cat_related_posts = get_posts('exclude=' . $post->ID . '&numberposts=' . $max_articles . '&category=' . $category_string); 
if ($cat_related_posts) { 
foreach ($cat_related_posts as $related_post) { 
$cnt++; 
if ($cnt > $max_articles) break; 
echo '<li class="child-' . $cnt . '">'; 
echo '<a href="' . get_permalink($related_post->ID) . '">'; 
echo $related_post->post_title . '</a></li>'; 
} 
} 
} 
echo '</ul>'; 
?>
<?php endif; ?>
</div>
</div>
</div>

<div class="post-navigation clear">
                <?php
                    $prev_post = get_adjacent_post(false, '', true);
                    $next_post = get_adjacent_post(false, '', false); ?>
                    <?php if ($prev_post) : $prev_post_url = get_permalink($prev_post->ID); $prev_post_title = $prev_post->post_title; ?>
                        <a class="post-prev" href="<?php echo $prev_post_url; ?>"><em>Previous post</em><span><?php echo $prev_post_title; ?></span></a>
                    <?php endif; ?>
                    <?php if ($next_post) : $next_post_url = get_permalink($next_post->ID); $next_post_title = $next_post->post_title; ?>
                        <a class="post-next" href="<?php echo $next_post_url; ?>"><em>Next post</em><span><?php echo $next_post_title; ?></span></a>
                    <?php endif; ?>
                
</div>

<?php get_template_part('shopbar'); ?>
<?php endwhile; endif; ?>

 <?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>

</div>
<?php get_footer(); ?>