<?php get_header(); ?>

<div id="content" role="main">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="content-title">
            <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
            <a href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;t=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="f" title="Share on Facebook"></a>
            <a href="http://twitter.com/home?status=<?php the_title(); ?> <?php the_permalink() ?>" target="_blank" class="t" title="Spread the word on Twitter"></a>
            <a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" class="di" title="Bookmark on Del.icio.us"></a>
            <a href="http://stumbleupon.com/submit?url=<?php the_permalink() ?>&amp;title=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="su" title="Share on StumbleUpon"></a>
</div>

<h1><?php the_title(); ?></h1>

<div class="entry">
<?php the_content('', ''); ?>
<div class="clearfix"></div><hr class="clear" />
<?php link_pages('<h4><strong>Pages:</strong> ', '</h4>', 'number'); ?>
</div>
<hr class="clear" />
<?php get_template_part('shopbar'); ?>
<?php endwhile; endif; ?>

<div class="post-navigation clear">
<?php breadcrumb(); ?>
</div>

</div>

<?php get_footer(); ?>