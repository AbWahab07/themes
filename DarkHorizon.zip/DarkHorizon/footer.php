<section class="download" id="contact">

<div class="color-overlay">

	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">

				<div class="download-container">
					<h2 class=" wow fadeInLeft animated" data-wow-offset="10" data-wow-duration="1.5s"><?php _e('Get in touch', 'Detox') ?></h2>

					<div class="buttons wow fadeInRight animated" data-wow-offset="10" data-wow-duration="1.5s">
						
						<a href="<?php echo($aOptions['featured9-text']); ?>" class="btn btn-default btn-lg standard-button"><?php _e('Twitter', 'Detox') ?></a>
						<a href="<?php echo($aOptions['featured91-text']); ?>" class="btn btn-default btn-lg standard-button"><?php _e('Facebook', 'Detox') ?></a>
						
					</div>
					
				</div>
				
				<div class="subscription-form-container">
					
					<h2 class="wow fadeInLeft animated" data-wow-offset="10" data-wow-duration="1.5s"><?php _e('Subscribe Now!', 'Detox') ?></h2>

					<form class="subscription-form mailchimp form-inline wow fadeInRight animated" data-wow-offset="10" data-wow-duration="1.5s" role="form">
						
						<h4 class="subscription-success"></h4>
						<h4 class="subscription-error"></h4>
						
<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('suscribe') ) : ?>
						<input type="email" name="email" id="subscriber-email" placeholder="Your Email" class="form-control input-box">
						<button type="submit" id="subscribe-button" class="btn btn-default standard-button"><?php _e('Subscribe', 'Detox') ?></button>
<?php endif; ?>
						
					</form>

				

				</div>
				
			</div> 
			
		</div> 
    
	</div>
</div>

</section>
<div id="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">

<div class="container">
	
	<div class="contact-box wow rotateIn animated" data-wow-offset="10" data-wow-duration="1.5s">
		
		
<div class="row expanded-contact-form">
			
			<div class="col-md-8 col-md-offset-2">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('email') ) : ?>
          
<form class="contact-form" id="contact" role="form">
					
					<!-- IF MAIL SENT SUCCESSFULLY -->
					<h4 class="success">
						<i class="icon_check"></i> Your message has been sent successfully.
					</h4>
					
					<!-- IF MAIL SENDING UNSUCCESSFULL -->
					<h4 class="error">
						<i class="icon_error-circle_alt"></i> E-mail must be valid and message must be longer than 1 character.
					</h4>
					
					<div class="col-md-6">
						<input class="form-control input-box" id="name" type="text" name="name" placeholder="Your Name">
					</div>
					
					<div class="col-md-6">
						<input class="form-control input-box" id="email" type="email" name="email" placeholder="Your Email">
					</div>
					
					<div class="col-md-12">
						<input class="form-control input-box" id="subject" type="text" name="subject" placeholder="Subject">
						<textarea class="form-control textarea-box" id="message" rows="8" placeholder="Message"></textarea>
					</div>
					
					<button class="btn btn-primary standard-button2 ladda-button" type="submit" id="submit" name="submit" data-style="expand-left">Send Message</button>
					
				</form>

<?php endif; ?>
				
			</div>
			
		</div>

		
	</div>

  <?php $aOptions = DarkHorizon::initOptions(false); ?>
	<img src="<?php echo($aOptions['featured2-image']); ?>" alt="<?php bloginfo('name'); ?>" class="responsive-img" />

	<ul class="social-icons">
		<li><a href="<?php echo($aOptions['featured91-text']); ?>"><i class="social_facebook_square"></i></a></li>
		<li><a href="<?php echo($aOptions['featured9-text']); ?>"><i class="social_twitter_square"></i></a></li>
		<li><a href="<?php echo($aOptions['featured92-text']); ?>"><i class="social_pinterest_square"></i></a></li>
		<li><a href="<?php echo($aOptions['featured93-text']); ?>"><i class="social_instagram_square"></i></a></li>
	</ul>

	<p class="copyright">
		&copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> <span><?php bloginfo('description'); ?></span> | <a class="no-link" href="https://3oneseven.com/">Website design by milo</a>
<br /><div id="gnavigation" style="font-size:10px"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/horizon-ecommerce-theme/" >Theme</a> <span>Horizon theme</span>
</span>
</span>
</span>
</div>
	</p>

</div>

</div>

<?php do_action('wp_footer'); ?>

<?php if ( (is_home())  ) { ?>
<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/smoothscroll.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.scrollTo.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.localScroll.min.js" type="text/javascript"></script>

<script src="<?php echo get_template_directory_uri(); ?>/js/wow.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.stellar.min.js" type="text/javascript"></script>

<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.nav.js" type="text/javascript"></script>



<script src="<?php echo get_template_directory_uri(); ?>/js/custom.js" type="text/javascript"></script>
<?php } else { ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript" ></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/smoothscroll.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.scrollTo.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.localScroll.min.js" type="text/javascript"></script>

<script src="<?php echo get_template_directory_uri(); ?>/js/wow.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.stellar.min.js" type="text/javascript"></script>

<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.nav.js" type="text/javascript"></script>

<script src="<?php echo get_template_directory_uri(); ?>/js/custom.js" type="text/javascript"></script>
<?php } ?>
<script src="<?php echo get_template_directory_uri(); ?>/js/instant.js" type="text/javascript"></script>


</body>
</html>