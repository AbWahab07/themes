<div id="shopp"  class="shoppage shopp_page grid shopp_grid-3 catalog">
<div class="category">
<?php shopp( 'storefront.catalog-products' ); ?>
</div>
</div>