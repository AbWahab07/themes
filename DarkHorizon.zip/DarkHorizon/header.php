<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<?php $aOptions = DarkHorizon::initOptions(false); ?>
<link rel="shortcut icon" type="image/ico" href="<?php echo($aOptions['featured1-image']); ?>" />
<style type="text/css">
#header,.download{background:transparent url(<?php echo($aOptions['featured3-image']); ?>) no-repeat center top fixed;-webkit-background-size: cover;background-size: cover;}
.testimonials{background:transparent url(<?php echo($aOptions['featured3-image']); ?>) no-repeat center fixed;-webkit-background-size: cover;background-size: cover;}
</style>
<!--[if lte IE 7]><script src="<?php echo get_template_directory_uri(); ?>/lte-ie7.js"></script><![endif]-->
<link href='https://fonts.googleapis.com/css?family=Roboto:100,300,100italic,400,300italic' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/styles.css" />


<?php wp_head(); ?>        

<!--[if lt IE 9]><script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/html5shiv.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/respond.min.js"></script><![endif]-->
<?php if ( (is_home())  ) { ?>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/contentslider.js"></script>
<?php } else { ?>
<?php } ?>
</head>
<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="http://schema.org/WebPage">

<div class="preloader">
<div class="status">&nbsp;</div>
</div>

<?php if ( (is_home())  ) { ?>
<div id="header" class="header" data-stellar-background-ratio="0.5" id="home" style="background-position: 50% 0px;" role="banner" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<div class="color-overlay">

	<div class="navbar navbar-inverse bs-docs-nav navbar-fixed-top sticky-navigation">
		<div class="container">
			<div class="navbar-header">

				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#kane-navigation">
				<span class="sr-only"><?php _e('Toggle navigation', 'Detox') ?></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
        
        <?php $aOptions = DarkHorizon::initOptions(false); ?>
				<a class="navbar-brand" href="#"><img src="<?php echo($aOptions['featured2-image']); ?>" alt="<?php bloginfo('name'); ?>" /></a>
				
			</div>

			<div class="navbar-collapse collapse" id="kane-navigation">
				<ul class="nav navbar-nav navbar-right main-navigation">
					<li><a href="#home"><?php _e('Home', 'Detox') ?></a></li>
					<li><a href="#concept"><?php _e('Concept', 'Detox') ?></a></li>
          <li><a href="#shop"><?php _e('Shop', 'Detox') ?></a></li>
          <li><a href="#news"><?php _e('News', 'Detox') ?></a></li>
          	<li><a href="#about"><?php _e('About', 'Detox') ?></a></li>
					
				</ul>
			</div>
		</div> 
	</div> 
  
	<div class="container">

		<div class="only-logo">
			<div class="navbar">
				<div class="navbar-header">
					<?php $aOptions = DarkHorizon::initOptions(false); ?>
          <img src="<?php echo($aOptions['featured2-image']); ?>" alt="<?php bloginfo('name'); ?>" />
				</div>
			</div>
		</div> 
		
		<div class="row">
			<div class="col-md-8 col-md-offset-2">

				<div class="intro-section">

					<h1 class="intro"><?php echo($aOptions['featured1-title']); ?></h1>
					<h5><?php echo($aOptions['featured1-desc']); ?></h5>

					<div class="buttons" id="download-button">
						
						<a href="<?php echo($aOptions['featured1-link']); ?>" class="btn btn-default btn-lg standard-button"><?php echo($aOptions['featured1-text']); ?></a>
						
					</div>
					
				</div>
				
			</div>
		</div>
		
	</div>
</div>
</div>
<?php } else { ?>
<div id="header" class="header" data-stellar-background-ratio="0.5" id="home" role="banner" itemscope="itemscope" itemtype="http://schema.org/WPHeader">

	<div class="navbar navbar-inverse bs-docs-nav navbar-fixed-top sticky-navigation">
		<div class="container">
			<div class="navbar-header">

				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#kane-navigation">
				<span class="sr-only"><?php _e('Toggle navigation', 'Detox') ?></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
        
        <?php $aOptions = DarkHorizon::initOptions(false); ?>
				<a class="navbar-brand" href="<?php echo get_settings('home'); ?>/"><img src="<?php echo($aOptions['featured2-image']); ?>" alt="<?php bloginfo('name'); ?>" /></a>
				
			</div>

			<div class="navbar-collapse collapse" id="kane-navigation">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'topnav',
'container' => '',
'container_id' => 'top',
'menu_id' => 'nav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>
			</div>
		</div> 
	</div> 
  
</div>
<?php } ?>