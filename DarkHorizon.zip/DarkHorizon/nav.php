<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'topnav',
'container' => '',
'container_id' => 'top',
'menu_id' => 'nav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>