<?php 
	$my_query = new WP_Query('showposts=3&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="col7a">
<div class="content-title">
            <?php the_category(' <span>/</span> '); ?>
            <a href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;t=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="f" title="Share on Facebook"></a>
            <a href="http://twitter.com/home?status=<?php the_title(); ?> <?php the_permalink() ?>" target="_blank" class="t" title="Spread the word on Twitter"></a>
            <a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" class="di" title="Bookmark on Del.icio.us"></a>
            <a href="http://stumbleupon.com/submit?url=<?php the_permalink() ?>&amp;title=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="su" title="Share on StumbleUpon"></a>
</div>

<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>

<div class="entry">

<div id="sent">
<div class="sleft"><a href="<?php the_permalink() ?>"><?php $img = get_the_post_thumbnail($post->ID, 'browse'); ?><?php echo $img; ?></a></div> 
<hr class="clear" />
<p><?php the_content_rss('', FALSE, '', 34); ?></p>
<h3><?php edit_post_link('Edit','',''); ?></h3>
</div>

<div id="sidebar">
<div class="post-date">
<span class="post-day"><?php the_time('d') ?></span>
<span class="post-month"><?php the_time('M') ?></span> 
<span class="post-day"><?php comments_number('{0}', '{1}', '{%}' );?></span>
<span class="post-tags"><?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "Tags: None";} }?>
<?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?></span>
</div>
</div>

</div>

</div>

<?php endwhile; ?>
</div>