		<div id="screenshots">
<?php 
	$my_query = new WP_Query('showposts=3&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="col7 animated fadeIn">

<figure class="effect-layla">
  
<div class="xxframe view view-first">
<a href="<?php the_permalink(); ?>">
<?php if (function_exists('vp_get_thumb_url')) { $thumb=vp_get_thumb_url($post->post_content, 'bigg');}?> 
<div class="xxy xk1" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
</div>

<figcaption>
<div class="xdetails mask">
<h2><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
<div class="xlistview">
<p ><?php the_content_rss('', FALSE, '', 14); ?></p>
<span >
<h4><span ><?php the_time('d') ?></span></h4>
</span>
<form action="<?php the_permalink(); ?>" method="post" class="shopp productz">
<h4 class="addtocart"><?php _e('Details', 'Detox') ?></h4>
</form> 
</div>
</div>
</figcaption>
</a>
</div>
</figure>

<div class="xcenter">
<div class="ycenter">
<h4 itemprop="name"><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
<span ><?php the_time('d') ?></span>
</div>
</div>

</div>
<?php endwhile; ?>
			
		</div>