<?php

function get_upload_field($id, $std = '', $desc = '') {

  $field = '<input id="' . $id . '" type="file" name="attachment_' . $id . '" />' .
           '<span class="submit"><input name="DarkHorizon_upload" type="submit" value="Upload" class="button panel-upload-save" />
		   </span> <span class="description"> '. __($desc,'detox') .' </span>';

  return $field;
}

load_theme_textdomain('DarkHorizon');
class DarkHorizon {
	function addOptions () {
	
		if (isset($_POST['DarkHorizon_reset'])) { DarkHorizon::initOptions(true); }
		if (isset($_POST['DarkHorizon_save'])) {

			$aOptions = DarkHorizon::initOptions(false);
		
		$aOptions['featured1-image'] = stripslashes($_POST['featured1-image']);
		$aOptions['featured1-title'] = stripslashes($_POST['featured1-title']);
		$aOptions['featured1-link'] = stripslashes($_POST['featured1-link']);
		$aOptions['featured1-desc'] = stripslashes($_POST['featured1-desc']);
    $aOptions['featured1-text'] = stripslashes($_POST['featured1-text']);
        
    $aOptions['featured2-image'] = stripslashes($_POST['featured2-image']);
    $aOptions['featured3-image'] = stripslashes($_POST['featured3-image']);
		
    $aOptions['featured4-title'] = stripslashes($_POST['featured4-title']);
    $aOptions['featured4-text'] = stripslashes($_POST['featured4-text']);
    $aOptions['featured4-link'] = stripslashes($_POST['featured4-link']);
    $aOptions['featured4-desc'] = stripslashes($_POST['featured4-desc']);
        
    $aOptions['featured5-image'] = stripslashes($_POST['featured5-image']);
		$aOptions['featured5-title'] = stripslashes($_POST['featured5-title']);
		$aOptions['featured5-link'] = stripslashes($_POST['featured5-link']);
		$aOptions['featured5-desc'] = stripslashes($_POST['featured5-desc']);
    $aOptions['featured5-text'] = stripslashes($_POST['featured5-text']);
    
    $aOptions['featured6-title'] = stripslashes($_POST['featured6-title']);
		$aOptions['featured6-desc'] = stripslashes($_POST['featured6-desc']);
    
    $aOptions['featured7-image'] = stripslashes($_POST['featured7-image']);
    
    $aOptions['featured8-image'] = stripslashes($_POST['featured8-image']);
		$aOptions['featured8-title'] = stripslashes($_POST['featured8-title']);
		$aOptions['featured8-link'] = stripslashes($_POST['featured8-link']);
		$aOptions['featured8-desc'] = stripslashes($_POST['featured8-desc']);
    $aOptions['featured8-text'] = stripslashes($_POST['featured8-text']);
    
    $aOptions['featured9-text'] = stripslashes($_POST['featured9-text']);
    $aOptions['featured91-text'] = stripslashes($_POST['featured91-text']);
    $aOptions['featured92-text'] = stripslashes($_POST['featured92-text']);
    $aOptions['featured93-text'] = stripslashes($_POST['featured93-text']);
    			
			update_option('DarkHorizon_theme', $aOptions);
		}
		if (isset($_POST['DarkHorizon_upload'])) {

			$aOptions = DarkHorizon::initOptions(false);

            $whitelist = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			
			if (!$_FILES['attachment_featured1-image']['type']=='') { 
				$up_file = 'featured1-image'; 
			}
			
			if (!$_FILES['attachment_featured2-image']['type']=='') { 
				$up_file = 'featured2-image'; 
			}
			
			if (!$_FILES['attachment_featured3-image']['type']=='') { 
				$up_file = 'featured3-image'; 
			}
      	if (!$_FILES['attachment_featured5-image']['type']=='') { 
				$up_file = 'featured5-image'; 
			}
				if (!$_FILES['attachment_featured7-image']['type']=='') { 
				$up_file = 'featured7-image'; 
			}	
      		if (!$_FILES['attachment_featured8-image']['type']=='') { 
				$up_file = 'featured8-image'; 
			}				
            $filetype = $_FILES['attachment_' . $up_file]['type'];

            if (in_array($filetype, $whitelist)) {
              $upload = wp_handle_upload($_FILES['attachment_' . $up_file], array('test_form' => false));
			  $aOptions[$up_file] = stripslashes($upload['url']);
			  update_option('DarkHorizon_theme', $aOptions);
            }
		}
		add_theme_page(" DarkHorizon Options", "DarkHorizon Options", 'edit_themes', basename(__FILE__), array('DarkHorizon', 'displayOptions'));
	}
	function initOptions ($bReset) {
		$aOptions = get_option('DarkHorizon_theme');
		if (!is_array($aOptions) || $bReset) {
 
			$aOptions['featured1-image'] = get_bloginfo('url') . '/wp-content/themes/DarkHorizon/images/favicon.png';
      $aOptions['featured1-title'] = 'Function';
			$aOptions['featured1-desc'] = 'Good design is making something intelligible and memorable. Great design is making something memorable and meaningful. ';
			$aOptions['featured1-link'] = get_bloginfo('url') . '/shop/';
      $aOptions['featured1-text'] = 'View the shop';
              
      $aOptions['featured2-image'] = get_bloginfo('url') . '/wp-content/themes/DarkHorizon/images/logo.png';
			$aOptions['featured3-image'] = get_bloginfo('url') . '/wp-content/themes/DarkHorizon/images/gown.gif';
			
      $aOptions['featured4-title'] = 'About Us';
			$aOptions['featured4-desc'] = 'Be sure to check the latest news where you can find more info about our work, design and concept.<br /><br />We make every effort to impart a simple, clear and balanced beauty to our products so that they will retain fascination and appeal for years to come.<br /><br />Good design is making something intelligible and memorable. Great design is making something memorable and meaningful. ';
			$aOptions['featured4-link'] = get_bloginfo('url') . '/shop/';
      $aOptions['featured4-text'] = 'gdbr_2yY3tw';
      
      $aOptions['featured5-image'] = get_bloginfo('url') . '/wp-content/themes/DarkHorizon/images/burberry-tie.png';
      $aOptions['featured5-title'] = 'Concept';
			$aOptions['featured5-desc'] = 'We make every effort to impart a simple, clear and balanced beauty to our products so that they will retain fascination and appeal for years to come.<br /><br />Take a quick look at our latest bestseller item or view all Shop items at our gallery. ';
			$aOptions['featured5-link'] = get_bloginfo('url') . '/shop/';
      $aOptions['featured5-text'] = 'View the shop';
      
      $aOptions['featured6-title'] = 'Our Shop';
			$aOptions['featured6-desc'] = 'Our shop features and all the details. ';
      
      $aOptions['featured7-image'] = get_bloginfo('url') . '/wp-content/themes/DarkHorizon/images/christian-coigny.jpg';
      
      $aOptions['featured8-image'] = get_bloginfo('url') . '/wp-content/themes/DarkHorizon/images/jacket.png';
      $aOptions['featured8-title'] = 'Shiny new product';
			$aOptions['featured8-desc'] = 'Good design is making something intelligible and memorable. Great design is making something memorable and meaningful.<br /><br />Having small touches of colour makes it more colourful than having the whole thing in colour. ';
			$aOptions['featured8-link'] = get_bloginfo('url') . '/shop/';
      $aOptions['featured8-text'] = 'View item';
      
      $aOptions['featured9-text'] = 'http://twitter.com/milo317';
      $aOptions['featured91-text'] = 'https://www.facebook.com/3oneseven';
      $aOptions['featured92-text'] = 'http://pinterest.com/3oneseven/';
      $aOptions['featured93-text'] = 'http://pinterest.com/3oneseven/';
       			
			update_option('DarkHorizon_theme', $aOptions);
		}
		return $aOptions;
	}
	function displayOptions () {
		$aOptions = DarkHorizon::initOptions(false);
?>
<div class="wrap">
	<h2>DarkHorizon Theme Options</h2>
	<p>You can edit logo options by using the fields below.</p>

<div id="sideblock" style="float:right;width:220px;margin-left:10px;"> 
     <h3>Information</h3>
     <div id="dbx-content" style="text-decoration:none;">       
 		 <img src="<?php bloginfo('stylesheet_directory'); ?>/images/favicon.ico" width="20px" /><a style="text-decoration:none;" href="http://3oneseven.com/"> 3oneseven</a><br /><br />
		 <img src="<?php bloginfo('stylesheet_directory'); ?>/images/tweet.jpg" width="20px" /><a style="text-decoration:none;" href="http://twitter.com/milo317"> Follow on Twitter</a><br /><br />
    <img src="<?php bloginfo('stylesheet_directory'); ?>/images/fb.jpg" width="20px" /><a style="text-decoration:none;" href="https://www.facebook.com/3oneseven"> Follow on FaceBook</a><br /><br />			
</div>
</div> 
 
    <div style="margin-left:0px;">
    <form action="#" method="post" enctype="multipart/form-data" name="massive_form" id="massive_form">
		<fieldset name="general_options" class="options">
        <div style="border-bottom:1px solid #333;"></div>
        <h3 style="margin-bottom:0px;">Feature Options:</h3>
        <p style="margin-top:0px;">You can add by filling out the fields below.</p>
                	        
		<h3>Favicon</h3>
             
       Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured1-image" id="featured1-image" size="30" value="<?php echo($aOptions['featured1-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured1-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured1-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured1-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
    
     <div style="border-bottom:1px solid #333;"></div>
                  
        	<h3>Logo</h3>
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured2-image" id="featured2-image" size="30" value="<?php echo($aOptions['featured2-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured2-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured2-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured2-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
                	
		 <div style="border-bottom:21px solid #333;"></div>
		 
     		<h3>Front box #1</h3>
        Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured1-title" id="featured1-title" value="<?php echo($aOptions['featured1-title']); ?>"></input>
        </div><br />
               
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured1-link" id="featured1-link" size="30" value="<?php echo($aOptions['featured1-link']); ?>"></input>   
        </div><br />
        
        Description:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured1-desc" cols="30" rows="2" id="featured1-desc"><?php echo($aOptions['featured1-desc']); ?></textarea>
		</div><br />
    
          Link Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured1-text" cols="30" rows="2" id="featured1-text"><?php echo($aOptions['featured1-text']); ?></textarea>
		</div><br />
	 
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured3-image" id="featured3-image" size="30" value="<?php echo($aOptions['featured3-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured3-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured3-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured3-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
                
<div style="border-bottom:21px solid #333;"></div>

 		<h3>Front box #2</h3>
        Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured5-title" id="featured5-title" value="<?php echo($aOptions['featured5-title']); ?>"></input>
        </div><br />
               
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured5-link" id="featured5-link" size="30" value="<?php echo($aOptions['featured5-link']); ?>"></input>   
        </div><br />
        
        Description:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured5-desc" cols="30" rows="2" id="featured5-desc"><?php echo($aOptions['featured5-desc']); ?></textarea>
		</div><br />
    
          Link Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured5-text" cols="30" rows="2" id="featured5-text"><?php echo($aOptions['featured5-text']); ?></textarea>
		</div><br />
	 
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured5-image" id="featured5-image" size="30" value="<?php echo($aOptions['featured5-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured5-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured5-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured5-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

 <div style="border-bottom:21px solid #333;"></div>
		 
     		<h3>Front box #3</h3>
        Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured6-title" id="featured6-title" value="<?php echo($aOptions['featured6-title']); ?>"></input>
        </div><br />
               
        Description:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured6-desc" cols="30" rows="2" id="featured6-desc"><?php echo($aOptions['featured6-desc']); ?></textarea>
		</div><br />

<div style="border-bottom:21px solid #333;"></div>

 		<h3>Front box #4</h3>
        Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured8-title" id="featured8-title" value="<?php echo($aOptions['featured8-title']); ?>"></input>
        </div><br />
               
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured8-link" id="featured8-link" size="30" value="<?php echo($aOptions['featured8-link']); ?>"></input>   
        </div><br />
        
        Description:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured8-desc" cols="30" rows="2" id="featured8-desc"><?php echo($aOptions['featured8-desc']); ?></textarea>
		</div><br />
    
          Link Text:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured8-text" cols="30" rows="2" id="featured8-text"><?php echo($aOptions['featured8-text']); ?></textarea>
		</div><br />
	 
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured8-image" id="featured8-image" size="30" value="<?php echo($aOptions['featured8-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured8-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured8-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured8-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
            
<div style="border-bottom:21px solid #333;"></div>
                       
<h3>Video Box</h3>
        Set the youtube video:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured4-text" id="featured4-text" value="<?php echo($aOptions['featured4-text']); ?>"></input>
        </div><br />

        		<h3>Front box #1</h3>
        Title:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured4-title" id="featured4-title" value="<?php echo($aOptions['featured4-title']); ?>"></input>
        </div><br />
               
        Links To:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured4-link" id="featured4-link" size="30" value="<?php echo($aOptions['featured4-link']); ?>"></input>   
        </div><br />
        
        Description:<br />
		<div style="margin:0;padding:0;">
        <textarea style="margin:0;padding:0;width:80% !important;border:1px solid #ccc !important;" name="featured4-desc" cols="30" rows="2" id="featured4-desc"><?php echo($aOptions['featured4-desc']); ?></textarea>
		</div><br />

<div style="border-bottom:21px solid #333;"></div>
                  
        	<h3>Blog Section</h3>
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured7-image" id="featured7-image" size="30" value="<?php echo($aOptions['featured7-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured7-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured7-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured7-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>

<div style="border-bottom:21px solid #333;"></div>
                       
<h3>Social Box</h3>

        Set Twitter link:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured9-text" id="featured9-text" value="<?php echo($aOptions['featured9-text']); ?>"></input>
        </div><br />
          Set Facebook link:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured91-text" id="featured91-text" value="<?php echo($aOptions['featured91-text']); ?>"></input>
        </div><br />
           Set Pinterest link:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured92-text" id="featured92-text" value="<?php echo($aOptions['featured92-text']); ?>"></input>
        </div><br />
          Set Instagram link:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured93-text" id="featured93-text" value="<?php echo($aOptions['featured93-text']); ?>"></input>
        </div><br />   
<div style="border-bottom:21px solid #333;"></div>

		</fieldset>
		<p class="submit"><input type="submit" name="DarkHorizon_reset" value="Reset" /></p>
		<p class="submit"><input type="submit" name="DarkHorizon_save" value="Save" /></p>
	</form>      
</div>
<?php
	}
}
// Register functions
add_action('admin_menu', array('DarkHorizon', 'addOptions'));
?>