<div id="intro-wrap">
<div class="row-content buffer even">

<h2><?php _e('Latest news', 'Detox'); ?></h2>
<div class="tabs">

<ul class="tab-links">
<li class="active"><a href="#tab1"><?php _e('New', 'Detox'); ?> <i class="fa fa-search fa-lg">&#xf105;</i></a></li>
<li><a href="#tab2"><?php _e('Featured', 'Detox'); ?> <i class="fa fa-search fa-lg">&#xf105;</i></a></li>
</ul>
   
<div class="tab-content">
 
<div id="tab1" class="tab active">

<div id="intro1" class="xpreload xdarken">					
				
<div class="banner">

	<ul>
<li>  
<?php 
	$my_query = new WP_Query('showposts=4&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

    <div class="perso">
    <div class="simg">
    <a href="<?php the_permalink() ?>" title="<?php echo get_the_title(); ?>">
    <?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
    </a>
    </div>
    <p><?php echo get_the_title(); ?></p>
    <p><?php the_category(' <span>/</span> '); ?></p>
    </div>
   
<?php endwhile; wp_reset_query(); ?>    
 </li>

<li>  
<?php 
	$my_query = new WP_Query('showposts=4&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

    <div class="perso">
    <div class="simg">
    <a href="<?php the_permalink() ?>" title="<?php echo get_the_title(); ?>">
    <?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
    </a>
    </div>
    <p><?php echo get_the_title(); ?></p>
       <p><?php the_category(' <span>/</span> '); ?></p>
    </div>
   
<?php endwhile; wp_reset_query(); ?>    
 </li>  
	</ul>

</div>
          																		
</div><!-- intro -->
</div>
  
<div id="tab2" class="tab">
<div id="intro1" class="ppreload pdarken">					

<div class="banner">
	
	<ul>
<li>  
<?php 
	$my_query = new WP_Query('showposts=4&offset=8');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

    <div class="perso">
    <div class="simg">
    <a href="<?php the_permalink() ?>" title="<?php echo get_the_title(); ?>">
    <?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
    </a>
    </div>
    <p><?php echo get_the_title(); ?></p>
       <p><?php the_category(' <span>/</span> '); ?></p>
    </div>
   
<?php endwhile; wp_reset_query(); ?>    
 </li>

<li>  
<?php 
	$my_query = new WP_Query('showposts=4&offset=12');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

    <div class="perso">
    <div class="simg">
    <a href="<?php the_permalink() ?>" title="<?php echo get_the_title(); ?>">
    <?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
    </a>
    </div>
    <p><?php echo get_the_title(); ?></p>
       <p><?php the_category(' <span>/</span> '); ?></p>
    </div>
   
<?php endwhile; wp_reset_query(); ?>    
 </li>  
	</ul>
  
</div>
             																		
</div><!-- intro -->        
</div>




</div>
</div>

<div class="bot"><div class="pnav"><a href="<?php echo get_settings('home'); ?>/"><?php _e('View the blog', 'Detox') ?></a></div></div>
</div>        
</div><!-- intro-wrap -->