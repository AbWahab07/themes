<?php get_header(); ?>

<div id="content">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="cat"><?php bloginfo('name'); ?></div>
<h1><?php the_title(); ?> <?php edit_post_link(' <b>Edit</b>','',''); ?></h1>
<div class="meta"></div>

<div id="fillsb">
<div class="entry">
<?php if(has_post_thumbnail()) :?><?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="postoimg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>
<div class="postimg"></div><?php else :?><?php endif;?>
<?php the_content(__('Read more', 'Detox'));?>

<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
</div>
</div>
<?php endif; ?>

<?php get_footer(); ?>