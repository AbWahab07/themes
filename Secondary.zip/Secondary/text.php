<section class="row section call-to-action">
<?php $aOptions = Secondary::initOptions(false); ?>  
         <div class="figr" style="background-image:url(<?php echo($aOptions['featured4-image']); ?>)"></div>
         <div class="play"><a href="<?php echo($aOptions['featured4-link']); ?>"><?php _e('Read more', 'Detox'); ?></a></div>
					<div class="confer">
          <div class="row-content buffer even">
						
            <h2><?php echo($aOptions['featured4-title']); ?></h2>
            <p><?php echo($aOptions['featured4-text']); ?></p>
						<div class="pnav"><a href="<?php echo($aOptions['featured4-link']); ?>"><?php _e('Read more', 'Detox'); ?></a></div>

					</div>
          </div>
</section>