<div id="intro-wrap" class="fmap">
<div class="row-content buffer even">

<h2><?php _e('Locations', 'Detox'); ?></h2>
<div class="tabs">

<?php $aOptions = Secondary::initOptions(false); ?>
<ul class="tab-links">
<li class="active"><a href="#tab13"><?php echo($aOptions['featured30-title']); ?> <i class="fa fa-search fa-lg">&#xf105;</i></a></li>
<li><a href="#tab14"><?php echo($aOptions['featured31-title']); ?> <i class="fa fa-search fa-lg">&#xf105;</i></a></li>
</ul>

  
<div class="tab-content">
  
<div id="tab13" class="tab active">

<section class="mapa">
<div class="figr"></div>

<div class="confer">

<div class="row-content buffer even">
<div class="bleft">
<p><?php echo($aOptions['featured30-text']); ?></p>
<div class="pnav"><a href="<?php echo($aOptions['featured31-link']); ?>"><?php _e('Read more', 'Detox'); ?></a></div>
</div>

</div>
<div class="bright" style="background-image:url(<?php echo($aOptions['featured30-image']); ?>)">
<a href="<?php echo($aOptions['featured30-link']); ?>"><?php _e('Read more', 'Detox'); ?></a>
</div>
</div>

</section>

</div>
  
<div id="tab14" class="tab">

<section class="mapa">
<div class="figr"></div>

<div class="confer">
<div class="row-content buffer even">
<div class="bleft">
<p><?php echo($aOptions['featured31-text']); ?></p>
<div class="pnav"><a href="<?php echo($aOptions['featured31-link']); ?>"><?php _e('Read more', 'Detox'); ?></a></div>
</div>
</div>

<div class="bright" style="background-image:url(<?php echo($aOptions['featured31-image']); ?>)">
<a href="<?php echo($aOptions['featured31-link']); ?>"><?php _e('Read more', 'Detox'); ?></a>
</div>
</div>

</section>	

</div>


</div>
</div>
</div>
</div>