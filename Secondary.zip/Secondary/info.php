<div id="intro-wrap" class="agendas">
<div class="row-content buffer even">

<h2><?php _e('Info', 'Detox'); ?></h2>
<div class="tabs">

<ul class="tab-links">
<li class="active"><a href="#tab33"><?php _e('About', 'Detox'); ?> <i class="fa fa-search fa-lg">&#xf105;</i></a></li>
<li><a href="#tab44"><?php _e('Payments', 'Detox'); ?> <i class="fa fa-search fa-lg">&#xf105;</i></a></li>
</ul>


<div class="tab-content">
<?php $aOptions = Secondary::initOptions(false); ?> 

<div id="tab33" class="tab active">

<section class="agendaz">
<div class="figr" style="background-image:url(<?php echo($aOptions['featured28-image']); ?>)"><div class="sfig"></div></div>

<div class="confer">
<div class="row-content buffer even">
<div class="xarow-content">
						
	<div class="chart" data-percent="<?php echo($aOptions['featured281-number']); ?>" data-bar-color="#ff3300" data-animate="2000">
							<div class="chart-content">
								<div class="percent"></div>
								<div class="chart-title"><?php echo($aOptions['featured281-text']); ?></div>
							</div><!-- chart-content -->
						</div><!-- chart -->
						<div class="chart" data-percent="<?php echo($aOptions['featured282-number']); ?>" data-bar-color="#ff3300" data-animate="2500">
							<div class="chart-content">
								<div class="percent"></div>
								<div class="chart-title"><?php echo($aOptions['featured282-text']); ?></div>
							</div><!-- chart-content -->
						</div><!-- chart -->
						<div class="chart" data-percent="<?php echo($aOptions['featured283-number']); ?>" data-bar-color="#ff3300" data-animate="3000">
							<div class="chart-content">
								<div class="percent"></div>
								<div class="chart-title"><?php echo($aOptions['featured283-text']); ?></div>
							</div><!-- chart-content -->
						</div><!-- chart -->
						<div class="chart" data-percent="<?php echo($aOptions['featured284-number']); ?>" data-bar-color="#ff3300" data-animate="3500">
							<div class="chart-content">
								<div class="percent"></div>
								<div class="chart-title"><?php echo($aOptions['featured284-text']); ?></div>
							</div><!-- chart-content -->
						</div><!-- chart -->

<div class="pnav"><a href="<?php echo($aOptions['featured28-link']); ?>"><?php _e('View more', 'Detox'); ?></a></div>

</div>
</div>
</div>
</section>

</div>
  
<div id="tab44" class="tab">

<section class="agendaz">
<div class="figr" style="background-image:url(<?php echo($aOptions['featured29-image']); ?>)"><div class="sfig"></div></div>

<div class="confer">
<div class="row-content buffer even">
<div class="arow-content">
						
	<div class="chart" data-percent="<?php echo($aOptions['featured291-number']); ?>" data-bar-color="#ff3300" data-animate="2000">
							<div class="chart-content">
								<div class="percent"></div>
								<div class="chart-title"><?php echo($aOptions['featured291-text']); ?></div>
							</div><!-- chart-content -->
						</div><!-- chart -->
						<div class="chart" data-percent="<?php echo($aOptions['featured292-number']); ?>" data-bar-color="#ff3300" data-animate="2500">
							<div class="chart-content">
								<div class="percent"></div>
								<div class="chart-title"><?php echo($aOptions['featured292-text']); ?></div>
							</div><!-- chart-content -->
						</div><!-- chart -->
						<div class="chart" data-percent="<?php echo($aOptions['featured293-number']); ?>" data-bar-color="#ff3300" data-animate="3000">
							<div class="chart-content">
								<div class="percent"></div>
								<div class="chart-title"><?php echo($aOptions['featured293-text']); ?></div>
							</div><!-- chart-content -->
						</div><!-- chart -->
						<div class="chart" data-percent="<?php echo($aOptions['featured294-number']); ?>" data-bar-color="#ff3300" data-animate="3500">
							<div class="chart-content">
								<div class="percent"></div>
								<div class="chart-title"><?php echo($aOptions['featured294-text']); ?></div>
							</div><!-- chart-content -->
						</div><!-- chart -->

<div class="pnav"><a href="<?php echo($aOptions['featured29-link']); ?>"><?php _e('View more', 'Detox'); ?></a></div>

</div>
</div>
</div>
</section>	

</div>


</div> 
</div>

</div>
</div>