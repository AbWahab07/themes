<?php get_header(); ?>

<div id="content">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="cat"><?php the_category(' <span>/</span> '); ?></div>
<h1><?php the_title(); ?> <?php edit_post_link(' <b>Edit</b>','',''); ?></h1>
<div class="meta"><?php the_time('M'); ?> <?php the_time('j'); ?> | <?php _e( ' by', 'Detox') ?> <?php the_author_posts_link(); ?></div>

<div id="fillsb">
<div class="entry">
<?php if(has_post_thumbnail()) :?><?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="postoimg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>
<?php else :?><?php endif;?>
<?php the_content(__('Read more', 'Detox'));?>

<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
</div>

<?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>			
<?php get_template_part('social'); ?>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>

</div>
</div>
<?php endif; ?>
<?php get_template_part('tops'); ?>
<?php get_footer(); ?>