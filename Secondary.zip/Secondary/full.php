<?php
/*
Template Name: Full width
*/
?>
<?php get_header(); ?>

<div id="content">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<h1><?php the_title(); ?> <?php edit_post_link(' <b>Edit</b>','',''); ?></h1>
<div id="fills">
<div class="entry">
<?php the_content(__('Read more', 'Detox'));?>

<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
</div>


<div class="content-title">
            <p class="alignleft"><?php _e('You are here:', 'Detox') ?></p> <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
            <a href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;t=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="f" title="<?php _e('Share on Facebook', 'Detox') ?>"></a>
            <a href="http://twitter.com/home?status=<?php the_title(); ?> <?php the_permalink() ?>" target="_blank" class="t" title="<?php _e('Spread the word on Twitter', 'Detox') ?>"></a>
            <a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" class="di" title="<?php _e('Bookmark on Del.icio.us', 'Detox') ?>"></a>
            <a href="http://stumbleupon.com/submit?url=<?php the_permalink() ?>&amp;title=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="su" title="<?php _e('Share on StumbleUpon', 'Detox') ?>"></a>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
</div>
<?php endif; ?>


</div>

<?php get_footer(); ?>