<section class="row section call-to-partner">         
<?php $aOptions = Secondary::initOptions(false); ?>  
<div class="figr" style="background-image:url(<?php echo($aOptions['featured12b-image']); ?>)"></div>
<div class="par">
<div class="row-content buffer even">
						
<h2><?php _e('Brands', 'Detox') ?></h2>

<div class="sl">
<div class="fsig"><a href="<?php echo($aOptions['featured12-link']); ?>"><img src="<?php echo($aOptions['featured12-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured13-link']); ?>"><img src="<?php echo($aOptions['featured13-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured14-link']); ?>"><img src="<?php echo($aOptions['featured14-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured15-link']); ?>"><img src="<?php echo($aOptions['featured15-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured16-link']); ?>"><img src="<?php echo($aOptions['featured16-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured17-link']); ?>"><img src="<?php echo($aOptions['featured17-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured18-link']); ?>"><img src="<?php echo($aOptions['featured18-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured19-link']); ?>"><img src="<?php echo($aOptions['featured19-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured20-link']); ?>"><img src="<?php echo($aOptions['featured20-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured21-link']); ?>"><img src="<?php echo($aOptions['featured21-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured22-link']); ?>"><img src="<?php echo($aOptions['featured22-image']); ?>" alt="media partners" /></a></div> 
<div class="fsig"><a href="<?php echo($aOptions['featured23-link']); ?>"><img src="<?php echo($aOptions['featured23-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured24-link']); ?>"><img src="<?php echo($aOptions['featured24-image']); ?>" alt="media partners" /></a></div>
<div class="fsig"><a href="<?php echo($aOptions['featured25-link']); ?>"><img src="<?php echo($aOptions['featured25-image']); ?>" alt="media partners" /></a></div>
</div>
</div>
</div>
<div class="bot"><div class="pnav"><a href="<?php echo($aOptions['featured122-link']); ?>"><?php _e('Shop now!', 'Detox') ?></a></div></div>
</section>