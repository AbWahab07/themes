<div id="sidebar">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('sidebar') ) : ?>
	        
<h3><?php _e('Categories', 'Detox') ?></h3>
<ul><?php wp_list_categories('orderby=id&show_count=0&sort_column=name&title_li=&depth=-1'); ?></ul>
		
<h3><?php _e('Archive', 'Detox') ?></h3>
<ul>
<?php wp_get_archives('type=monthly&show_post_count=true'); ?>
</ul>
        
<?php endif; ?>

</div>