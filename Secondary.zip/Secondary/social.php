<div class="content-title">
             <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
            <div class="socials meta-social">
            <ul class="inline">
            <li><a target="_blank" href="http://twitter.com/home?status=<?php the_title(); ?> <?php the_permalink() ?>" class="twitter-share border-box"><i class="fa fa-twitter fa-lg"></i></a></li>
						<li><a target="_blank" href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;t=<?php echo urlencode(the_title('','', false)) ?>" class="facebook-share border-box"><i class="fa fa-facebook fa-lg"></i></a></li>
            <?php if (has_post_thumbnail( $post->ID ) ): ?><?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
            <li><a target="_blank" href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php echo $image[0]; ?>" class="pinterest-share border-box"><i class="fa fa-pinterest fa-lg"></i></a></li>
            <?php endif; ?>
            </ul>
            </div>
</div>