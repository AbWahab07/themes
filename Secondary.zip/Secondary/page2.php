<?php
/*
Template Name: Page left sidebar
*/
?>
<?php get_header(); ?>
<div id="fillsb">
<div id="xcontent">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="xmedial">
<div class="cat"><?php the_time('M'); ?> <?php the_time('j'); ?> | <?php _e( ' by', 'Detox') ?> <?php the_author_posts_link(); ?></div>
<h1><?php the_title(); ?> <?php edit_post_link(' <b>Edit</b>','',''); ?></h1>
<div id="middle">
<div class="entry">
<?php the_content(__('Read more', 'Detox'));?>

<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
</div>

<?php get_template_part('social'); ?>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
</div>
<?php endif; ?>
</div>
</div>
<?php get_template_part('sidebar'); ?>
</div>
</div>
<?php get_footer(); ?>