	<div id="fintro-wrap" class="xanimated xfadeIn">
				<div id="fintro" class="preload xdarken">					
					<div class="intro-item animated fadeIn">
          
<div id="slider1" class="sliderwrapper">

<?php 
	$my_query = new WP_Query('showposts=4&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>                
<div class="contentdiv">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?> 
<div class="h-f">
<div class="cis" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="h-t">
<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
<div class="ctitle">
<?php the_category(' <span>/</span> '); ?>
</div>
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<div class="pnav"> 
<a href="<?php the_permalink() ?>">View more</a>
</div>
</div> 
<a href="<?php the_permalink() ?>">
</a>
</div>
</div>
</div>
<?php endwhile; ?>                           
                
<div id="paginate-slider1" class="pagination"></div>
<script type="text/javascript">
featuredcontentslider.init({
id: "slider1", 
contentsource: ["inline", ""], 
toc: "#increment", 
nextprev: ["", ""], 
revealtype: "mouseover", 
enablefade: [true, 0.9], 
autorotate: [true, 9000], 
onChange: function(previndex, curindex){ 
}
})
</script>
</div>
			
					</div>									
																												
				</div>
			</div>