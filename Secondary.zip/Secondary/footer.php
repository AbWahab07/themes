</main>

</div>
</section>
</div>	

<?php get_template_part('ftop'); ?>

<div id="sfoo">
<?php get_template_part('sfoo'); ?>

<footer role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
<section class="row-content buffer">
<section id="top-footer">				
						<div class="widget meta-social pcolumn pthree">
							<ul class="inline">
								<li><a target="_blank" href="" class="twitter-share border-box"><i class="fa fa-twitter fa-lg"></i></a></li>
								<li><a target="_blank" href="" class="facebook-share border-box"><i class="fa fa-facebook fa-lg"></i></a></li>
                <li><a target="_blank" href="" class="youtube-share border-box"><i class="fa fa-youtube fa-lg"></i></a></li>
                <li><a target="_blank" href="" class="pinterest-share border-box"><i class="fa fa-pinterest fa-lg"></i></a></li>
               									
							</ul>
						</div>														
</section>
         
<section id="bottom-footer">
<p class="keep-right"><?php _e('Copyright', 'y2k'); ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> | <a class="no-link" href="https://3oneseven.com/">Website design by milo</a>
<br /><div id="gnavigation" style="font-size:10px"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/secondary-magazine-theme/" >Theme</a> <span>Secondary theme</span>
</span>
</span>
</span>
</div>
</p>
</section> 

</section>
</footer>
</div>


<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/plugins.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/milo.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/instant.js" type="text/javascript"></script>

</body>
</html>