<div id="intro-wrap">
<div id="intro" class="preload xdarken">					
<div class="intro-item">
<div class="xcaption animated fadeInDown">
<div class="con"><svg class="shadow" viewBox="0 0 350 50"><text y="40">Secondary</text></svg>
<h1>AMAZINGLY BEAUTIFUL THEME</h1>
             
</div>
</div>
			
</div>									
</div>
</div>