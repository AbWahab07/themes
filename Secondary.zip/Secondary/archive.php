<?php get_header(); ?>

<div id="content">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="post">
<div class="cat"><?php the_category(' <span>/</span> '); ?></div>
<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a> <?php edit_post_link(' <b>Edit</b>','',''); ?></h1>
<div class="meta"><?php the_time('M'); ?> <?php the_time('j'); ?> | <?php _e( ' by', 'Detox') ?> <?php the_author_posts_link(); ?></div>

<div id="fillsb">
<div class="entry">
<?php if(has_post_thumbnail()) :?><?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="spostimg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div><?php else :?><div class="spostimg"></div><?php endif;?>
<p><?php the_content_rss('', FALSE, ' ', 30); ?></p>
<div class="pnav">
<a href="<?php the_permalink() ?>"><?php _e( 'View more', 'Detox') ?></a>
</div>
</div>
</div>

</div>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>

</div>

<?php get_footer(); ?>