<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<style type="text/css">@-ms-viewport{width: device-width;}</style>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<!--[if lte IE 9]><link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/ie.css" type="text/css" title="default" media="screen" /><![endif]-->    
<!--[if lt IE 9]><script src="<?php echo get_template_directory_uri(); ?>/js/respond.min.js"></script><![endif]-->
 <?php $aOptions = Secondary::initOptions(false); ?>
<link rel="icon" href="<?php echo($aOptions['featured2-image']); ?>" />
<meta name="generator" content="Nexus-6 ver 2019" />

<?php if(is_front_page()): ?><?php elseif (is_singular()): ?>
<link rel="prefetch" href="<?php echo get_permalink(get_adjacent_post(false,'',true)); ?>">
<link rel="prerender" href="<?php echo get_permalink(get_adjacent_post(false,'',false)); ?>">
<?php else: ?>
<link rel="prefetch" href="<?php echo home_url(); ?>">
<link rel="prerender" href="<?php echo home_url(); ?>">
<?php endif; ?>

<script src="<?php echo get_template_directory_uri(); ?>/js/contentslider.js" type="text/javascript"></script>


</head>

<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="http://schema.org/WebPage">

<header role="banner" class="transparent light" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<div class="row">
<div class="nav-inner row-content buffer-left buffer-right even clear-after animated fadeIn">
<div id="brand">
<h1 class="reset"><a href="/"><img src="<?php echo($aOptions['featured1-image']); ?>" alt="<?php bloginfo('name'); ?>" /></a></h1>
</div>

<a id="menu-toggle" href="#"><i class="fa fa-bars fa-lg"></i></a>
<nav>
<ul id="nav" class="menu">
<li id="menu-item-183688767" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-183688767"><a href="/about/">About</a></li>
<li id="menu-item-183689116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-183689116"><a href="/nature/">Nature</a></li>
<li id="menu-item-183689117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-183689117"><a href="/level-3/">Level 3</a></li>
</ul>         
</nav>

<div id="reg">
<div id="sb-search" class="animated fadeIn">
<a href="#searchform" class="search-toggle" rel="ibox"><i class="fa fa-search fa-lg">&#xf002;</i></a>
<form id="searchform" style="display: none;" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e('Search...', 'Detox'); ?>" name="s" id="s" onfocus="if (this.value == 'Search...', 'Detox') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search', 'Detox';}" /></form>
</div>        
</div>
</div>	
</div>	
</header>
    
<main role="main">      