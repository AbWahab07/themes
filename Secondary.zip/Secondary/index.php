<?php get_template_part('headerhome'); ?>

<?php get_template_part('top'); ?>
<div id="main" class="animated fadeIn">
<?php get_template_part('text'); ?>	
<?php
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('pro');
} else {
get_template_part('post');
}
?>
<?php get_template_part('brands'); ?>	
<?php get_template_part('info'); ?>	

</div><!-- id-main -->
<?php get_template_part('footerhome'); ?>