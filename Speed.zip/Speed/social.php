<div id="sc">
<div class="fb"><a class="trs" title="Friend us on Facebook" href="">Facebook</a></div>
<div class="tw"><a class="trs" title="Follow us on Twitter" href="">Twitter</a></div>
<div class="rss"><a class="trs" title="Subscribe via RSS" href="">RSS Feed</a></div>
<div class="sign"><a class="trs" title="Subscribe via Mail" href="">Email Signup</a></div>
</div>