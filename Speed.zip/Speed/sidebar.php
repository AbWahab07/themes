<div class="sidebar">
<div class="in">

<?php if ( (is_single())  ) { ?>
<div class="scol">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad1') ) : ?>
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />
<?php endif; ?>
</div>
<?php } else { ?>
<div class="show">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('about') ) : ?>
<h3><?php _e( 'Welcome to Speed') ?></h3> 
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="cookie" class="alignright" width="100" />
<p><?php _e( 'Place your home widget content here along with a nice welcome text.') ?></p>
<div class="smore"><a href="http://3oneseven.com/speed-wordpress-theme/"><?php _e( 'Read more') ?></a></div>
<?php endif; ?>
</div>
<?php } ?>

<?php if ( (is_single())  ) { ?>
<div class="widget">
<div class="widget-body clear">  
<div class="slideshow"><div id="slideshow">

<?php 
	$my_query = new WP_Query('category_name=&showposts=8&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="slide clear">
<div class="post">
<?php if(has_post_thumbnail()) :?>
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php $browse_img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $browse_img; ?></a>
<?php else :?>
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="100%" height="auto" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
<div class="ribb"></div>
<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
<div class="post-content">
<?php the_content_rss('', FALSE, '', 12); ?>
<div class="smore"><a href="<?php the_permalink(); ?>"><?php _e( 'Read more') ?></a></div>
</div>

</div>
</div>

<?php endwhile; ?>
 </div>

            <a href="javascript: void(0);" id="larr"></a>
            <a href="javascript: void(0);" id="rarr"></a>
</div>
</div>
</div>
<?php } else { ?>
<?php } ?>

<div class="scol">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad2') ) : ?>
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />
<?php endif; ?>
</div>

<?php if ( (is_home())  ) { ?>
<div class="widget widget_recentposts_thumbnail">
<h3><?php _e( 'Popular posts') ?></h3>
<div class="widget-body clear">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=-37');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="rpthumb clear">
<?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'mini-thumbnail'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="50px" height="50px" alt="<?php the_title(); ?>" />
<?php endif;?>
<span class="rpthumb-title"><?php the_title(); ?></span>
</a>
<small style="float:right;margin:-25px 0 0 0;"><?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></small>
<?php endwhile; ?>
</div>
</div>
<?php } else { ?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) :
        $widget_args = array(
            'after_widget' => '</div></div>',
            'before_title' => '<h3>',
            'after_title' => '</h3><div class="widget-body clear">'
        );
?>
<?php endif; ?>
<?php } ?>

<?php if ( (is_single())  ) { ?>
<div class="scol">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad3') ) : ?>
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />
<?php endif; ?>
</div>
<?php } else { ?>
<div class="widget">
<div class="widget-body clear">  
<div class="slideshow"><div id="slideshow">

<?php 
	$my_query = new WP_Query('category_name=&showposts=8&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="slide clear">
<div class="post">
<?php
    if(has_post_thumbnail()) :?>
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php $browse_img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $browse_img; ?></a>
<?php else :?>
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="100%" height="auto" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
<div class="ribb"></div>
<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
<div class="post-content">
<?php the_content_rss('', FALSE, '', 12); ?>
<div class="smore"><a href="<?php the_permalink(); ?>"><?php _e( 'Read more') ?></a></div>
</div>

</div>
</div>

<?php endwhile; ?>
 </div>

            <a href="javascript: void(0);" id="larr"></a>
            <a href="javascript: void(0);" id="rarr"></a>
</div>
</div>
</div>
<?php } ?>

</div>
</div>