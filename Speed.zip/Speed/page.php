<?php get_header(); ?>

<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
<div id="front" class="animated fadeIn">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="xcontentdiv1" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
</div>
<div class="xcontentdiv">
<div class="xslidetxt">
<div class="post-category"><?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?></div>
<h1><?php the_title(); ?></h1>
<div class="post-meta">
<?php edit_post_link( __( 'Edit entry'), '<em>&bull; </em>'); ?>
</div>
</div>
<div class="content-title">
<div class="socials">

</div>
</div>
<div class="post-navigation clear">
                <?php
                    $prev_post = get_adjacent_post(false, '', true);
                    $next_post = get_adjacent_post(false, '', false); ?>
                    <?php if ($prev_post) : $prev_post_url = get_permalink($prev_post->ID); $prev_post_title = $prev_post->post_title; ?>
                        <a class="post-prev" href="<?php echo $prev_post_url; ?>"><em>Previous page</em><span><?php echo $prev_post_title; ?></span></a>
                    <?php endif; ?>
                    <?php if ($next_post) : $next_post_url = get_permalink($next_post->ID); $next_post_title = $next_post->post_title; ?>
                        <a class="post-next" href="<?php echo $next_post_url; ?>"><em>Next page</em><span><?php echo $next_post_title; ?></span></a>
                    <?php endif; ?>
</div>                   
</div>
</div>

<div id="white" class="animated fadeIn">
<div class="white">

<div id="content">
<div class="in">

<div class="entry">
            <div <?php post_class('single clear'); ?> id="post_<?php the_ID(); ?>">
            
                <div class="post-content"><?php the_content(); ?></div>
            
            </div>
</div>

<?php endwhile; ?>
<?php endif; ?>

</div>
</div>
</div>
<?php get_template_part('pagebar'); ?>
<?php get_footer(); ?>