<?php get_header(); ?>

<div id="white" class="animated fadeIn">
<div class="white">
<div id="content">
<div class="in">

<?php
/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('shop');
} else {
get_template_part('item');
}
?>
<div class="content-title">
Latest entries
<a href="javascript: void(0);" id="mode"<?php if ($_COOKIE['mode'] == 'grid') echo ' class="flip"'; ?>></a>
</div>

<?php query_posts(array(
        'post__not_in' => $exl_posts,
        'paged' => $paged,
    )
); ?>

<?php get_template_part('loop'); ?>
<?php wp_reset_query(); ?>

</div>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>