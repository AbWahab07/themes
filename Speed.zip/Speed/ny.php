<div id="xyz"> 		
<div class="wrap">

<div class="tl">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column1') ) : ?>
<h1>Speed Magazine Theme</h1>
<div class="ssread"><a class="a-btn" href="https://3oneseven.com/speed-buddypress-theme/">Download</a></div>
<div class="ssread"><a class="a-btn" href="https://wp.3oneseven.com/?wptheme=Speed">Demo</a></div>
<?php endif; ?>
</div>
<div class="tr">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column2') ) : ?>
<a href="https://3oneseven.com/speed-buddypress-theme/"><img src="<?php echo get_template_directory_uri(); ?>/images/speed.png" alt="speed template" /></a>
<?php endif; ?>
</div>
</div> 
</div>