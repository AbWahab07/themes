<div id="slider1" class="contentslide">

<div class="opacitylayer">

<?php 
	$my_query = new WP_Query('showposts=8&offset=5');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="contentdiv">

<div class="slidetxt">
<div class="post-category"><?php the_category(' / '); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

<div class="post-meta">by 
<span class="post-author"><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" title="Posts by <?php the_author(); ?>"><?php the_author(); ?></a></span>
<em>&bull; </em><?php comments_popup_link(__('No Comments'), __('1 Comment'), __('% Comments'), '', __('Comments Closed')); ?> <?php edit_post_link( __( 'Edit entry'), '<em>&bull; </em>'); ?>
</div>
 
<p><?php the_content_rss('', FALSE, '', 25); ?></p>
<div class="fmore"><a title="<?php _e('Read more here'); ?>" href="<?php the_permalink() ?>"><?php _e( 'Read more') ?></a></div>
</div>

 <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="slideimg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"></a>
</div>
                    
</div>

<?php endwhile; ?>

</div>

<div class="pagination" id="paginate-slider1"></div>
<script type="text/javascript">
ContentSlider("slider1", 9000) 
</script>

<div class="ribbon"></div>
</div>