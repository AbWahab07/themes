<div class="mangle">
<ul class="ca-menu">
                    <li>
                        <a href="">
                            <span class="ca-icon"><img src="<?php bloginfo('template_url'); ?>/images/icon/facebook.png" alt="facebook" /></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Friend us on Facebook</h2>
                                <h3 class="ca-sub">Facebook</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="ca-icon"><img src="<?php bloginfo('template_url'); ?>/images/icon/twitter.png" alt="twitter" /></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Follow us on Twitter</h2>
                                <h3 class="ca-sub"></h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="ca-icon" id="heart"><img src="<?php bloginfo('template_url'); ?>/images/icon/rss.png" alt="pinterest" /></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Follow on Pinterest</h2>
                                <h3 class="ca-sub"></h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="ca-icon"><img src="<?php bloginfo('template_url'); ?>/images/icon/mail.png" alt="dribble" /></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Follow on Dribble</h2>
                                <h3 class="ca-sub"></h3>
                            </div>
                        </a>
                    </li>
                    
</ul>
</div>

<div class="clearfix"></div><hr class="clear" />
<div class="col4">
<?php if ( !function_exists('dynamic_sidebar')
 || !dynamic_sidebar('footer-column111') ) : ?>

<h3 class="widgettitle"><?php _e( 'Topi', 'Detox') ?><span><?php _e( 'cs', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_list_categories('orderby=name&show_count=1&title_li=&number=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>

<div class="col5">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column211') ) : ?>

<h3 class="widgettitle"><?php _e( 'Recent', 'Detox') ?> <span><?php _e( 'Comments', 'Comments') ?></span></h3>

<?php
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
comment_post_ID, comment_author, comment_date_gmt, comment_approved,
comment_type,comment_author_url,
SUBSTRING(comment_content,1,30) AS com_excerpt
FROM $wpdb->comments
LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
$wpdb->posts.ID)
WHERE comment_approved = '1' AND comment_type = '' AND
post_password = ''
ORDER BY comment_date_gmt DESC
LIMIT 5";
$comments = $wpdb->get_results($sql);
$output = $pre_HTML;
$output .= "\n<ul>";
foreach ($comments as $comment) {
$output .= "\n<li>".strip_tags($comment->comment_author)
.": " . "<a href=\"" . get_permalink($comment->ID) .
"#comment-" . $comment->comment_ID . "\" title=\"on " .
$comment->post_title . "\">" . strip_tags($comment->com_excerpt)
."&hellip;</a></li>";
}
$output .= "\n</ul>";
$output .= $post_HTML;
echo $output;?>

<?php endif; ?>
</div>

<div class="col6">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column311') ) : ?>

<h3 class="widgettitle">Pop<span>ular</span></h3>

<ul id="popular-comments">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=-37');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>
<li>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?> <small><?php comments_popup_link('No Comments;', '1 Comment', '% Comments'); ?></small></a>
</li>
<?php endwhile; ?>
</ul>

<?php endif; ?>
</div>

<div class="col7">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column411') ) : ?>

<h3 class="widgettitle"><?php _e( 'Archi', 'Detox') ?><span><?php _e( 'ves', 'Detox') ?></span></h3>

<div class="cats">
<ul><?php wp_get_archives('type=monthly&show_post_count=0&limit=8'); ?></ul>
</div>

<?php endif; ?>

</div>