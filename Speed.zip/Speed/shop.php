<div id="slider1" class="contentslide">

<div class="opacitylayer">

<?php $loop = new WP_Query( array( 'post_type' => 'product', 'posts_per_page' => 6 ) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>
<div class="contentdiv">

<div class="slidetxt">
<div class="post-category"><?php echo $product->get_categories( ', ', '<span class="posted_in">' . _n( '', '', sizeof( get_the_terms( $post->ID, 'product_cat' ) ), 'woocommerce' ) . ' ', '.</span>' ); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php echo get_the_title(); ?>"><?php echo get_the_title(); ?></a></h2>

<div class="post-meta">
<span class="post-author"><?php echo $product->get_price_html(); ?></span>
<?php edit_post_link( __( '<em>&bull; </em> Edit entry'), '<em>&bull; </em>'); ?>
</div>
 
<?php echo apply_filters( 'woocommerce_short_description', $post->post_excerpt ) ?>
<div class="fmore"><a title="<?php _e('View Item'); ?>" href="<?php the_permalink() ?>"><?php _e( 'View Item') ?></a></div>
</div>

<div class="slideimg">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
<?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="100%" height="auto" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
</a>
</div>                    
</div>

<?php endwhile; wp_reset_query(); ?>

</div>

<div class="pagination" id="paginate-slider1"></div>
<script type="text/javascript">
ContentSlider("slider1", 9000) 
</script>

<div class="ribbon"></div>
</div>