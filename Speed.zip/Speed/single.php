<?php get_header(); ?>

<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
<div id="front" class="animated fadeIn">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="xcontentdiv1" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="crong"></div>
</div>
<div class="xcontentdiv">
<div class="xslidetxt">
<div class="post-category"><?php the_category(' / '); ?></div>
<h1><?php the_title(); ?></h1>
<div class="post-meta">by 
<span class="post-author"><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" title="Posts by <?php the_author(); ?>"><?php the_author(); ?></a></span>
<em>&bull; </em><?php comments_popup_link(__('No Comments'), __('1 Comment'), __('% Comments'), '', __('Comments Closed')); ?> <?php edit_post_link( __( 'Edit entry'), '<em>&bull; </em>'); ?>
</div>
</div>
<div class="content-title">
<div class="socials">
          
</div>
</div>
<div class="post-navigation clear">
                <?php
                    $prev_post = get_adjacent_post(false, '', true);
                    $next_post = get_adjacent_post(false, '', false); ?>
                    <?php if ($prev_post) : $prev_post_url = get_permalink($prev_post->ID); $prev_post_title = $prev_post->post_title; ?>
                        <a class="post-prev" href="<?php echo $prev_post_url; ?>"><em>Previous post</em><span><?php echo $prev_post_title; ?></span></a>
                    <?php endif; ?>
                    <?php if ($next_post) : $next_post_url = get_permalink($next_post->ID); $next_post_title = $next_post->post_title; ?>
                        <a class="post-next" href="<?php echo $next_post_url; ?>"><em>Next post</em><span><?php echo $next_post_title; ?></span></a>
                    <?php endif; ?>
</div>                   
</div>
</div>

<div id="white" class="animated fadeIn">
<div class="white">

<div id="content">
<div class="in">

<div class="entry">
            <div <?php post_class('single clear'); ?> id="post_<?php the_ID(); ?>">            
                <div class="post-content"><?php the_content(); ?></div>
                <div class="post-footer"><?php the_tags(__('<strong>Tags: </strong>'), ', '); ?></div>
            </div>

<div class="sc">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad4') ) : ?>
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />
<?php endif; ?>
</div>
                        
<div class="bolism">
<div class="rel">
<?php if ( get_the_author_meta( 'description' ) ) :  ?>
<div class="author-avatar alignright">
<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 60 ) ); ?>
</a>
</div>

<div id="author-description">
<h4><?php printf( esc_attr__( 'About %s', 'Bruce' ), get_the_author() ); ?> :</h4>
<p><?php the_author_meta( 'description' ); ?> | <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'View all posts by %s <span class="meta-nav">&rarr;</span>', 'Bruce' ), get_the_author() ); ?></a><?php edit_post_link(' | Edit','',''); ?></p>
</div>
<?php endif; ?>
</div>
</div>

<?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>
            
</div>
	
<?php endwhile; ?>
<?php endif; ?>

</div>
</div>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>