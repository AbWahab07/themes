<?php get_header(); ?>

<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>

<div id="white" class="animated fadeIn">
<div class="white">

<div id="content">
<div class="in">

<div class="entry">
            <div <?php post_class('single clear'); ?> id="post_<?php the_ID(); ?>">
            
                <div class="post-content"><?php the_content(); ?></div>
            
            </div>
</div>

<?php endwhile; ?>
<?php endif; ?>

</div>
</div>
</div>
<?php get_template_part('pagebar'); ?>
<?php get_footer(); ?>