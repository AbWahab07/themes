<?php get_header(); ?>


<div class="content-title">
    <h2>404! We couldn't find the page!</h2>
</div>

<div class="entry">
    <div <?php post_class('single clear'); ?> id="post_<?php the_ID(); ?>">
        <div class="post-content">
            <p>The page you've requested can not be displayed. It appears you've missed your intended destination, either through a bad or outdated link, or a typo in the page you were hoping to reach.</p>

<h2>Try searching</h2>
                <div class="search">
                    <form method="get" id="searchform" action="<?php bloginfo('url'); ?>">
                        <fieldset>
                            <input name="s" type="text" onfocus="if(this.value=='Search with some different keywords') this.value='';" onblur="if(this.value=='') this.value='Search with some different keywords';" value="Search with some different keywords" />
                            <button type="submit"></button>
                        </fieldset>
                    </form>
                </div>
                
<?php the_widget( 'Recentposts_thumbnail', 'title=Recent posts', $widget_args); ?>

<div class="clearfix"></div><hr class="clear" />
<h2><?php _e( 'Topics', 'speed') ?></h2>
<ul>
<?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0&feed=RSS'); ?>
</ul>

        </div>
    </div>
</div>



<?php get_footer(); ?>