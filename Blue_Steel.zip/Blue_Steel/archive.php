<?php get_header(); ?>

<section id="wrapper">

<section id="banner">
						<div class="inner">
							<div class="logo"><span class="icon fa-bookmark-o"></span></div>
							<h2><?php bloginfo('name'); ?></h2>
							<p><?php bloginfo('description'); ?></p>
						</div>
</section>


<section id="four" class="wrapper alt style1">
<div class="inner">

<section class="features">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<article>
 
											<a href="<?php the_permalink() ?>" class="image">
                      <?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
											<h3 class="major"><?php the_title(); ?></h3>
											<p><?php the_content_rss('', FALSE, '', 20); ?></p>
                      <a href="<?php the_permalink() ?>" class="special"><?php _e('Learn more', 'Detox') ?></a>

</article>
<?php endwhile; else: ?>
<article><p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p></article>
<?php endif; ?> 
 
</section>

<section>
<div class="inner navigation">
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
</div>
</section>

</div>
</section>

</section>
<?php get_footer(); ?>