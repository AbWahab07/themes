<?php
/*
Template Name: shopp full width Template
*/
?>
<?php get_header(); ?>

<section id="wrapper">

<header>
<div class="inner">
<h2>Shop</h2>
<p><?php bloginfo('description'); ?></p>
</div>
</header>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="wrapper">
<div class="inner">
<section>
<?php the_content(__('Read more', 'Detox'));?>
<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
</section>

</div>
</div>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p>
<?php endif; ?>  
</section>
<?php get_footer(); ?>