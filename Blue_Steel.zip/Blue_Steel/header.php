<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />

<link rel="shortcut icon" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/images/ico/favicon.png" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<!--[if lte IE 8]><script src="<?php echo get_template_directory_uri(); ?>/assets/js/ie/html5shiv.js"></script><![endif]-->
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/main.css" />
<!--[if lte IE 9]><link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/ie9.css" /><![endif]-->
<!--[if lte IE 8]><link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/ie8.css" /><![endif]-->



<?php wp_head(); ?>

</head>

<body <?php body_class(); ?> id="blue_steel_theme_by_milo317">
<div id="page-wrapper">
<?php if ( (is_home())  ) { ?><header id="header" class="alt"><?php } else { ?><header id="header" class=""><?php } ?>
<div class="inner">
<div class="logo"><span class="icon fa-bookmark-o"></span></div><h1><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1>
<nav>
<a href="#menu"><?php _e('Menu', 'Detox') ?></a>
</nav>
</div>
</header>

<nav id="menu">
<div class="inner">
<h2><?php _e('Menu', 'Detox') ?></h2>
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'top-nav',
'menu_class' => 'links',
'container_id' => 'top-nav',
'menu_id' => 'nav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>
<a href="#" class="close"><?php _e('Close', 'Detox') ?></a>
</div>
</nav>