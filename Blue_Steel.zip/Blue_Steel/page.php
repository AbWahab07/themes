<?php get_header(); ?>

<section id="wrapper">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<header>
<div class="inner">
<h2><?php the_title(); ?></h2>
<p><?php the_category(' <span>/</span> '); ?> <?php _e('by', 'Detox'); ?> <?php the_author_posts_link(); ?></p>
</div>
</header>

<div class="wrapper">
<div class="inner">
<section>
<?php the_content(__('Read more', 'Detox'));?>
<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
</section>

</div>
</div>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p>
<?php endif; ?>  
</section>
<?php get_footer(); ?>