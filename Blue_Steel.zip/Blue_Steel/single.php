<?php get_header(); ?>

<section id="wrapper">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<header>
<div class="inner">
<h2><?php the_title(); ?></h2>
<p><?php the_category(' <span>/</span> '); ?> <?php _e('by', 'Detox'); ?> <?php the_author_posts_link(); ?></p>
</div>
</header>

<div class="wrapper">
<div class="inner">

<section>
<div class="entry">
<?php the_content(__('Read more', 'Detox'));?>
<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
<h3><?php edit_post_link('Edit','',''); ?></h3>
</div>
</section>

<section>
  
<div class="row">
<div class="6u 12u$(medium)">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('pagebar') ) : ?>
          
<?php if ( get_the_author_meta( 'description' ) ) :  ?>
<span class="image left">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 90 ) ); ?>
</span>

<div id="author-description">
<h4><?php printf( esc_attr__( 'About %s', 'Bruce' ), get_the_author() ); ?> :</h4>
<?php the_author_meta( 'description' ); ?> | <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'View all posts by %s <span class="meta-nav">&rarr;</span>', 'Bruce' ), get_the_author() ); ?><?php edit_post_link(' | Edit','',''); ?></a>
</div>
<?php endif; ?>

<?php endif; ?>

</div>

<div class="6u 12u$(medium)">
<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('widgetbar') ) : ?>
          
<h4><?php _e('Related Posts', 'Detox'); ?></h4>
<?php 
$max_articles = 4; // How many articles to display 
echo '<ul class="list columns">'; 
$cnt = 0; $article_tags = get_the_tags(); 
$tags_string = ''; 
if ($article_tags) { 
foreach ($article_tags as $article_tag) { 
$tags_string .= $article_tag->slug . ','; 
} 
} 
$tag_related_posts = get_posts('exclude=' . $post->ID . '&numberposts=' . $max_articles . '&tag=' . $tags_string); 
if ($tag_related_posts) { 
foreach ($tag_related_posts as $related_post) { 
$cnt++; 
echo '<li class="child-' . $cnt . '">'; 
echo '<a href="' . get_permalink($related_post->ID) . '">'; 
echo $related_post->post_title . '</a></li>'; 
} 
} 
if ($cnt < $max_articles) { 
$article_categories = get_the_category($post->ID); 
$category_string = ''; 
foreach($article_categories as $category) { 
$category_string .= $category->cat_ID . ','; 
} 
$cat_related_posts = get_posts('exclude=' . $post->ID . '&numberposts=' . $max_articles . '&category=' . $category_string); 
if ($cat_related_posts) { 
foreach ($cat_related_posts as $related_post) { 
$cnt++; 
if ($cnt > $max_articles) break; 
echo '<li class="child-' . $cnt . '">'; 
echo '<a href="' . get_permalink($related_post->ID) . '">'; 
echo $related_post->post_title . '</a></li>'; 
} 
} 
} 
echo '</ul>'; 
?>

<?php endif; ?>
</div>
</div>

</section>

<div class="clearfix"></div><hr class="clear" />

<section>
<div class="post-navigation clear">
                <?php
                    $prev_post = get_adjacent_post(false, '', true);
                    $next_post = get_adjacent_post(false, '', false); ?>
                    <?php if ($prev_post) : $prev_post_url = get_permalink($prev_post->ID); $prev_post_title = $prev_post->post_title; ?>
                        <a class="post-prev" href="<?php echo $prev_post_url; ?>"><em><?php _e('Previous post', 'Detox'); ?></em><span><?php echo $prev_post_title; ?></span></a>
                    <?php endif; ?>
                    <?php if ($next_post) : $next_post_url = get_permalink($next_post->ID); $next_post_title = $next_post->post_title; ?>
                        <a class="post-next" href="<?php echo $next_post_url; ?>"><em><?php _e('Next post', 'Detox'); ?></em><span><?php echo $next_post_title; ?></span></a>
                    <?php endif; ?>

</div>
</section>

 <?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>

</div>
</div>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p>
<?php endif; ?>  
</section>
<?php get_footer(); ?>