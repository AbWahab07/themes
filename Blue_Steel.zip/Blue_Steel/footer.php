<section id="footer">
<div class="inner">

<div class="row">
<div class="6u 12u$(medium)">

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column1') ) : ?>

<h3><a href="<?php echo get_settings('home'); ?>/wp-admin/widgets.php">Widgetized <span>Section</span></a></h3>

<ul >
<li><a title="3oneseven" href="https://3oneseven.com/">3oneseven</a></li>
<li><a href="https://goo.gl/eV9NcW">Echinger strasse 10e</a></li>
<li>Bayern</li>
<li><span class="locality" itemprop="addressLocality">Deutschland</span></li>
<li><a rel="nofollow" href="tel:+49 173 4298898" title="Phone through">+49 173 4298898</a></li>
<li><time itemprop="openingHours" datetime="Mo-Fr">M - F: 9:30 - 5:30</time></li>
<li><time itemprop="openingHours" datetime="Sat">S:    10:00 - 5:00</time></li>
</ul>

<?php endif; ?>

</div>

<div class="6u 12u$(medium)">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column2') ) : ?>

<h3><a href="<?php echo get_settings('home'); ?>/wp-admin/widgets.php">Widgetized <span>Section</span></a></h3>

<ul >
<li><a title="3oneseven" href="https://3oneseven.com/">3oneseven</a></li>
<li><a href="https://goo.gl/eV9NcW">Echinger strasse 10e</a></li>
<li>Bayern</li>
<li><span class="locality" itemprop="addressLocality">Deutschland</span></li>
<li><a rel="nofollow" href="tel:+49 173 4298898" title="Phone through">+49 173 4298898</a></li>
<li><time itemprop="openingHours" datetime="Mo-Fr">M - F: 9:30 - 5:30</time></li>
<li><time itemprop="openingHours" datetime="Sat">S:    10:00 - 5:00</time></li>
</ul>

<?php endif; ?>
</div>
</div>
						
<ul class="copyright">
<li><?php _e('Copyright', 'Detox') ?> &copy; <?php echo date("Y"); ?> <?php _e('All rights reserved', 'Detox') ?>.</li><li><a class="no-link" href="https://3oneseven.com/">Website design by milo</a></li>
<li>
<div id="gnavigation" style="font-size:10px"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/blue-steel-wordpress-theme/" >Theme</a> <span>BlueSteel theme</span>
</span>
</span>
</span>
</div>
</li>
</ul>

</div>
</section>

</div>

<?php wp_footer(); ?>
			<script src="<?php echo get_template_directory_uri(); ?>/assets/js/skel.min.js"></script>
			<script src="<?php echo get_template_directory_uri(); ?>/assets/js/jquery.min.js"></script>
			<script src="<?php echo get_template_directory_uri(); ?>/assets/js/jquery.scrollex.min.js"></script>
			<script src="<?php echo get_template_directory_uri(); ?>/assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="<?php echo get_template_directory_uri(); ?>/assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="<?php echo get_template_directory_uri(); ?>/assets/js/main.js"></script>
            <script src="<?php echo get_template_directory_uri(); ?>/assets/js/instant.js" type="text/javascript"></script>
</body>
</html>