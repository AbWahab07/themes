<?php get_header(); ?>

					<section id="banner">
						<div class="inner">
							<div class="logo"><span class="icon fa-bookmark-o"></span></div>
							<h2>Blue Steel</h2>
							<p><?php bloginfo('description'); ?></p>
						</div>
					</section>

					<section id="wrapper">

							<section id="one" class="wrapper spotlight style1">
              <?php 
$my_query = new WP_Query('showposts=1&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
								<div class="inner">
									<a href="<?php the_permalink() ?>" class="image">
                      <?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
									<div class="content">
										<h2 class="major"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
									<p><?php the_content_rss('', FALSE, '', 20); ?></p>
										<a href="<?php the_permalink() ?>" class="special"><?php _e('Learn more', 'Detox') ?></a>
									</div>
								</div>
                 <?php endwhile; ?> 
							</section>

							<section id="two" class="wrapper alt spotlight style2">
<?php 
$my_query = new WP_Query('showposts=1&offset=1');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>              
								<div class="inner">
									<a href="<?php the_permalink() ?>" class="image">
                      <?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
<div class="content">
										<h2 class="major"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
										<p><?php the_content_rss('', FALSE, '', 20); ?></p>
                    <a href="<?php the_permalink() ?>" class="special"><?php _e('Learn more', 'Detox') ?></a>
									</div>
								</div>
                <?php endwhile; ?> 
							</section>

							<section id="three" class="wrapper spotlight style3">
<?php 
$my_query = new WP_Query('showposts=1&offset=2');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>              
								<div class="inner">
									<a href="<?php the_permalink() ?>" class="image">
                      <?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
<div class="content">
										<h2 class="major"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
										<p><?php the_content_rss('', FALSE, '', 20); ?></p>
                    <a href="<?php the_permalink() ?>" class="special"><?php _e('Learn more', 'Detox') ?></a>
									</div>
								</div>
                <?php endwhile; ?> 
							</section>


							<section id="four" class="wrapper alt style1">
           
								<div class="inner">
                 <?php 
$my_query = new WP_Query('showposts=1&offset=3');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>  
									<h2 class="major"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
									<p><?php the_content_rss('', FALSE, '', 20); ?></p>
                  <?php endwhile; ?> 
                  <section class="features">
										<article>
                     <?php 
$my_query = new WP_Query('showposts=1&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>  
											<a href="<?php the_permalink() ?>" class="image">
                      <?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
<h3 class="major"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
											<p><?php the_content_rss('', FALSE, '', 20); ?></p>
                      <a href="<?php the_permalink() ?>" class="special"><?php _e('Learn more', 'Detox') ?></a>
                      <?php endwhile; ?> 
										</article>
										<article>
                    <?php 
$my_query = new WP_Query('showposts=1&offset=5');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>   
											<a href="<?php the_permalink() ?>" class="image">
                      <?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
<h3 class="major"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
											<p><?php the_content_rss('', FALSE, '', 20); ?></p>
                      <a href="<?php the_permalink() ?>" class="special"><?php _e('Learn more', 'Detox') ?></a>
                      <?php endwhile; ?> 
										</article>
										<article>
                     <?php 
$my_query = new WP_Query('showposts=1&offset=6');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>  
											<a href="<?php the_permalink() ?>" class="image">
                      <?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
<h3 class="major"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
											<p><?php the_content_rss('', FALSE, '', 20); ?></p>
                      <a href="<?php the_permalink() ?>" class="special"><?php _e('Learn more', 'Detox') ?></a>
                      <?php endwhile; ?> 
										</article>
										<article>
                     <?php 
$my_query = new WP_Query('showposts=1&offset=7');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>  
											<a href="<?php the_permalink() ?>" class="image">
                      <?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
<h3 class="major"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
											<p><?php the_content_rss('', FALSE, '', 20); ?></p>
                      <a href="<?php the_permalink() ?>" class="special"><?php _e('Learn more', 'Detox') ?></a>
                      <?php endwhile; ?> 
										</article>
									</section>
									<ul class="actions">
										<li><a href="<?php the_permalink() ?>" class="button"><?php _e('Browse All', 'Detox') ?></a></li>
									</ul>
								</div>
							</section>

					</section>

<?php get_footer(); ?>