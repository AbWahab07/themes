<?php get_header(); ?>

<?php get_template_part('item'); ?>

<div id="front">
<div class="col11">
<?php 
$my_query = new WP_Query('showposts=1&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>

<div class="entry">
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<div class="more"><a href="<?php the_permalink() ?>">Read More</a></div>
</div>

<?php endwhile; ?>
</div>

<div class="col12">		        
<?php 
$my_query = new WP_Query('showposts=1&offset=5');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>

<div class="entry">
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<div class="more"><a href="<?php the_permalink() ?>">Read More</a></div>
</div>

<?php endwhile; ?>
</div>

<div class="col13">
<?php 
$my_query = new WP_Query('showposts=1&offset=6');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
		        
<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>

<div class="entry">
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<div class="more"><a href="<?php the_permalink() ?>">Read More</a></div>
</div>

<?php endwhile; ?>
</div>

<div class="col14">
<?php 
$my_query = new WP_Query('showposts=1&offset=7');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>

<div class="entry">
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<div class="more"><a href="<?php the_permalink() ?>">Read More</a></div>
</div>

<?php endwhile; ?>
</div>
</div>

<?php
/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('shop');
} else {
}
?>

</div>
</div>
<?php get_footer(); ?>