<?php get_header(); ?>

<div id="sow" class="animated fadeIn">
<div id="content">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="entry">
<div class="mof">
<?php if ( wp_attachment_is_image( $post->id ) ) : $att_image = wp_get_attachment_image_src( $post->id, "full"); ?>
<a href="<?php echo get_permalink($post->post_parent); ?>" rev="attachment">
<img src="<?php echo $att_image[0];?>" class="aligncenter" title="<?php echo get_the_title($post->post_parent); ?>" alt="<?php echo get_the_title($post->post_parent); ?>" /></a>
<?php else : ?><?php endif; ?>
<h1 class="mifo"><?php echo get_the_title($post->post_parent); ?></h1>

<div class="sag">
<div class="alignleft"><?php previous_image_link( false, '&#8249;&#8249; Previous Image' ); ?> </div>
<div class="alignright"><?php next_image_link( false, 'Next Image &#8250; &#8250;' ) ?></div>
</div>

</div>
</div>

<?php endwhile; else: ?>
<p>Sorry, no attachments matched your criteria.</p>
<?php endif; ?>


</div>
</div>
</div>
</div>
<?php get_footer(); ?>