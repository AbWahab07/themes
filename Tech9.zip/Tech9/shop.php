<div id="slider1" class="contentslide">

<div class="opacitylayer">

<?php $loop = new WP_Query( array( 'post_type' => 'product', 'posts_per_page' => 3 ) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>
<div class="col11">

<div class="slidetxt">
<div class="post-category"><?php echo $product->get_categories( ', ', '<span class="posted_in">' . _n( '', '', sizeof( get_the_terms( $post->ID, 'product_cat' ) ), 'woocommerce' ) . ' ', '.</span>' ); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php echo get_the_title(); ?>"><?php echo get_the_title(); ?></a></h2>

<div class="post-meta">
<span class="post-author"><?php echo $product->get_price_html(); ?></span>
<?php edit_post_link( __( '<em>&bull; </em> Edit entry'), '<em>&bull; </em>'); ?>
</div>

</div>

<div class="slideimg">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
<?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="100%" height="auto" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
</a>
</div>
<?php echo apply_filters( 'woocommerce_short_description', $post->post_excerpt ) ?>
<div class="more"><a title="<?php _e('View Item'); ?>" href="<?php the_permalink() ?>"><?php _e( 'View Item') ?></a></div>                    
</div>

<?php endwhile; wp_reset_query(); ?>

</div>

<?php $loop = new WP_Query( array( 'post_type' => 'product', 'offset' => 3, 'posts_per_page' => 1 ) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>
<div class="col14">

<div class="slidetxt">
<div class="post-category"><?php echo $product->get_categories( ', ', '<span class="posted_in">' . _n( '', '', sizeof( get_the_terms( $post->ID, 'product_cat' ) ), 'woocommerce' ) . ' ', '.</span>' ); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php echo get_the_title(); ?>"><?php echo get_the_title(); ?></a></h2>

<div class="post-meta">
<span class="post-author"><?php echo $product->get_price_html(); ?></span>
<?php edit_post_link( __( '<em>&bull; </em> Edit entry'), '<em>&bull; </em>'); ?>
</div>

</div>

<div class="slideimg">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
<?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="100%" height="auto" alt="<?php the_title(); ?>" /></a>
<?php endif;?>
</a>
</div>
<?php echo apply_filters( 'woocommerce_short_description', $post->post_excerpt ) ?>
<div class="more"><a title="<?php _e('View Item'); ?>" href="<?php the_permalink() ?>"><?php _e( 'View Item') ?></a></div>                    
</div>

<?php endwhile; wp_reset_query(); ?>
<div class="ribbon"></div>
</div>