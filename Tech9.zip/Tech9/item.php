<div id="item" class="animated fadeIn">
<div id="slider">
<script type="text/javascript">
featuredcontentglider.init({
	gliderid: "glidercontent",
	contentclass: "glidecontent",
	togglerid: "togglebox",
	remotecontent: "", 
	selected: 0,
	persiststate: true,
	speed: 1000,
	direction: "leftright", 
	autorotate: true, 
	autorotateconfig: [12000, 1] //if auto rotate enabled, set [milliseconds_btw_rotations, cycles_before_stopping]
})
</script>

<div id="glidercontent" class="glidecontentwrapper">

<?php 
$my_query = new WP_Query('showposts=4&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="glidecontent">
<div class="simg">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="slo"><a href="<?php the_permalink() ?>"><img src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></a></div>
</div>
<div class="itemtxt">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<div class="read"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e("Learn more"); ?>"><?php _e("Read more"); ?></a></div>
</div>
</div>
<?php endwhile; ?>


</div>


<div id="htabs">
<div id="togglebox" class="glidecontenttoggler">
<a href="#" class="prev"></a>

<?php 
$my_query = new WP_Query('showposts=4&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<a href="#" class="toc"><?php the_title(); ?></a>
<?php endwhile; ?>

<a href="#" class="next"></a>
</div>
</div>

</div>
</div>