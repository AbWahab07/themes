<?php
/*
Template Name: fullwidth template
*/
?><?php get_header(); ?>

<div id="sow" class="animated fadeIn">
<div id="content">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="entry">
<?php the_content(__('Read more'));?>
</div>

<?php endwhile; else: ?>
<p>Sorry, no attachments matched your criteria.</p>
<?php endif; ?>


</div>
</div>
</div>
</div>
<?php get_footer(); ?>