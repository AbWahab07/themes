<?php get_header(); ?>

<div id="sow" class="animated fadeIn">

<div id="content">

<div id="middle">
<h3>Search <span>Result</span> </h3>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>

<div class="entry">
<div class="simg">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="slomo"><a href="<?php the_permalink() ?>"><img src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></a></div>
</div>
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>

<div class="more"><a href="<?php the_permalink() ?>">Read More</a></div>
</div>
<div class="postspace"></div>


<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>

<div class="navigation">
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
</div>

</div>
<?php get_template_part('sidebar'); ?>
</div>
</div>
</div>

</div>
<?php get_footer(); ?>