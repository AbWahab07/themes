<div id="sidebar">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('blog-sidebar2') ) : ?>
	        

<h2><?php _e("Recently"); ?></h2>
<ul>
<?php get_archives('postbypost', 4); ?>
</ul>

<h2><?php _e("Categories"); ?></h2>
<ul>
<?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?>
</ul>
		
<h2><?php _e("Archive"); ?></h2>
<ul>
<?php wp_get_archives('type=monthly&show_post_count=true'); ?>
</ul>
        
<?php endif; ?>

</div>