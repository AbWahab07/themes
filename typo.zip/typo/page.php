<?php get_header(); ?>

<div id="xcontent" class="animated fadeIn">
  <?php if (have_posts()) : ?>
  <?php $post = $posts[0];  ?>
  <?php if (is_category()) { ?>
  <h2 class="pagetitle">&#8216;
    <?php single_cat_title(); ?>
    &#8217;
    <?php _e('Category', 'Detox')?>
  </h2>
  <?php  } elseif (is_day()) { ?>
  <h2 class="pagetitle">    <?php _e('Archive for', 'Detox')?>    <?php the_time('F jS, Y', 'Detox'); ?>  </h2>
  
  <?php  } elseif (is_month()) { ?>
  <h2 class="pagetitle">    <?php _e('Archive for', 'Detox')?>    <?php the_time('F, Y', 'Detox'); ?>  </h2>
  
  <?php } elseif (is_year()) { ?>
  <h2 class="pagetitle">    <?php _e('Archive for', 'Detox')?>    <?php the_time('Y', 'Detox'); ?>  </h2>
  
  <?php  } elseif (is_search()) { ?>
  <h2 class="pagetitle">    <?php _e('Search results for', 'Detox')?>    &#8216;&#8216;<?php echo($s); ?> &#8217;&#8217; </h2>
    <?php } ?>
  
  <?php while (have_posts()) : the_post(); ?>
  <div class="post" id="post-<?php the_ID(); ?>">
    <h1><?php the_title(); ?></h1>
      
    <?php if(!is_page()) {  ?>
    <small> 
    <?php _e('Written on', 'Detox')?>
    <?php the_time('M', 'Detox') ?> <?php the_time('d') ?>, <?php the_time('Y', 'Detox') ?>
    <?php _e('I', 'Detox')?> <?php the_category(', ') ?>.
    </small>
    
    <?php }  ?>
    <?php if(!is_search()) :  ?>
    <div class="entry">
      <?php the_content(__('Read more', 'Detox'));?>
    </div>
    <?php endif;  ?>
    <?php if(!is_page()) {  ?>
    <?php if(is_single()) : ?>

  
    
    
    <?php else :  ?>

   
    <?php endif; ?>
    <?php }  ?>
  </div>
  <?php if(is_single()) :   ?>
  <?php comments_template(); ?>
  <?php endif;  ?>
  <?php endwhile; ?>
  <?php if(is_single() || is_page() ) :  ?>
  <?php else: ?>
  
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
  
  <?php endif;  ?>
  <?php else : ?>
  <p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p>
  <?php endif; ?>
</div>

</div>
<?php get_template_part('sidebar'); ?>
<?php get_template_part('footer'); ?>