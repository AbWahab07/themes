<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('bar-column1') ) : ?>

<?php endif; ?>