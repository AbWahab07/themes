<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="https://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" title="default" media="all" />
<link rel="shortcut icon" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico" />

<?php if(is_front_page()): ?><?php elseif (is_singular()): ?>
<link rel="prefetch" href="<?php echo get_permalink(get_adjacent_post(false,'',true)); ?>">
<link rel="prerender" href="<?php echo get_permalink(get_adjacent_post(false,'',false)); ?>">
<?php else: ?>
<link rel="prefetch" href="<?php echo home_url(); ?>">
<link rel="prerender" href="<?php echo home_url(); ?>">
<?php endif; ?>


<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/contentslider.js"></script>

<?php wp_head(); ?>        

</head>
<body <?php body_class() ?> id="typography_theme_by_milo317">

<div id="wrap">

<div id="container">

<div id="header">
<div id="logo" class="animated slideInDown">
<h1><a title="<?php bloginfo('name'); ?>" href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1>
<div class="des"><?php bloginfo('description'); ?></div>
</div>  


<div id="mnav" class="animated slideInDown">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'top-nav',
'container' => '',
'container_id' => 'top-nav',
'menu_id' => 'navi',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>
<form id="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e( 'Search...', 'Detox') ?>" name="s" id="s" onfocus="if (this.value == '<?php _e( 'Search...', 'Detox') ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e( 'Search more', 'Detox') ?>';}" />
</form>
</div>

</div>