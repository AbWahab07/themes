<?php get_header(); ?>
<div id="content" class="animated fadeIn">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="post" id="post-<?php the_ID(); ?>">

<span class="macky"><?php the_category(', ') ?></span>


<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
      
<small><span class="sigdate">{</span>  <span class="post-comments">
    <?php comments_popup_link(__('No Comment', 'Detox'), __('1 Comment', 'Detox'), __('% Comments', 'Detox'), '', __('Closed', 'Detox')); ?>
    </span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "Tags: None";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?> \ 
    <?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?> }</span></small>
    
 
<div class="entry">
<div class="hcenter fadeIn">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php $image = get_the_post_thumbnail($post->ID, 'cover'); ?><?php echo $image; ?></a>
</div>
<?php the_excerpt(); ?>
<div class="clear"></div>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
</div>

<?php edit_post_link('{Edit this entry}','',''); ?>

</div>
<div class="clear"></div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p>
<?php endif; ?>

<div class="navigation">
<div class="clearfix"></div><hr class="clear" />
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
</div>

</div>
</div>

<div class="no">
<nav class="nav-slide">
<?php next_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>Older<span>Entries</span></h3></div>', 0); ?>
<?php previous_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>Newer<span>Entries</span></h3></div>', 0) ?>
</nav>
</div>
<?php get_template_part('sidebar'); ?>
<?php get_template_part('footer'); ?>