<?php get_header(); ?>

<div id="content" class="animated fadeIn">

 <div class="post" id="post-th">
<span class="macky"><a class="uildlt-uildlt animated fadeIn" itemprop="genre" href="https://3oneseven.com/wordpress-themes/">CSS, Web design, WordPress theme</a></span>
    <h2><a href="https://3oneseven.com/typography-wordpress-theme/">Typography Theme</a></h2>
      
<small><span class="sigdate">{</span>  <span class="post-comments">
    No Comment
    </span> \ \ 
    April<span class="bigdate">4</span></small>
   
    <div class="clear"></div>

    <div class="entry">
<div class="hcenter fadeIn">
<a href="https://3oneseven.com/typography-wordpress-theme/" title="Typography Theme"><img src="https://wp.3oneseven.com/wp-content/themes/typo/images/typography.jpg" width="100%" alt="typography" /></a>
</div>
<p>Featuring a single column responsive layout, enabled with custom field options, custom posts, responsive design & typography.
Theme configuration is easy made via the themes option panel .</p>
<div class="clear"></div>
<div class="more"><span class="bigdate">{</span> <a href="https://3oneseven.com/typography-wordpress-theme/"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>

</div>
</div>

  <?php if (have_posts()) : ?>
  <?php $post = $posts[0];  ?>
  <?php if (is_category()) { ?>
  
  <h2 class="pagetitle">&#8216;
    <?php single_cat_title(); ?>
    &#8217;
    <?php _e('Category', 'Detox')?>
  </h2>
  
  
  <?php  } elseif (is_day()) { ?>
  <h2 class="pagetitle">    <?php _e('Archive for', 'Detox')?>    <?php the_time('F jS, y', 'Detox'); ?>  </h2>
  
  <?php  } elseif (is_month()) { ?>
  <h2 class="pagetitle">    <?php _e('Archive for', 'Detox')?>    <?php the_time('F, y', 'Detox'); ?>  </h2>
  
  <?php } elseif (is_year()) { ?>
  <h2 class="pagetitle">    <?php _e('Archive for', 'Detox')?>    <?php the_time('y', 'Detox'); ?>  </h2>
  
  <?php  } elseif (is_search()) { ?>
  <h2 class="pagetitle">    <?php _e('Search results for', 'Detox')?>    &#8216;&#8216; <?php echo($s); ?> &#8217;&#8217; </h2>
    <?php } ?>
  
  
  <?php while (have_posts()) : the_post(); ?>
  <div class="post" id="post-<?php the_ID(); ?>">
<span class="macky"><?php the_category(', ') ?></span>
    <h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
      
    <?php if(!is_page()) {  ?>
    
    <small><span class="sigdate">{</span>  <span class="post-comments">
    <?php comments_popup_link(__('No Comment', 'Detox'), __('1 Comment', 'Detox'), __('% Comments', 'Detox'), '', __('Closed', 'Detox')); ?>
    </span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "Tags: None";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?> \ 
    <?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?> }</span></small>
   
    <div class="clear"></div>
    <?php }  ?>
    <?php if(!is_search()) :  ?>
    <div class="entry">
<div class="hcenter">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php $image = get_the_post_thumbnail($post->ID, 'cover'); ?><?php echo $image; ?></a>
</div>
<?php the_excerpt(); ?>
<div class="clear"></div>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>

<?php edit_post_link('{Edit this entry}','',''); ?>
    </div>
    <?php endif;  ?>
    <?php if(!is_page()) {  ?>
    <?php if(is_single()) : ?>    
    <?php else :  ?>   
    <?php endif; ?>
    <?php }  ?>
  </div>
  <?php if(is_single()) :   ?>
  <?php comments_template(); ?>
  <?php endif;  ?>
  <?php endwhile; ?>
  <?php if(is_single() || is_page() ) :  ?>
  <?php else: ?>

<div class="navigation">
<div class="clearfix"></div><hr class="clear" />
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
</div>
  
  <?php endif;  ?>
  <?php else : ?>
  <p><?php _e('Sorry, no posts matched your criteria.', 'Detox')?></p>
  <?php endif; ?>
</div>

</div>

<div class="no">
<nav class="nav-slide">
<?php next_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>Older<span>Entries</span></h3></div>', 0); ?>
<?php previous_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>Newer<span>Entries</span></h3></div>', 0) ?>
</nav>
</div>
<?php get_template_part('sidebar'); ?>
<?php get_template_part('footer'); ?>