<?php get_template_part('header'); ?>

<div id="smain" class="animated slideInDown">
<div id="post">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="breaks">
<div class="hc5 view view-first">
<div class="hp">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="round" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>
</a>
<div class="x">
<small> &#183;<div class="author-avatar alignleft"><?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 60 ) ); ?></div> 
<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'all posts by %s ', 'Tracks' ), get_the_author() ); ?></a>&#183; <?php edit_post_link(' <b>Edit</b>','',''); ?></small>
<h1><?php the_title(); ?></h1>
<small><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></small>
</div>
</div>
<div class="mask" style="display:none">
<h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<a href="<?php the_permalink() ?>" class="sinfo"><?php _e('View the article', 'Detox') ?></a>
<div class="xminfo"><a href="<?php the_permalink() ?>"><?php _e('View the article', 'Detox') ?></a></div>
</div>
</div>
</div>

<div class="entry">
<?php the_content(__('Read more', 'Detox'));?>
<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
<?php edit_post_link('<h3 class="alignright">Edit</h3>','',''); ?>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>

<div class="clearfix"></div><hr class="clear" />

<div id="navigation" itemprop="breadcrumb">
<?php _e('You are here', 'Detox') ?>: <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>
</div>
<?php get_template_part('footer'); ?>