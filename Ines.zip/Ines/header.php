<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />

<link rel="shortcut icon" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico" />
<link itemprop="logo" rel="logo" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico" />

<link rel="author" type="text/plain" href="https://wp.3oneseven.com/humans.txt" />

<?php wp_head(); ?>        

 <!--[if lt IE 9]><script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js" type="text/javascript"></script><![endif]-->
<script src="<?php echo get_template_directory_uri(); ?>/js/fluidvids.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.js" type="text/javascript"></script>
</head>
<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="http://schema.org/WebPage">
<progress value="0" id="progressBar"><div class="progress-container"><span class="progress-bar"></span></div></progress>
<main>
<div id="wrapper">

<div id="main">
<div class="wrap">

<div id="fheader" class="animated slideInLeft">
<div id="header">
<div class="inheader">
<div class="head">
<div id="logo"><h1 itemprop="headline"><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1></div>
<h2 itemprop="description" style="display:none;"><?php bloginfo('description'); ?></h2>
</div>

<div class="xmainmenu">
<div class="menu-header" role="banner" itemscope="itemscope" itemtype="http://schema.org/WPHeader">

<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'top-nav',
'container' => '',
'container_id' => 'logo-inner',
'menu_id' => 'top-nav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>

<div class="soc">
<div class="hsoc">
<form id="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e( 'Search...', 'Detox') ?>" name="s" id="s" onfocus="if (this.value == '<?php _e( 'Search...', 'Detox') ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e( 'Search more', 'Detox') ?>';}" />
</form>
</div>
</div>

</div>
</div>
</div>
</div>
</div>