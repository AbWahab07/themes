<?php get_template_part('header'); ?>

<div id="smain">
<div id="post" class="animated slideInDown">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="breaks">
<div class="hc5 view view-first">
<div class="hp">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="round" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>
</a>
<div class="x">
<small> &#183;<?php the_category(' , ') ?>&#183; <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'all posts by %s ', 'Tracks' ), get_the_author() ); ?></a> <?php edit_post_link(' <b>Edit</b>','',''); ?></small>
<h1><?php the_title(); ?></h1>
<small><span class="post-comments">
<?php comments_popup_link(__('No Comment', 'Detox'), __('1 Comment', 'Detox'), __('% Comments', 'Detox'), '', __('Closed', 'Detox')); ?>
</span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?> \ 
<?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></small>
</div>
</div>
<div class="mask" style="display:none">
<h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<a href="<?php the_permalink() ?>" class="sinfo"><?php _e('View the article', 'Detox') ?></a>
<div class="xminfo"><a href="<?php the_permalink() ?>"><?php _e('View the article', 'Detox') ?></a></div>
</div>
</div>
</div>
<div class="entry" itemprop="text">

<div class="clearfix"></div><hr class="clear" />
<?php the_content(__('Read more', 'Detox'));?>
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
<?php edit_post_link('<h3 class="alignright">Edit</h3>','',''); ?>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>

<div class="meta animated slideInRight">

<div class="rel">

<?php $orig_post = $post;
global $post;
$categories = get_the_category($post->ID);
if ($categories) {
$category_ids = array();
foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
$args=array(
'category__in' => $category_ids,
'post__not_in' => array($post->ID),
'posts_per_page'=> 2, // Number of related posts that will be displayed.
'caller_get_posts'=>1,
'orderby'=>'rand' // Randomize the posts
);
$my_query = new wp_query( $args );
if( $my_query->have_posts() ) {
echo '<div id="related_posts">';
while( $my_query->have_posts() ) {
$my_query->the_post(); ?>

<div class="breaks">
<div class="hc5 view view-first">
<div class="hp">
<a href="<?php the_permalink() ?>">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="round" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></div>
</a>
<div class="x">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div ><?php the_excerpt(); ?></div>
</div>
</div>

<div class="mask" style="display:none">
<h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<a href="<?php the_permalink() ?>" class="sinfo"><?php _e('View the article', 'Detox') ?></a>
<div class="xminfo"><a href="<?php the_permalink() ?>"><?php _e('View the article', 'Detox') ?></a></div>
</div>

</div>
</div>
<? }
echo '</div>';
} }
$post = $orig_post;
wp_reset_query(); ?>
</div>

</div>

<div id="navigation" class="animated slideInRight">
<?php _e('You are here', 'Detox') ?>: <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>

<?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>	
            
<div class="post-navigation clear animated slideInRight">
               
</div>

<div class="clearfix"></div><hr class="clear" />

</div>
</div>
</div>

<?php get_template_part('footer'); ?>