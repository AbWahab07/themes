<?php get_template_part('header'); ?>

<div id="smain" class="animated slideInDown">

<div class="breaks">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="hc5 view view-first">
<div class="hp">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="round" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"><a class="nix" href="<?php the_permalink() ?>"></a></div>

<div class="x">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div ><?php the_excerpt(); ?></div>
</div>
</div>

<div class="mask">
<h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<a href="<?php the_permalink() ?>" class="sinfo"><?php _e('View the article', 'Detox') ?></a>
<div class="xminfo"><a href="<?php the_permalink() ?>"><?php _e('View the article', 'Detox') ?></a></div>
</div>

</div>
<?php endwhile; else: ?>
<div class="navi hc5"><h2><?php _e('Sorry, nothing found, search again?', 'Detox') ?></h2></div>
<?php endif; ?>

</div>

</div>
<nav class="nav-slide">
<?php next_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>Older<span> Entries</span></h3></div>', 0); ?>
<?php previous_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>Newer<span> Entries</span></h3></div></a>', 0) ?>
</nav>
<?php get_footer(); ?>