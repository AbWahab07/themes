<div id="xblack">
<div class="wrapper">
<div id="front">

<?php 
	$my_query = new WP_Query('showposts=1&offset=5');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="xcontentdiv1">
<div class="xslideimg1" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="xslidetxt">
<div class="post-category"><?php the_category(' / '); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>

</div>

<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"></a>
</div>                    
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('showposts=4&offset=6');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="xcontentdiv">
<div class="xslideimg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="xslidetxt">
<div class="post-category"><?php the_category(' / '); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

</div>
</div>                    
</div>

<?php endwhile; ?>

</div>
</div>
</div>