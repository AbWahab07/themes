<?php if ( has_post_thumbnail() ) :?>
<div class="xthumb animated fadeIn"><?php $browse_img = get_the_post_thumbnail($post->ID, 'gallerie'); ?><?php echo $browse_img; ?></div>
<?php endif; ?>