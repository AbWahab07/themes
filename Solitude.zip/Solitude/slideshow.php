<?php if ( (is_home())  ) { ?>
<div class="show">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('about') ) : ?>
<h3>Welcome to Solitude</h3> 
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="cookie" class="alignright" width="100" />
<p>Place your home widget content here along with a nice welcome text.</p>
<div class="smore"><a href="http://3oneseven.com/">Read more</a></div>
<?php endif; ?>
</div>

<?php } else { ?>

<div class="slideshow"><div id="slideshow">

<?php 
	$my_query = new WP_Query('showposts=1&offset=0&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>

<div class="slide clear">
<div class="post">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><img src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></a>

<div class="ribb"></div>
<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
<div class="post-content">
<?php if (function_exists('smart_excerpt')) smart_excerpt(get_the_excerpt(), 27); ?>
<div class="smore"><a href="<?php the_permalink(); ?>">View</a></div>
</div>

</div>
</div>

<?php endwhile; ?>
 </div>

</div>

<?php } ?>