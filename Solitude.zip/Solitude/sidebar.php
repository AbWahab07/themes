<div class="sidebar">

<div class="widget">
<div class="widget-body clear">  
<?php get_template_part('slideshow'); ?>
</div>
</div>

<div class="scol">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad1') ) : ?>
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />
<?php endif; ?>
</div>

<div class="scol">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad2') ) : ?>
<?php endif; ?>
</div>

<?php if ( (is_home())  ) { ?>
<div class="widget widget_recentposts_thumbnail">
<h3>Popular posts</h3>
<div class="widget-body clear">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=-37');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="rpthumb clear">
<?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'mini-thumbnail'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="50px" height="50px" alt="<?php the_title(); ?>" />
<?php endif;?>
<span class="rpthumb-title"><?php the_title(); ?></span>
</a>
<?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?>
<?php endwhile; ?>
</div>
</div>
<?php } else { ?>
<div class="widget widget_recentposts_thumbnail">
<h3>Popular posts</h3>
<div class="widget-body clear">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=-37');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="rpthumb clear">
<?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'mini-thumbnail'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="50px" height="50px" alt="<?php the_title(); ?>" />
<?php endif;?>
<span class="rpthumb-title"><?php the_title(); ?></span>
<?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?>
</a>
<?php endwhile; ?>
</div>
</div>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) :
        $widget_args = array(
            'after_widget' => '</div></div>',
            'before_title' => '<h3>',
            'after_title' => '</h3><div class="widget-body clear">'
        );
?>
<?php endif; ?>
<?php } ?>

<?php if ( (is_single())  ) { ?>
<?php } else { ?>
<div class="scol">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad3') ) : ?>
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />
<?php endif; ?>
</div>
<?php } ?>
</div>