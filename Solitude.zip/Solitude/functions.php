<?php
function custom_colors() {
   echo '<style type="text/css">#wpadminbar,#wpcontent{background:#fff !important;border-bottom:5px solid #ccc;color:#333;text-shadow:#fff 0 1px 1px;}#wpadminbar #wp-admin-bar-wp-logo,#wpadminbar .ab-icon,#wp-admin-bar-wp-logo,#message{display:none !important;}#footer{background:#fff !important;border-top:5px solid #ccc;color:#333;}#user_info p,#user_info p a,#wphead a{color:#900 !important;}#wp-admin-bar-wp-logo{display:none !important;}</style>';
}
add_action('admin_head', 'custom_colors');  
add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );
add_filter( 'show_admin_bar', '__return_false' );

remove_action('wp_head', 'rsd_link'); 
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');

update_option('thumbnail_size_w', 290);
update_option('thumbnail_size_h', 290);
add_image_size( 'mini', 500, 400, true );
add_image_size( 'mini-thumbnail', 50, 50, true );
add_image_size( 'slider', 280, 280, true );
add_image_size( 'rlider', 400, 400, true );
add_image_size( 'rslider', 290, 180, true );
add_image_size( 'gallerie', 940, 590, true );
add_image_size( 'covers', 140, 140, true );
add_image_size( 'browse', 155, 155 );
add_image_size( 'xnew', 1300, 800, true );
add_image_size( 'bigg', 940, 590, true );
if ( is_admin() && isset($_GET['activated'] ) && $pagenow == 'themes.php' ) {
    update_option( 'posts_per_page', 12 );
    update_option( 'paging_mode', 'default' );
}

function sight_save_data($post_id) {
    global $meta_box;
    // verify nonce
    if (!wp_verify_nonce($_POST['sight_meta_box_nonce'], basename(__FILE__))) {
        return $post_id;
    }
    // check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    // check permissions
    if ('page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } elseif (!current_user_can('edit_post', $post_id)) {
        return $post_id;
    }
    foreach ($meta_box['fields'] as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        $new = $_POST[$field['id']];

        if ($new && $new != $old) {
            update_post_meta($post_id, $field['id'], $new);
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    }
}

function options_admin_menu() {
	add_theme_page("Cake Options", "Cake Options", 'edit_themes', basename(__FILE__), 'options_page');
}
add_action('admin_menu', 'options_admin_menu');
function options_page() {
    if ( $_POST['update_options'] == 'true' ) { options_update(); }  //check options update
	?>
    <div class="wrap">
        <div id="icon-options-general" class="icon32"><br /></div>
		<h2>Cake Options</h2>
        <form method="post" action="">
			<input type="hidden" name="update_options" value="true" />
            <table class="form-table">                                
                
                <tr valign="top">
                    <th scope="row"><label><?php _e('Pagination:'); ?></label></th>
                    <td>
                        <input type="radio" name="paging_mode" value="default" <?php echo (get_option('paging_mode') == 'default')? 'checked="checked"' : ''; ?>/><span class="description">Default + WP Page-Navi support</span><br/>
                        <input type="radio" name="paging_mode" value="ajax" <?php echo (get_option('paging_mode') == 'ajax')? 'checked="checked"' : ''; ?>/><span class="description">AJAX-fetching posts</span><br/>
                    </td>
                </tr>
                
            </table>

            <p><input type="submit" value="Save Changes" class="button button-primary" /></p>
        </form>
    </div>
<?php
}

function options_update() {
	update_option('ss_disable', $_POST['ss_disable']);
	update_option('ss_timeout', $_POST['ss_timeout']);
	update_option('paging_mode', $_POST['paging_mode']);
	update_option('ga', stripslashes_deep($_POST['ga']));
}

class Recentposts_thumbnail extends WP_Widget {
    function Recentposts_thumbnail() {
        parent::WP_Widget(false, $name = 'Cake Recent Posts');
    }
    function widget($args, $instance) {
        extract( $args );
        $title = apply_filters('widget_title', $instance['title']);
        ?>
            <?php echo $before_widget; ?>
            <?php if ( $title ) echo $before_title . $title . $after_title;  else echo '<div class="widget-body clear">'; ?>
            <?php
                global $post;
                if (get_option('rpthumb_qty')) $rpthumb_qty = get_option('rpthumb_qty'); else $rpthumb_qty = 5;
                $q_args = array(
                    'numberposts' => $rpthumb_qty,
                );
                $rpthumb_posts = get_posts($q_args);
                foreach ( $rpthumb_posts as $post ) :
                    setup_postdata($post);
            ?>
                <a href="<?php the_permalink(); ?>" class="rpthumb clear">
                    <?php if ( has_post_thumbnail() && !get_option('rpthumb_thumb') ) {
                        the_post_thumbnail('mini-thumbnail');
                        $offset = 'style="padding-left: 65px;"';
                    }
                    ?>
                    <span class="rpthumb-title" <?php echo $offset; ?>><?php the_title(); ?></span>
                    <span class="rpthumb-date" <?php echo $offset; unset($offset); ?>><?php the_time(__('M j, Y')) ?></span>
                </a>
            <?php endforeach; ?>
            <?php echo $after_widget; ?>
        <?php
    }
    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        update_option('rpthumb_qty', $_POST['rpthumb_qty']);
        update_option('rpthumb_thumb', $_POST['rpthumb_thumb']);
        return $instance;
    }
    function form($instance) {
        $title = esc_attr($instance['title']);
        ?>
            <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
            <p><label for="rpthumb_qty">Number of posts:  </label><input type="text" name="rpthumb_qty" id="rpthumb_qty" size="2" value="<?php echo get_option('rpthumb_qty'); ?>"/></p>
            <p><label for="rpthumb_thumb">Hide thumbnails:  </label><input type="checkbox" name="rpthumb_thumb" id="rpthumb_thumb" <?php echo (get_option('rpthumb_thumb'))? 'checked="checked"' : ''; ?>/></p>
        <?php
    }

}
add_action('widgets_init', create_function('', 'return register_widget("Recentposts_thumbnail");'));

function new_excerpt_length($length) {
	return 200;
}
add_filter('excerpt_length', 'new_excerpt_length');

function smart_excerpt($string, $limit) {
    $words = explode(" ",$string);
    if ( count($words) >= $limit) $dots = '...';
    echo implode(" ",array_splice($words,0,$limit)).$dots;
}

function comments_link_attributes(){
    return ' class="comments_popup_link"';
}
add_filter('comments_popup_link_attributes', 'comments_link_attributes');

function next_posts_attributes(){
    return 'class="nextpostslink"';
}
add_filter('next_posts_link_attributes', 'next_posts_attributes');

function milo_body_control() { 
global $post;
$postclass = $post->post_name;
if (is_home()) { 
echo 'id="home" class="Solitude-design-by-milo317"'; 
} elseif (is_single()) { 
echo 'id="single" class="' . $postclass . ' Solitude-design-by-milo317"';
} elseif (is_page()) { 
echo 'id="page" class=" ' . $postclass . ' Solitude-design-by-milo317"';
} elseif (is_category()) { 
echo 'id="page" class="category Solitude-design-by-milo317"';
} elseif (is_archive()) { 
echo 'id="page" class="arch Solitude-design-by-milo317"';
} elseif (is_404()) { 
echo 'id="page" class="error Solitude-design-by-milo317"';
} elseif (is_search()) { 
echo 'id="page" class="searchme Solitude-design-by-milo317"'; 
} 
}

function admin_favicon() {
	echo '<link rel="Shortcut Icon" type="image/x-icon" href="'.get_bloginfo('stylesheet_directory').'/images/ico/favicon.ico" />';
}
add_action('admin_head', 'admin_favicon');

function remove_footer_admin () {
    echo "Thank you for creating with <a href='http://3oneseven.com/'>milo</a>.";
} 
add_filter('admin_footer_text', 'remove_footer_admin'); 

add_action('admin_head', 'my_custom_logo');
function my_custom_logo() {
   echo '
      <style type="text/css">
         #header-logo { background-image: url('.get_bloginfo('template_directory').'/images/ico/favicon.ico) !important; }
      </style>
   ';
}

function custom_login() { 
echo '<link rel="stylesheet" type="text/css" href="' . get_template_directory_uri() . '/log/log.css" />'; 
}   
add_action('login_head', 'custom_login');
function fb_login_headerurl() {
	$url = bloginfo('url');
	echo $url;
}
add_filter( 'login_headerurl', 'fb_login_headerurl' );
function fb_login_headertitle() {
	$name = get_option('blogname');
	echo $name;
}
add_filter( 'login_headertitle', 'fb_login_headertitle' );

function Bruce_remove_recent_comments_style() {
	global $wp_widget_factory;
	remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}
add_action( 'widgets_init', 'Bruce_remove_recent_comments_style' );

add_action( 'after_setup_theme', 'regMyMenus' );
function regMyMenus() {
// This theme uses wp_nav_menu() in four locations.
register_nav_menus( array(
'topnav' => __( 'Top Menu', 'Detox' ),
'secnav' => __( 'Menu', 'Detox' ),
'fnav' => __( 'Footer Menu', 'Detox' ),
'mnav' => __( 'Mobile Menu', 'Detox' ),
) );
}

function secnav_fallback() {
?>
<ul id="catnavi">
<?php wp_list_categories('hierarchical=0&title_li='); ?>
</ul>
<?php
}
function topnav_fallback() {
?>
<ul id="pnavi">
<li class="<?php if ( is_home() or is_single() or is_paged() or is_search() or (function_exists('is_tag') and is_tag()) ) { ?>current_page_item<?php } else { ?>page_item<?php } ?>"><a href="/"><?php _e( 'Home', 'Detox' ) ?></a></li>
<?php wp_list_pages('depth=4&sort_column=menu_order&title_li='); ?>
</ul>
<?php
}
function fnav_fallback() {
?>
<ul id="fnavi">
<li><a href="/"><?php _e( 'Home', 'Detox' ) ?></a></li>
<?php wp_list_pages('depth=1&sort_column=menu_order&title_li='); ?>
</ul>
<?php
}
function mnav_fallback() {
?>
<ul>
<?php wp_list_pages('title_li=&depth=1'); ?>
</ul>
<?php
}
function show_active_category($text) {
	global $post;
	if( is_single() || is_category() ) {
		$categories = wp_get_post_categories($post->ID);
		foreach( $categories as $catid ) {
			$cat = get_category($catid);
			if(preg_match('#>' . $cat->name . '</a>#', $text)) {
				$text = str_replace('>' . $cat->name . '</a>', ' class="active_category">' . $cat->name . '</a>', $text);
			}
		}
	}
	return $text;
}
add_filter('wp_list_categories', 'show_active_category');

function dimox_breadcrumbs() { 
  $delimiter = '&raquo;';
  $home = 'Home'; // text for the 'Home' link
  $before = '<span class="current">'; // tag before the current crumb
  $after = '</span>'; // tag after the current crumb 
  if ( !is_home() && !is_front_page() || is_paged() ) {
    echo '<div id="crumbs">'; 
    global $post;
    $homeLink = get_bloginfo('url');
    echo '<a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' '; 
    if ( is_category() ) {
      global $wp_query;
      $cat_obj = $wp_query->get_queried_object();
      $thisCat = $cat_obj->term_id;
      $thisCat = get_category($thisCat);
      $parentCat = get_category($thisCat->parent);
      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
      echo $before . 'Archive by category "' . single_cat_title('', false) . '"' . $after; 
    } elseif ( is_day() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
      echo $before . get_the_time('d') . $after; 
    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo $before . get_the_time('F') . $after; 
    } elseif ( is_year() ) {
      echo $before . get_the_time('Y') . $after; 
    } elseif ( is_single() && !is_attachment() ) {
      if ( get_post_type() != 'post' ) {
        $post_type = get_post_type_object(get_post_type());
        $slug = $post_type->rewrite;
        echo '<a href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a> ' . $delimiter . ' ';
        echo $before . get_the_title() . $after;
      } else {
        $cat = get_the_category(); $cat = $cat[0];
        echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
        echo $before . get_the_title() . $after;
      } 
    } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
      $post_type = get_post_type_object(get_post_type());
      echo $before . $post_type->labels->singular_name . $after; 
    } elseif ( is_attachment() ) {
      $parent = get_post($post->post_parent);
      $cat = get_the_category($parent->ID); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
      echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';
      echo $before . get_the_title() . $after; 
    } elseif ( is_page() && !$post->post_parent ) {
      echo $before . get_the_title() . $after; 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
      echo $before . get_the_title() . $after; 
    } elseif ( is_search() ) {
      echo $before . 'Search results for "' . get_search_query() . '"' . $after; 
    } elseif ( is_tag() ) {
      echo $before . 'Posts tagged "' . single_tag_title('', false) . '"' . $after; 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo $before . 'Articles posted by ' . $userdata->display_name . $after;
    } elseif ( is_404() ) {
      echo $before . 'Error 404' . $after;
    }
    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
      echo __('Page') . ' ' . get_query_var('paged');
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
    } 
    echo '</div>'; 
  }
} // end dimox_breadcrumbs()

add_filter('gallery_style', create_function('$a', 'return preg_replace("%<style type=\'text/css\'>(.*?)</style>%s", "", $a);'));
add_filter('login_errors', create_function('$a', "return null;"));
function remove_lostpassword_text ( $text ) {
	 if ($text == 'Lost your password?'){$text = '';}
		return $text;
	 }
add_filter( 'gettext', 'remove_lostpassword_text' );

add_action("init", "init_mudslide_custom_error");
function init_mudslide_custom_error() {
    global $mudslide_custom_error;
    $mudslide_custom_error = new MudslideCustomError();
}
class MudslideCustomError {
    public function __construct() {
        add_filter('wp_die_handler', array(&$this, 'get_custom_wp_die_handler'));
    }	
   function get_custom_wp_die_handler() {
        return array(&$this, 'mudslide_website_wp_die_handler');
    }
   function mudslide_website_wp_die_handler($message, $title = '', $args = array()) {        
        $errorTemplate = get_theme_root(). '/'. get_template(). '/error.php';			
        if(!is_admin() && file_exists($errorTemplate)) {
            $defaults = array( 'response' => 500 );
            $r = wp_parse_args($args, $defaults);
            $have_gettext = function_exists('__');
            if ( function_exists( 'is_wp_error' ) && is_wp_error( $message ) ) {
                if ( empty( $title ) ) {
                    $error_data = $message->get_error_data();
                    if ( is_array( $error_data ) && isset( $error_data['title'] ) )
                        $title = $error_data['title'];
                }
                $errors = $message->get_error_messages();                
                switch ( count( $errors ) ) :
                    case 0 :
                        $message = '';
                        break;
                    case 1 :
                        $message = "<p>{$errors[0]}</p>";
                        break;
                    default :
                        $message = "<ul>\n\t\t<li>" . join( "</li>\n\t\t<li>", $errors ) . "</li>\n\t</ul>";
                        break;
                endswitch;
            } elseif ( is_string( $message ) ) {            
                $message = "<p>$message</p>";
            }
           if ( empty($title) )
            $title = $have_gettext ? __('WordPress &rsaquo; Error') : 'WordPress &rsaquo; Error';		
           require_once($errorTemplate);		
           die();
        } else {
            _default_wp_die_handler($message, $title, $args);
        }
    }	
}
register_sidebars( 1, 
	array( 
		'name' => 'About Widget', 'Detox',
		'id' => 'about',
		'description' => __('The about widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1, 
	array( 
		'name' => 'Home Page Box 1', 'Detox',
		'id' => 'footer-column11',
		'description' => __('The 1st column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Home Page Box 2', 'Detox',
		'id' => 'footer-column21',
		'description' => __('The 2nd column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Home Page Box 3', 'Detox',
		'id' => 'footer-column31',
		'description' => __('The 3rd column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Home Page Box 4', 'Detox',
		'id' => 'footer-column41',
		'description' => __('The 4th column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1, 
	array( 
		'name' => 'Tag Box 1', 'Detox',
		'id' => 'tag-column1',
		'description' => __('The 1st column tag widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h1 class="widgettitle">',
        'after_title' => '</h1>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Tag Box 2', 'Detox',
		'id' => 'tag-column2',
		'description' => __('The 2nd column tag widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '',
        'after_title' => ''
	) 
);
register_sidebars( 1, 
	array( 
		'name' => 'Footer Box 1', 'Detox',
		'id' => 'footer-column111',
		'description' => __('The 1st column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Footer Box 2', 'Detox',
		'id' => 'footer-column211',
		'description' => __('The 2nd column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Footer Box 3', 'Detox',
		'id' => 'footer-column311',
		'description' => __('The 3rd column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Footer Box 4', 'Detox',
		'id' => 'footer-column411',
		'description' => __('The 4th column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1, 
	array( 
		'name' => 'Footer Box 5', 'Detox',
		'id' => 'footer-column1',
		'description' => __('The 1st column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Footer Box 6', 'Detox',
		'id' => 'footer-column2',
		'description' => __('The 2nd column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Footer Box 7', 'Detox',
		'id' => 'footer-column3',
		'description' => __('The 3rd column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Footer Box 8', 'Detox',
		'id' => 'footer-column4',
		'description' => __('The 4th column footer widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Sidebar', 'Detox',
		'id' => 'sidebar',
		'description' => __('The sidebar widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Pagebar', 'Detox',
		'id' => 'pagebar',
		'description' => __('The sidebar widget area on pages.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s cats">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Top adslot', 'Detox',
		'id' => 'topad',
		'description' => __('The header adslot widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '',
        'after_title' => ''
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Sidebar AdSlot1', 'Detox',
		'id' => 'sidebarad1',
		'description' => __('The adslots widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Sidebar AdSlot2', 'Detox',
		'id' => 'sidebarad2',
		'description' => __('The adslots widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Sidebar AdSlot3', 'Detox',
		'id' => 'sidebarad3',
		'description' => __('The adslots widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Single post AdSlot', 'Detox',
		'id' => 'sidebarad4',
		'description' => __('The adslots widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
function commentslist($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	<li>
      <ul>
							   <li class="clearfix" data-animated="fadeInUp">
                        	<div class="pull-left avatar">
                          <?php echo get_avatar($comment, 70, get_bloginfo('template_url').'/images/avatar.png'); ?>
                   	</div>
                    <div class="comment_right">
										<div class="comment_info dclearfix">
                            <div class="pull-left comment_author"><?php printf(__('%s</p>'), get_comment_author_link()) ?></div>
                            <div class="pull-left comment_inf_sep">|</div>
											<div class="pull-left comment_date"><?php printf(__('<p class="comment-date">%s</p>'), get_comment_date('M j, Y')) ?></div>
                            <div class="pull-left comment_inf_sep">|</div>
											<div class="pull-left comment_date"><?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></div>
                        </div>
                            <?php if ($comment->comment_approved == '0') : ?>
                                <p><?php _e('Your comment is awaiting moderation.') ?></p>
                            <?php endif; ?>
                            <?php comment_text() ?>
           </div>                 
   </li>
   </ul>
   </li>
<?php
}

add_filter('get_comments_number', 'comment_count', 0);
function comment_count( $count ) {
        if ( ! is_admin() ) {
                global $id;
                $comments_by_type = &separate_comments(get_comments('status=approve&post_id=' . $id));
                return count($comments_by_type['comment']);
        } else {
                return $count;
        }
}
function myavatar_add_default_avatar( $url )
{
return get_stylesheet_directory_uri() .'/images/avatar.png';
}
add_filter( 'bp_core_mysteryman_src', 'myavatar_add_default_avatar' ); 
function my_default_get_group_avatar($avatar) {
global $bp, $groups_template;
if( strpos($avatar,'group-avatars') ) {
return $avatar;
}
else {
$custom_avatar = get_stylesheet_directory_uri() .'/images/avatar.png';
if($bp->current_action == "")
return '<img width="'.BP_AVATAR_THUMB_WIDTH.'" height="'.BP_AVATAR_THUMB_HEIGHT.'" src="'.$custom_avatar.'" class="avatar" alt="' . esc_attr( $groups_template->group->name ) . '" />';
else
return '<img width="'.BP_AVATAR_FULL_WIDTH.'" height="'.BP_AVATAR_FULL_HEIGHT.'" src="'.$custom_avatar.'" class="avatar" alt="' . esc_attr( $groups_template->group->name ) . '" />';
}
}
add_filter( 'bp_get_group_avatar', 'my_default_get_group_avatar');
add_filter( 'max_srcset_image_width', create_function( '', 'return 1;' ) );
add_action( 'wp_enqueue_scripts', 'child_manage_woocommerce_styles', 99 );
function child_manage_woocommerce_styles() {
	//remove generator meta tag
	remove_action( 'wp_head', array( $GLOBALS['woocommerce'], 'generator' ) );
	//first check that woo exists to prevent fatal errors
	if ( function_exists( 'is_woocommerce' ) ) {
		//dequeue scripts and styles
		if ( ! is_woocommerce() && ! is_cart() && ! is_checkout() ) {
      wp_dequeue_style( 'woocommerce-layout' );
      wp_dequeue_style( 'woocommerce-smallscreen' );
      wp_dequeue_style( 'woocommerce' );
      wp_dequeue_style( 'woocommerce-general' );
			wp_dequeue_style( 'woocommerce_frontend_styles' );
			wp_dequeue_style( 'woocommerce_fancybox_styles' );
			wp_dequeue_style( 'woocommerce_chosen_styles' );
			wp_dequeue_style( 'woocommerce_prettyPhoto_css' );
			wp_dequeue_script( 'wc_price_slider' );
			wp_dequeue_script( 'wc-single-product' );
			wp_dequeue_script( 'wc-add-to-cart' );
			wp_dequeue_script( 'wc-cart-fragments' );
			wp_dequeue_script( 'wc-checkout' );
			wp_dequeue_script( 'wc-add-to-cart-variation' );
			wp_dequeue_script( 'wc-single-product' );
			wp_dequeue_script( 'wc-cart' );
			wp_dequeue_script( 'wc-chosen' );
			wp_dequeue_script( 'woocommerce' );
			wp_dequeue_script( 'prettyPhoto' );
			wp_dequeue_script( 'prettyPhoto-init' );
			wp_dequeue_script( 'jquery-blockui' );
			wp_dequeue_script( 'jquery-placeholder' );
			wp_dequeue_script( 'fancybox' );
			wp_dequeue_script( 'jqueryui' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'child_manage_buddypress_styles', 99 );
function child_manage_buddypress_styles() {
	//first check that woo exists to prevent fatal errors
	if ( function_exists( 'is_buddypress' ) ) {
		//dequeue scripts and styles
		if ( ! is_buddypress() && ! is_buddypress() && ! !bp_is_blog_page() ) {
      wp_dequeue_style( 'bp-legacy-css' );
      wp_dequeue_style( 'bp-mentions-css' );
			wp_deregister_script( 'bp-confirm' );
			wp_deregister_script( 'bp-widget-members' );
			wp_deregister_script( 'bp-jquery-query' );
			wp_deregister_script( 'bp-jquery-cookie' );
			wp_deregister_script( 'bp-jquery-scroll-to' );
			wp_deregister_script( 'bp-buddypress' );
      wp_deregister_script( 'bp-jquery-caret' );
			wp_deregister_script( 'bp-jquery-atwho' );
			wp_deregister_script( 'bp-mentions' );
		}
	}
}
function your_theme_xprofile_cover_image( $settings = array() ) {
    $settings['default_cover'] = '/wp-content/themes/Solitude/images/cover.jpg'; 
    return $settings;
}
add_filter( 'bp_before_groups_cover_image_settings_parse_args', 'your_theme_xprofile_cover_image', 10, 1 );
function your_xtheme_xprofile_cover_image( $settings = array() ) {
    $settings['default_cover'] = '/wp-content/themes/Solitude/images/cover.jpg'; 
    return $settings;
}
add_filter( 'bp_before_xprofile_cover_image_settings_parse_args', 'your_xtheme_xprofile_cover_image', 10, 1 );
function vp_get_thumb_url($text, $size){
        global $post;
        $imageurl="";
        $featuredimg = get_post_thumbnail_id($post->ID);
        $img_src = wp_get_attachment_image_src($featuredimg, $size);
        $imageurl=$img_src[0];
        if (!$imageurl) {
                $allimages =&get_children('post_type=attachment&post_mime_type=image&post_parent=' . $post->ID );
                foreach ($allimages as $img){
                        $img_src = wp_get_attachment_image_src($img->ID, $size);
                        break;
                }
                $imageurl=$img_src[0];
        }
        if (!$imageurl) {
                preg_match('/<\s*img [^\>]*src\s*=\s*[\""\']?([^\""\'>]*)/i' ,  $text, $matches);
                $imageurl=$matches[1];
        }
        if (!$imageurl){
                preg_match("/([a-zA-Z0-9\-\_]+\.|)youtube\.com\/watch(\?v\=|\/v\/)([a-zA-Z0-9\-\_]{11})([^<\s]*)/", $text, $matches2);
                $youtubeurl = $matches2[0];
                $videokey = $matches2[3];
        if (!$youtubeurl) {
                preg_match("/([a-zA-Z0-9\-\_]+\.|)youtu\.be\/([a-zA-Z0-9\-\_]{11})([^<\s]*)/", $text, $matches2);
                $youtubeurl = $matches2[0];
                $videokey = $matches2[2];
        }
        if ($youtubeurl)
                $imageurl = "http://i.ytimg.com/vi/{$videokey}/0.jpg";
        }
        if (!$imageurl) {
                $dir = get_template_directory_uri() . '/images/'; // [SET MANUALLY!!!]
                $get_cat = get_the_category();
                $cat = $get_cat[0]->
                slug;
                $imageurl = $dir . $cat . '.jpg'; // [SET MANUALLY!!!]
                $array = array( 'cat_1', 'cat_2', 'cat_3',);
                if (!in_array($cat, $array))
                        $imageurl = $dir . 'cover.jpg'; // [SET MANUALLY!!!]
        }
        return $imageurl;
}
add_filter('next_posts_link_attributes', 'posts_link_attributes_1');
add_filter('previous_posts_link_attributes', 'posts_link_attributes_2');
function posts_link_attributes_1() {
    return 'rel="prev" class="prev"';
}
function posts_link_attributes_2() {
    return 'rel="next" class="next"';
}
?>