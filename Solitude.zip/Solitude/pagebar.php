<div class="sidebar">

<div class="scol">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad1') ) : ?>
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />
<?php endif; ?>
</div>

<div class="widget widget_recentposts_thumbnail">
<h3>Popular posts</h3>
<div class="widget-body clear">

<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=-37');
?>

<?php while ($pc->have_posts()) : $pc->the_post(); ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="rpthumb clear">
<?php if(has_post_thumbnail()) :?>
<?php $browse_img = get_the_post_thumbnail($post->ID, 'mini-thumbnail'); ?><?php echo $browse_img; ?>
<?php else :?>
<img src="<?php bloginfo('template_directory'); ?>/images/no-avatar.png" width="50px" height="50px" alt="<?php the_title(); ?>" />
<?php endif;?>
<span class="rpthumb-title"><?php the_title(); ?></span>
<?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?>
</a>



<?php endwhile; ?>

</div>

</div>



<div class="scol">

<?php if ( !function_exists('dynamic_sidebar')

		        || !dynamic_sidebar('sidebarad2') ) : ?>

<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />

<?php endif; ?>

</div>



<?php if ( !function_exists('dynamic_sidebar')

		        || !dynamic_sidebar('pagebar') ) : ?>

<?php endif; ?>



<div class="scol">

<?php if ( !function_exists('dynamic_sidebar')

		        || !dynamic_sidebar('sidebarad3') ) : ?>

<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />

<?php endif; ?>

</div>



</div>