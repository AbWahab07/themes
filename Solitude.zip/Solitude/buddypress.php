<?php
/*
Template Name: full width template
*/
?>
<?php get_template_part('header2'); ?>

    <?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post(); ?>

<div id="white" class="animated fadeIn">
<div class="wrapper">
<div id="xcontent">

<div class="entry">
            <div <?php post_class('single clear'); ?> id="post_<?php the_ID(); ?>">
            
             <div class="content-title">
            <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
          
        </div>
        
                <div class="post-meta">
                    <h1><?php the_title(); ?></h1>
                    by <span class="post-author"><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" title="Posts by <?php the_author(); ?>"><?php the_author(); ?></a></span>
                    <?php edit_post_link( __( 'Edit entry'), '&bull; '); ?>                    
                </div>
                <?php the_content(); ?>
            
            </div>
        </div>

        <?php endwhile; ?>
    <?php endif; ?>

<?php get_template_part('footer2'); ?>