<div id="white"> 		
<div class="wrapper">

<div class="tl">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column1') ) : ?>
<h1>Solitude Magazine Theme</h1>
<div class="ssread"><a class="a-btn" href="https://3oneseven.com/solitude-magazin-theme/">Download</a></div>
<div class="ssread"><a class="a-btn" href="https://wp.3oneseven.com/?wptheme=Solitude">Demo</a></div>
<?php endif; ?>
</div>
<div class="tr">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column2') ) : ?>
<a href="https://3oneseven.com/solitude-magazin-theme/"><img src="<?php echo get_template_directory_uri(); ?>/images/solitude.png" alt="Solitude Theme" /></a>
<?php endif; ?>
</div>
</div> 
</div>