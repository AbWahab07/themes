<?php get_template_part('header'); ?>

<?php if ( have_posts() ) : ?>

<div id="white" class="animated fadeIn">
<div class="wrapper">
<div id="content">

    <div class="content-title">
        Search Result <span>/</span> <?php the_search_query(); ?>
        <a href="javascript: void(0);" id="mode"<?php if ($_COOKIE['mode'] == 'grid') echo ' class="flip"'; ?>></a>
    </div>

    <?php get_template_part('loop'); ?>

<?php else : ?>

<div id="white" class="animated fadeIn">
<div class="wrapper">
<div id="content">
    <div class="content-title">
        Your search "<strong><?php the_search_query(); ?></strong>" did not match any documents, search again?
    </div>



<?php endif; ?>

<nav class="nav-slide">
<?php next_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>Older<span> Entries</span></h3></div>', 0); ?>
<?php previous_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>Newer<span> Entries</span></h3></div></a>', 0) ?>
</nav>
<?php get_footer(); ?>