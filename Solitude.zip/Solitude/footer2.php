</div>

</div>
</div>
<?php get_template_part('ny'); ?>
<?php if ( (is_home())  ) { ?>
<?php get_template_part('slide'); ?>
<?php } else { ?>

<?php } ?>
<div id="white">
<div class="wrapper">
<?php get_template_part('mangle'); ?>
</div>
</div>
<div class="footer">
<div class="wrap">

<div class="col4">
<?php if ( !function_exists('dynamic_sidebar')
 || !dynamic_sidebar('footer-column1') ) : ?>

<h3 class="widgettitle"><?php _e( 'Topi', 'Detox') ?><span><?php _e( 'cs', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_list_categories('orderby=name&show_count=1&title_li=&number=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>

<div class="col5">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column2') ) : ?>

<h3 class="widgettitle"><?php _e( 'Recent', 'Detox') ?> <span><?php _e( 'Comments', 'Comments') ?></span></h3>

<?php
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
comment_post_ID, comment_author, comment_date_gmt, comment_approved,
comment_type,comment_author_url,
SUBSTRING(comment_content,1,30) AS com_excerpt
FROM $wpdb->comments
LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
$wpdb->posts.ID)
WHERE comment_approved = '1' AND comment_type = '' AND
post_password = ''
ORDER BY comment_date_gmt DESC
LIMIT 5";
$comments = $wpdb->get_results($sql);
$output = $pre_HTML;
$output .= "\n<ul>";
foreach ($comments as $comment) {
$output .= "\n<li>".strip_tags($comment->comment_author)
.": " . "<a href=\"" . get_permalink($comment->ID) .
"#comment-" . $comment->comment_ID . "\" title=\"on " .
$comment->post_title . "\">" . strip_tags($comment->com_excerpt)
."&hellip;</a></li>";
}
$output .= "\n</ul>";
$output .= $post_HTML;
echo $output;?>

<?php endif; ?>
</div>

<div class="col6">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column3') ) : ?>

<h3 class="widgettitle">Pop<span>ular</span></h3>

<ul id="popular-comments">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=-37');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>
<li>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> &#38; <small><?php comments_popup_link('No Comments;', '1 Comment', '% Comments'); ?></small>
</li>
<?php endwhile; ?>
</ul>

<?php endif; ?>
</div>

<div class="col7">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column4') ) : ?>

<h3 class="widgettitle"><?php _e( 'Archi', 'Detox') ?><span><?php _e( 'ves', 'Detox') ?></span></h3>

<div class="cats">
<ul><?php wp_get_archives('type=monthly&show_post_count=0&limit=8'); ?></ul>
</div>

<?php endif; ?>

</div>

<div class="clearfix"></div><hr class="clear" />

<div class="clear animated slideInDown">
<div class="logo">
<h1><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a></h1>
<div class="m1"><?php bloginfo('description'); ?></div>
</div>

<div id="fnav" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'fnav',
'container' => '',
'container_id' => 'fna',
'menu_id' => 'fnavi',
'fallback_cb' => 'fnav_fallback',
));
} else {
?>
<?php
}
?>

</div>
</div>

<div class="clearfix"></div><hr class="clear" />

<p class="copyright">&copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> | <?php
					if ( is_user_logged_in() ) {
					    echo '<a href="'.wp_logout_url( get_permalink() ).'" title="Logout" class="hunderline">Logout</a>';
					} else {
					    echo '<a href="'.wp_login_url( get_permalink() ).'" title="Login" class="hunderline">Login</a>';
					}
					?> | <a href="#catnavi">Top</a></p>

<p class="credits">
<a class="no-link" href="https://3oneseven.com/">Website design by milo</a></p> 
<p class="credits" style="font-size:10px"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/solitude-magazin-theme/" >Theme</a> <span>Solitude theme</span>
</span>
</span>
</span>
</div>
</p>

</div>
</div>
</div>
<?php wp_footer(); ?>

<div class="overlays overlay-contentscale">
<button type="button" class="overlay-close"><?php _e('Close', 'Detox'); ?></button>
<h1><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1>
<div class="navi">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'mnav',
'container' => '',
'container_id' => 'top',
'menu_id' => 'navx',
'fallback_cb' => 'mnav_fallback',
));
} else {
?>
<?php
}
?>
</div>
</div> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
<script type="text/javascript">$(document).ready(function(){var a=function(){return $(document).height()-$(window).height()},b=function(){return $(window).scrollTop()};if("max"in document.createElement("progress")){var c=$("progress");c.attr({max:a()}),$(document).on("scroll",function(){c.attr({value:b()})}),$(window).resize(function(){c.attr({max:a(),value:b()})})}else{var e,f,c=$(".progress-bar"),d=a(),g=function(){return e=b(),f=e/d*100,f+="%"},h=function(){c.css({width:g()})};$(document).on("scroll",h),$(window).on("resize",function(){d=a(),h()})}}),$(document).ready(function(){$("#flat").addClass("active"),$("#progressBar").addClass("flat"),$("#flat").on("click",function(){$("#progressBar").removeClass().addClass("flat"),$(this).preventDefault()}),$("#single").on("click",function(){$("#progressBar").removeClass().addClass("single"),$(this).preventDefault()}),$("#multiple").on("click",function(){$("#progressBar").removeClass().addClass("multiple"),$(this).preventDefault()}),$("#semantic").on("click",function(){$("#progressBar").removeClass().addClass("semantic"),$(this).preventDefault(),alert("hello")}),$(document).on("scroll",function(){maxAttr=$("#progressBar").attr("max"),valueAttr=$("#progressBar").attr("value"),percentage=valueAttr/maxAttr*100,percentage<49?(document.styleSheets[0].addRule(".semantic","color: red"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: red"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: red")):percentage<98?(document.styleSheets[0].addRule(".semantic","color: red"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: red"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: red")):(document.styleSheets[0].addRule(".semantic","color: red"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: red"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: red"))})});</script>
<script type="text/javascript">var scrolltotop={setting:{startline:100,scrollto:0,scrollduration:1e3,fadeduration:[500,100]},controlHTML:'<img src="<?php echo get_template_directory_uri(); ?>/images/bnav.png" style="filter:alpha(opacity=70); -moz-opacity:0.7;" width="28" height="29" />',controlattrs:{offsetx:0,offsety:20},anchorkeyword:"#top",state:{isvisible:!1,shouldvisible:!1},scrollup:function(){this.cssfixedsupport||this.$control.css({opacity:0});var a=isNaN(this.setting.scrollto)?this.setting.scrollto:parseInt(this.setting.scrollto);a="string"==typeof a&&1==jQuery("#"+a).length?jQuery("#"+a).offset().top:0,this.$body.animate({scrollTop:a},this.setting.scrollduration)},keepfixed:function(){var a=jQuery(window),b=a.scrollLeft()+a.width()-this.$control.width()-this.controlattrs.offsetx,c=a.scrollTop()+a.height()-this.$control.height()-this.controlattrs.offsety;this.$control.css({left:b+"px",top:c+"px"})},togglecontrol:function(){var a=jQuery(window).scrollTop();this.cssfixedsupport||this.keepfixed(),this.state.shouldvisible=a>=this.setting.startline?!0:!1,this.state.shouldvisible&&!this.state.isvisible?(this.$control.stop().animate({opacity:1},this.setting.fadeduration[0]),this.state.isvisible=!0):0==this.state.shouldvisible&&this.state.isvisible&&(this.$control.stop().animate({opacity:0},this.setting.fadeduration[1]),this.state.isvisible=!1)},init:function(){jQuery(document).ready(function(a){var b=scrolltotop,c=document.all;b.cssfixedsupport=!c||c&&"CSS1Compat"==document.compatMode&&window.XMLHttpRequest,b.$body=a(window.opera?"CSS1Compat"==document.compatMode?"html":"body":"html,body"),b.$control=a('<div id="topcontrol">'+b.controlHTML+"</div>").css({position:b.cssfixedsupport?"fixed":"absolute",bottom:b.controlattrs.offsety,right:b.controlattrs.offsetx,opacity:0,cursor:"pointer"}).attr({title:"back to top"}).click(function(){return b.scrollup(),!1}).appendTo("body"),document.all&&!window.XMLHttpRequest&&""!=b.$control.text()&&b.$control.css({width:b.$control.width()}),b.togglecontrol(),a('a[href="'+b.anchorkeyword+'"]').click(function(){return b.scrollup(),!1}),a(window).bind("scroll resize",function(){b.togglecontrol()})})}};scrolltotop.init();</script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/classie.js"></script> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/demo7.js"></script> 
<script src="<?php echo get_template_directory_uri(); ?>/js/instant.js" type="text/javascript"></script>


</body>
</html>