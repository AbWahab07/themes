<?php get_header(); ?>

<div id="white" class="animated fadeIn">
<div class="wrapper">
<div id="content">

<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>

<div class="content-title">
            <?php the_category(' <span>/</span> '); ?>
           
        </div>

        <div class="entry">
            <div <?php post_class('single clear'); ?> id="post_<?php the_ID(); ?>">
                <div class="post-meta">
                    <h1><?php the_title(); ?></h1>
                    by <span class="post-author"><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" title="Posts by <?php the_author(); ?>"><?php the_author(); ?></a></span> on <span
                        class="post-date"><?php the_time(__('M j, Y')) ?></span> &bull; <span><?php the_time() ?></span> <?php edit_post_link( __( 'Edit entry'), '&bull; '); ?><a
                        href="#comments" class="post-comms"><?php comments_number(__('No Comments'), __('1 Comment'), __('% Comments'), '', __('Comments Closed') ); ?></a></div>
                <div class="post-content"><?php the_content(); ?></div>
                <div class="post-footer"><?php the_tags(__('<strong>Tags: </strong>'), ', '); ?></div>
            </div>

<div class="sc">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebarad4') ) : ?>
<img src="<?php bloginfo('template_url'); ?>/images/cake.png" alt="nice cookie" class="aligncenter" />

<?php endif; ?>
</div>
            
<div class="bolism">

<div class="rel">
<?php if ( get_the_author_meta( 'description' ) ) :  ?>
<div class="author-avatar alignright">
<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 60 ) ); ?>
</a>
</div>

<div id="author-description">
<h4><?php printf( esc_attr__( 'About %s', 'Bruce' ), get_the_author() ); ?> :</h4>
<p><?php the_author_meta( 'description' ); ?> | <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'View all posts by %s <span class="meta-nav">&rarr;</span>', 'Bruce' ), get_the_author() ); ?></a><?php edit_post_link(' | Edit','',''); ?></p>
</div>
<?php endif; ?>
</div>

</div>


            
<?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>	

        </div>

        <?php endwhile; ?>
    <?php endif; ?>

<nav class="nav-slide">
<?php 
$prev_post = get_adjacent_post(false, '', true);
if(!empty($prev_post)) {
echo '<a class="prev" href="' . get_permalink($prev_post->ID) . '"><span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>' . $prev_post->post_title . ' <span> Previously</span></h3></div></a>'; }
 ?>
<?php
$next_post = get_adjacent_post(false, '', false);
if(!empty($next_post)) {
echo '<a class="next" href="' . get_permalink($next_post->ID) . '">	<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>' . $next_post->post_title . ' <span>Next</span></h3></div></a>'; }
?>
</nav>
<?php get_footer(); ?>