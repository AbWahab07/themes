<div id="sc">
<div class="fb"><a class="trs" href="">Facebook</a></div>
<div class="tw"><a class="trs"  href="">Twitter</a></div>
<div class="rss"><a class="trs" href="">Instragram</a></div>
<div class="sign"><a class="trs" href="">Pinterest</a></div>
</div>