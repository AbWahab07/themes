<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "https://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" dir="<?php bloginfo('text_direction'); ?>" xml:lang="<?php bloginfo('language'); ?>">
<head>

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/images/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_url'); ?>" />

<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />
<!--[if IE]><link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('template_url'); ?>/ie.css" /><![endif]-->
<!--[if lte IE 8]><link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/iefix.css" type="text/css" media="all" /><![endif]-->

<!--[if lte IE 9]><script src="https://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js" type="text/javascript"></script><![endif]-->
<!--[if IE]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]--> 

<?php if ( (is_home())  ) { ?>
<script src="<?php bloginfo('template_url'); ?>/js/contentslider.js" type="text/javascript"></script>
<?php } ?>

<!--[if lte IE 9]><script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js" type="text/javascript"></script><![endif]--><!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]--> 
<!--[if lte IE 9]><script src="<?php bloginfo('template_url'); ?>/js/modernizr-1.6.min.js" type="text/javascript"></script><![endif]-->

<?php wp_head(); ?>        

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/modernizr.custom.js"></script>
</head>

<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="https://schema.org/WebPage">
<progress value="0" id="progressBar"><div class="progress-container"><span class="progress-bar"></span></div></progress>
<div class="xtow2">
<h1><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1>
<div id="xnavbar" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<button id="trigger-overlay" type="button"><span style="display:none"><?php _e('Menu', 'Detox') ?></span></button>
</div>

</div>

<div class="wrapper">

<div id="fheader" class="animated slideInDown">
<div id="navi">
<div id="pnavi" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'topnav',
'container' => '',
'container_id' => 'topnav',
'menu_id' => 'pnavi',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>
</div>
<?php get_template_part('social'); ?>
</div>
</div>

<div class="header clear animated slideInDown">
<div class="logo">
<h1><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a></h1>
<div class="m1"><?php bloginfo('description'); ?></div>
</div>

<div id="catnav" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'secnav',
'container' => '',
'container_id' => 'secnav',
'menu_id' => 'catnavi',
'fallback_cb' => 'secnav_fallback',
));
} else {
?>
<?php
}
?>

<?php get_search_form(); ?>
</div>
</div>


<div class="twrapper animated fadeIn">

<!--[if lte IE 8]><div id="timer"></div><![endif]-->

<?php if ( (is_home())  ) { ?>
<?php get_template_part('front'); ?>
<?php } else { ?>
<div class="mansingle animated fadeIn"></div>
<?php } ?>

</div>

<?php if ( (is_home())  ) { ?>
<?php } else { ?>
</div>
<?php } ?>