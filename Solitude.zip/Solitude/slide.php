<div id="black">
<div id="slider2" class="contentslide">

<div class="opacitylayer">

<?php 
	$my_query = new WP_Query('showposts=8&offset=5');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="contentdiv">

<div class="slidetxt">
<div class="yslidetxt">
<div class="post-category"><?php the_category(' / '); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

</div>
</div>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="slideimg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"></a>
</div>                    
</div>

<?php endwhile; ?>

</div>

<div class="pagination" id="paginate-slider2"></div>
<script type="text/javascript">
ContentSlider("slider2", 9000) 
</script>

</div>

<div class="wrapper">
<div class="col4">
<?php if ( !function_exists('dynamic_sidebar')
 || !dynamic_sidebar('footer-column11') ) : ?>

<h3 class="widgettitle"><?php _e( 'Topi', 'Detox') ?><span><?php _e( 'cs', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_list_categories('orderby=name&show_count=1&title_li=&number=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>

<div class="col5">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column21') ) : ?>

<h3 class="widgettitle"><span><?php _e( 'Comments', 'Comments') ?></span></h3>

<?php
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
comment_post_ID, comment_author, comment_date_gmt, comment_approved,
comment_type,comment_author_url,
SUBSTRING(comment_content,1,30) AS com_excerpt
FROM $wpdb->comments
LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
$wpdb->posts.ID)
WHERE comment_approved = '1' AND comment_type = '' AND
post_password = ''
ORDER BY comment_date_gmt DESC
LIMIT 5";
$comments = $wpdb->get_results($sql);
$output = $pre_HTML;
$output .= "\n<ul>";
foreach ($comments as $comment) {
$output .= "\n<li>".strip_tags($comment->comment_author)
.": " . "<a href=\"" . get_permalink($comment->ID) .
"#comment-" . $comment->comment_ID . "\" title=\"on " .
$comment->post_title . "\">" . strip_tags($comment->com_excerpt)
."&hellip;</a></li>";
}
$output .= "\n</ul>";
$output .= $post_HTML;
echo $output;?>

<?php endif; ?>
</div>

<div class="col6">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column31') ) : ?>

<h3 class="widgettitle">Pop<span>ular</span></h3>

<ul id="popular-comments">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=-37');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>
<li>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> &#38; <small><?php comments_popup_link('No Comments;', '1 Comment', '% Comments'); ?></small>
</li>
<?php endwhile; ?>
</ul>

<?php endif; ?>
</div>

<div class="col7">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column41') ) : ?>

<h3 class="widgettitle"><?php _e( 'Archi', 'Detox') ?><span><?php _e( 'ves', 'Detox') ?></span></h3>

<div class="cats">
<ul><?php wp_get_archives('type=monthly&show_post_count=0&limit=8'); ?></ul>
</div>

<?php endif; ?>

</div>
</div>
</div>