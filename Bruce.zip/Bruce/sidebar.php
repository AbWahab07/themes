<div class="sidebar">

<?php get_template_part('slideshow'); ?>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebar') ) : ?>
            
<?php endif; ?>

<?php the_widget( 'Recentposts_thumbnail', 'title=Recently', $widget_args); ?>

</div>