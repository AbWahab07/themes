<?php
  $orig_post = $post;
  global $post;
  $tags = wp_get_post_tags($post->ID);   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'orderby' => 'rand',
  'post__not_in' => array($post->ID),
  'posts_per_page'=>1, // Number of related posts to display.
  'caller_get_posts'=>1
  );   
  $my_query = new wp_query( $args ); 
  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>


<div class="ausgabe">
<div class="atext animated rotateInDownRight">
<h4><span><?php _e( 'Related') ?></span></h4>

<h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>

</div>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="asimg animated rotateInDownRight" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>
</div>

  <? }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>