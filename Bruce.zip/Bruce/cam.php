<div class="wrapper"> 
<?php if ( (is_single())  ) { ?><div class="ren"></div> <?php } ?>    
<div class="hen"><h2>Video</h2></div>
<div class="ren"></div> 
</div>
<div id="slider3" class="sliderwrapper">

<?php 
$my_query = new WP_Query('category_name=&showposts=1&offset=0&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="contentdiv"> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="simg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="over">
<div class="alimg">
<div class="slideimg">
<div class="slidetxt">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<p><?php the_content_rss('', FALSE, ' ', 12); ?></p>
</div>
</div>
</div>
</div>
</div> 
<div class="whity">
<div class="reds">
<div class="buys">
<a href="<?php the_permalink() ?>"><?php _e( 'Read more') ?><div class="iconWrapper"><div class="play icon"></div></div></a>
</div>
</div>
</div>

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>  
<div class="asimg animated slideInRight" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

</div>
<?php endwhile; ?>

<div class="pagination" id="paginate-slider3"></div>

</div>