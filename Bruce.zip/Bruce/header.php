<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="https://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />

<!--[if lte IE 10]><link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/iefix.css" type="text/css" media="all" /><![endif]-->

<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" type="image/x-icon" />
<!--[if lte IE 9]><script src="https://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js" type="text/javascript"></script><![endif]-->
<!--[if IE]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
 

<?php wp_head(); ?>        

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/modernizr.custom.js"></script>
</head>
<body <?php body_class() ?> id="bruce_theme_by_milo317">
<progress value="0" id="progressBar"><div class="progress-container"><span class="progress-bar"></span></div></progress>

<div class="xtow2">
<div class="wrapper">
<div id="xnavbar" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<button id="trigger-overlay" type="button"><span style="display:none"><?php _e('Menu', 'Detox') ?></span></button>

<div class="header">
<div class="logo">
<h1><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1>
<div class="memo"><?php bloginfo('description'); ?></div>
</div>
</div>

<div id="sb-search">
<a href="#searchform" class="ssearch-toggle" rel="ibox"><div class="iconWrapper"><div class="search icon"></div></div></a>
<form id="searchform" style="display: none;" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e('Search...', 'Detox'); ?>" name="s" id="s" onfocus="if (this.value == 'Search...', 'Detox') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search', 'Detox';}" /></form>
</div>

</div>
</div>
</div>