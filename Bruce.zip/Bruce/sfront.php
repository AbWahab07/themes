<div class="wrapper">
<div class="ren"></div>  	
<div class="hen"><h2>Featured</h2></div>

<div id="container" class="clear">
<div id="content">
<div id="loop" class="grid clear">

<?php 
	$my_query = new WP_Query('category_name=&showposts=1&offset=6');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="post" id="post_<?php the_ID(); ?>" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">

<div class="over">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<p><?php the_content_rss('', FALSE, ' ', 12); ?></p>
<div class="more"><a href="<?php the_permalink() ?>"><?php _e( 'Read more') ?></a></div>
</div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('category_name=&showposts=1&offset=7');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="post" id="post_<?php the_ID(); ?>" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">

<div class="srimg">

</div>

<div class="over">
<h2 class="sgrey"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<p><?php the_content_rss('', FALSE, ' ', 12); ?></p>
<div class="more"><a href="<?php the_permalink() ?>"><?php _e( 'Read more') ?></a></div>
</div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('category_name=&showposts=1&offset=8');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="gpost" id="post_<?php the_ID(); ?>" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">



<div class="over">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<p><?php the_content_rss('', FALSE, ' ', 12); ?></p>
<div class="more"><a href="<?php the_permalink() ?>"><?php _e( 'Read more') ?></a></div>
</div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('category_name=&showposts=1&offset=9');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="mpost" id="post_<?php the_ID(); ?>" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">

<div class="over">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<p><?php the_content_rss('', FALSE, ' ', 26); ?></p>
<div class="more"><a href="<?php the_permalink() ?>"><?php _e( 'Read more') ?></a></div>
</div>
</div>
</div>
<?php endwhile; ?>

<?php 
	$my_query = new WP_Query('category_name=&showposts=1&offset=10');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="gpost" id="post_<?php the_ID(); ?>" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">

<div class="srimg">

</div>

<div class="over">
<h2 class="sgrey"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<p><?php the_content_rss('', FALSE, ' ', 12); ?></p>
<div class="more"><a href="<?php the_permalink() ?>"><?php _e( 'Read more') ?></a></div>
</div>
</div>
</div>
<?php endwhile; ?>

</div>

</div>
</div>
</div>
</div>
</div>