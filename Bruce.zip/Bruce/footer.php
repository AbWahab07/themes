<?php if ( (is_single())  ) { ?><?php get_template_part('cam'); ?><?php } else { ?><?php } ?>
<?php get_template_part('ny'); ?>
<div class="footer animated fadeInLeftBig">

<div class="tope">
<div class="wrapper">
<?php if ( (is_home())  ) { ?>
<div class="topl"><a href="#top"><?php _e('To the ', 'Detox'); ?> <b><?php _e('Top', 'Detox'); ?></b></a></div>
<?php } else { ?>
<div class="topl"><a href="#break"><?php _e('To the ', 'Detox'); ?> <b><?php _e('Top', 'Detox'); ?></b></a></div>
<?php } ?>
<div class="topr"><a href="/"><?php _e('More <b>News</b> ', 'Detox'); ?></a></div>
</div>
</div>

<div class="xwrapper">
<div class="middle">

<div class="wrapper">
<div class="col7 full">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column1') ) : ?>

<form class="aweber_form" method="post" action=""><input type="hidden" name="listname" value="bruce" />
<input type="hidden" name="redirect" value="" />
<input type="hidden" name="meta_adtracking" value="sidebar_form" />
<input type="hidden" name="meta_message" value="1" />
<input type="hidden" name="meta_required" value="email" />
<input type="hidden" name="meta_forward_vars" value="0" />
<input type="text" class="name" name="name" value="Your Name" onfocus="if (this.value == 'Your Name') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Name';}" />
<input type="text" class="email" name="email" value="Your Email" onfocus="if (this.value == 'Your Email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Email';}" />
<input type="submit" class="submit" name="submit" value="Subscribe" />
</form>
<?php endif; ?>
</div>
</div>
</div>
</div>


<div class="abo">
<div class="wrapper">

<div class="hefte">
<?php 
$my_query = new WP_Query('category_name=&showposts=1&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'front');
}
?>
<div class="h3 animated slideInLeft" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>
<?php endwhile; ?>

<?php 
$my_query = new WP_Query('category_name=&showposts=1&offset=1');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
 <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'front');
}
?>
<div class="h2 animated slideInRight" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>
<?php endwhile; ?>

<?php 
$my_query = new WP_Query('category_name=&showposts=1&offset=2');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'front');
}
?>
<div class="h1 animated slideInDown" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>
<?php endwhile; ?>
</div>
<div class="abobu animated slideInDown">
<p><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></p>
</div>

<div class="xcol7 xfull">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column2') ) : ?>

<form class="xaweber_form" method="post" action="">
<input type="hidden" name="listname" value="bruce" />
<input type="hidden" name="redirect" value="/" />
<input type="hidden" name="meta_adtracking" value="sidebar_form" />
<input type="hidden" name="meta_message" value="1" />
<input type="hidden" name="meta_required" value="email" />
<input type="hidden" name="meta_forward_vars" value="0" />
<input type="text" class="name" name="name" value="Your Name" onfocus="if (this.value == 'Your Name') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Name';}" />
<input type="text" class="email" name="email" value="Your Choice" onfocus="if (this.value == 'Your Choice') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Choice';}" />
<input type="text" class="email" name="email" value="Your Address" onfocus="if (this.value == 'Your Address') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Address';}" />
<input type="submit" class="submit" name="submit" value="Order now" />
</form>
<?php endif; ?>
</div>

</div>
</div>

<div class="wrapper">
<div class="fright">
<p class="copyright"><?php _e('Copyright', 'Detox'); ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> </p>
<p class="credits"><a class="no-link" href="https://3oneseven.com/">Website design by milo</a> </p>
<p class="creditso" style="font-size:10px;margin:0 auto;display:block;clear:both;text-align:center;"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/bruce-magazine-theme/" >Theme</a> <span>Bruce theme </span>
</span>
</span>
</span>
</p>
</div>
</div>

</div>

<?php wp_footer(); ?>

<div class="overlays overlay-contentscale">
<button type="button" class="overlay-close"><?php _e('Close', 'Detox'); ?></button>
<h1><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1>
<div class="navi">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'mnav',
'container' => '',
'container_id' => 'top',
'menu_id' => 'navx',
'fallback_cb' => 'mnav_fallback',
));
} else {
?>
<?php
}
?>
</div>
</div> 

<div class="svg-wrap">
			<svg width="64" height="64" viewBox="0 0 64 64">
				<path id="arrow-left-1" d="M46.077 55.738c0.858 0.867 0.858 2.266 0 3.133s-2.243 0.867-3.101 0l-25.056-25.302c-0.858-0.867-0.858-2.269 0-3.133l25.056-25.306c0.858-0.867 2.243-0.867 3.101 0s0.858 2.266 0 3.133l-22.848 23.738 22.848 23.738z" />
			</svg>
			<svg width="64" height="64" viewBox="0 0 64 64">
				<path id="arrow-right-1" d="M17.919 55.738c-0.858 0.867-0.858 2.266 0 3.133s2.243 0.867 3.101 0l25.056-25.302c0.858-0.867 0.858-2.269 0-3.133l-25.056-25.306c-0.858-0.867-2.243-0.867-3.101 0s-0.858 2.266 0 3.133l22.848 23.738-22.848 23.738z" />
			</svg>
		</div>   
<?php wp_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
<script type="text/javascript">$(document).ready(function(){var a=function(){return $(document).height()-$(window).height()},b=function(){return $(window).scrollTop()};if("max"in document.createElement("progress")){var c=$("progress");c.attr({max:a()}),$(document).on("scroll",function(){c.attr({value:b()})}),$(window).resize(function(){c.attr({max:a(),value:b()})})}else{var e,f,c=$(".progress-bar"),d=a(),g=function(){return e=b(),f=e/d*100,f+="%"},h=function(){c.css({width:g()})};$(document).on("scroll",h),$(window).on("resize",function(){d=a(),h()})}}),$(document).ready(function(){$("#flat").addClass("active"),$("#progressBar").addClass("flat"),$("#flat").on("click",function(){$("#progressBar").removeClass().addClass("flat"),$(this).preventDefault()}),$("#single").on("click",function(){$("#progressBar").removeClass().addClass("single"),$(this).preventDefault()}),$("#multiple").on("click",function(){$("#progressBar").removeClass().addClass("multiple"),$(this).preventDefault()}),$("#semantic").on("click",function(){$("#progressBar").removeClass().addClass("semantic"),$(this).preventDefault(),alert("hello")}),$(document).on("scroll",function(){maxAttr=$("#progressBar").attr("max"),valueAttr=$("#progressBar").attr("value"),percentage=valueAttr/maxAttr*100,percentage<49?(document.styleSheets[0].addRule(".semantic","color: red"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: red"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: red")):percentage<98?(document.styleSheets[0].addRule(".semantic","color: red"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: red"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: red")):(document.styleSheets[0].addRule(".semantic","color: red"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: red"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: red"))})});</script>
<script type="text/javascript">var scrolltotop={setting:{startline:100,scrollto:0,scrollduration:1e3,fadeduration:[500,100]},controlHTML:'<img src="<?php echo get_template_directory_uri(); ?>/images/nav.jpg" style="filter:alpha(opacity=70); -moz-opacity:0.7;" width="72" height="72" />',controlattrs:{offsetx:0,offsety:20},anchorkeyword:"#top",state:{isvisible:!1,shouldvisible:!1},scrollup:function(){this.cssfixedsupport||this.$control.css({opacity:0});var a=isNaN(this.setting.scrollto)?this.setting.scrollto:parseInt(this.setting.scrollto);a="string"==typeof a&&1==jQuery("#"+a).length?jQuery("#"+a).offset().top:0,this.$body.animate({scrollTop:a},this.setting.scrollduration)},keepfixed:function(){var a=jQuery(window),b=a.scrollLeft()+a.width()-this.$control.width()-this.controlattrs.offsetx,c=a.scrollTop()+a.height()-this.$control.height()-this.controlattrs.offsety;this.$control.css({left:b+"px",top:c+"px"})},togglecontrol:function(){var a=jQuery(window).scrollTop();this.cssfixedsupport||this.keepfixed(),this.state.shouldvisible=a>=this.setting.startline?!0:!1,this.state.shouldvisible&&!this.state.isvisible?(this.$control.stop().animate({opacity:1},this.setting.fadeduration[0]),this.state.isvisible=!0):0==this.state.shouldvisible&&this.state.isvisible&&(this.$control.stop().animate({opacity:0},this.setting.fadeduration[1]),this.state.isvisible=!1)},init:function(){jQuery(document).ready(function(a){var b=scrolltotop,c=document.all;b.cssfixedsupport=!c||c&&"CSS1Compat"==document.compatMode&&window.XMLHttpRequest,b.$body=a(window.opera?"CSS1Compat"==document.compatMode?"html":"body":"html,body"),b.$control=a('<div id="topcontrol">'+b.controlHTML+"</div>").css({position:b.cssfixedsupport?"fixed":"absolute",bottom:b.controlattrs.offsety,right:b.controlattrs.offsetx,opacity:0,cursor:"pointer"}).attr({title:"back to top"}).click(function(){return b.scrollup(),!1}).appendTo("body"),document.all&&!window.XMLHttpRequest&&""!=b.$control.text()&&b.$control.css({width:b.$control.width()}),b.togglecontrol(),a('a[href="'+b.anchorkeyword+'"]').click(function(){return b.scrollup(),!1}),a(window).bind("scroll resize",function(){b.togglecontrol()})})}};scrolltotop.init();</script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/classie.js"></script> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/demo7.js"></script> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/ibox.js"></script>  



</body>
</html>