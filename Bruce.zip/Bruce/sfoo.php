<?php if ( (is_home())  ) { ?>
</div>
<?php } else { ?>
</div>
</div>
</div>
<?php } ?>

<div class="footer">

<div class="wrapper">
<div class="middle">

<div class="col7">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column1') ) : ?>

<h3><?php _e('Con<span>tact</span>'); ?></h3>
<ul>
<li><a rel="nofollow" href="mailto:milo@3oneseven.com" title="Email me">3oneseven</a></li>
<li>Echinger str</li>
<li><a href="http://goo.gl/AAoFS" title="View on maps">80805 Munich | Germany</a></li>
<li><a rel="nofollow" href="tel:+49 173 4298898" title="Phone through">+49 173 4298898</a></li>
<li><a rel="nofollow" href="mailto:milo@3oneseven.com" title="Email me">milo&#64;3oneseven</a></li>
</ul>

<?php endif; ?>
</div>

<div class="col7">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column2') ) : ?>

<h3><?php _e('So<span>cial</span>'); ?></h3>

<ul>
<li><a title="Follow on Twitter" href="http://twitter.com/milo317">Twitter</a></li>
<li><a title="Follow on Facebook" href="http://www.facebook.com/milo317">Facebook</a></li> 
<li><a title="Follow on Flickr" href="http://www.flickr.com/photos/milo3oneseven/">Flickr</a></li>
<li><a href="http://milo317.com/">milo317</a></li>
<li><a href="http://de.milo317.com/">Deutsche webseite</a></li>
</ul>

<?php endif; ?>
</div>

<div class="col7">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column3') ) : ?>

<h3><?php _e('Pop<span>ular</span>'); ?></h3>

<?php $result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , 4"); 
foreach ($result as $post) { 
setup_postdata($post);
$postid = $post->ID; 
$title = $post->post_title; 
$commentcount = $post->comment_count; 
if ($commentcount != 0) { ?> 

<ul>
<li><a href="<?php echo get_permalink($postid); ?>" title="<?php echo $title ?>">
<?php echo $title ?></a> <?php _e('with'); ?> <?php echo $commentcount ?> <?php _e('Comments'); ?></li>
</ul>
<?php } } ?>

<?php endif; ?>
</div>

<div class="col777">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column4') ) : ?>

<h3><?php _e('About <span>Us</span>'); ?></h3>
<?php query_posts('pagename=about');?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php the_content_rss('', FALSE, 'more_file', 28); ?>
<br /><a href="/about/">Read more...&#8594; </a>
<?php endwhile; endif; ?>  		

<?php endif; ?>
</div>

<p class="copyright">&copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> <span><?php bloginfo('description'); ?></span></p>
<p class="credits"><a href="http://3oneseven.com/">Design by milo</a></p>

</div>
</div>
</div>

<?php wp_footer(); ?>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>