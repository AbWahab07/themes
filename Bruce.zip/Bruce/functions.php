<?php
function custom_colors() {
   echo '<style type="text/css">#wpadminbar,#wpcontent{background:#fff !important;border-bottom:5px solid #ccc;color:#333;text-shadow:#fff 0 1px 1px;}#wpadminbar #wp-admin-bar-wp-logo,#wpadminbar .ab-icon,#wp-admin-bar-wp-logo,#message{display:none !important;}#footer{background:#fff !important;border-top:5px solid #ccc;color:#333;}#user_info p,#user_info p a,#wphead a{color:#900 !important;}#wp-admin-bar-wp-logo{display:none !important;}</style>';
}
add_action('admin_head', 'custom_colors'); 
function disable_wp_emojicons() {
  remove_action( 'admin_print_styles', 'print_emoji_styles' );
  remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
  remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
  remove_action( 'wp_print_styles', 'print_emoji_styles' );
  remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
  remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
  remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
  add_filter( 'tiny_mce_plugins', 'disable_emojicons_tinymce' );
}
add_action( 'init', 'disable_wp_emojicons' );
function disable_emojicons_tinymce( $plugins ) {
  if ( is_array( $plugins ) ) {
    return array_diff( $plugins, array( 'wpemoji' ) );
  } else {
    return array();
  }
}   
add_theme_support( 'post-thumbnails' );
if ( !defined('ABSPATH')) exit;
load_theme_textdomain('Detox', get_template_directory().'/languages');
$locale = get_locale();
$locale_file = get_template_directory().'/languages/$locale.php';
if (is_readable( $locale_file))
require_once( $locale_file);
function Detox_category_rel_removal ($output) {
    $output = str_replace(' rel="category tag"', '', $output);
    return $output;
}
add_filter('wp_list_categories', 'Detox_category_rel_removal');
add_filter('the_category', 'Detox_category_rel_removal');  

remove_action('wp_head', 'wp_generator');

function custom_excerpt_length( $length ) {
	return 20;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );
add_image_size( 'mini', 600, 600, true );
add_image_size( 'cslider', 1682, 964, true );
add_image_size( 'gallerie', 940, 990, true );
add_image_size( 'front', 440, 430, true );
add_image_size( 'special', 700, 950, true );
add_image_size( 'specials', 700, 950, true );
add_image_size( 'hefte', 900, 950, true );
add_image_size( 'bigg', 1682, 964, true );
if ( is_admin() && isset($_GET['activated'] ) && $pagenow == 'themes.php' ) {
    update_option( 'posts_per_page', 6 );
    update_option( 'paging_mode', 'ajax' );
}

add_action( 'after_setup_theme', 'regMyMenus' );
function regMyMenus() {
// This theme uses wp_nav_menu() in four locations.
register_nav_menus( array(
'top-nav' => __( 'Main Menu', 'Detox' ),
'mobile-nav' => __( 'Mobile Menu', 'Detox' ),
'mnav' => __( 'Mobile Menu', 'Detox' ),
) );
}
function topnav_fallback() {
?>
<ul id="top-nav" role="navigation">
<li class="<?php if ( is_home() or (function_exists('is_tag') and is_tag()) ) { ?>current_page_item<?php } else { ?>page_item<?php } ?>"><a href="<?php home_url(); ?>/">
<?php _e('Home', 'Detox') ?></a></li>
<?php wp_list_pages('title_li=&depth=1&exclude=&sort_column=menu_order'); ?>
</ul> 
<?php
}
function mobilenav_fallback() {
?>
<ul id="top-navs" role="navigation">
<li class="<?php if ( is_home() or (function_exists('is_tag') and is_tag()) ) { ?>current_page_item<?php } else { ?>page_item<?php } ?>"><a href="<?php home_url(); ?>/">
<?php _e('Home', 'Detox') ?></a></li>
<?php wp_list_pages('title_li=&depth=1&exclude=&sort_column=menu_order'); ?>
</ul> 
<?php
}
function mnav_fallback() {
?>
<ul>
<?php wp_list_pages('title_li=&depth=1'); ?>
</ul>
<?php
}
function admin_favicon() {
	echo '<link rel="Shortcut Icon" type="image/x-icon" href="'.get_bloginfo('stylesheet_directory').'/images/icon/favicon.gif" />';
}
add_action('admin_head', 'admin_favicon');

class Recentposts_thumbnail extends WP_Widget {
    function Recentposts_thumbnail() {
        parent::WP_Widget(false, $name = 'Recent Posts');
    }
    function widget($args, $instance) {
        extract( $args );
        $title = apply_filters('widget_title', $instance['title']);
        ?>
            <?php echo $before_widget; ?>
            <?php if ( $title ) echo $before_title . $title . $after_title;  else echo '<div class="widget-body clear">'; ?>
            <?php
                global $post;
                if (get_option('rpthumb_qty')) $rpthumb_qty = get_option('rpthumb_qty'); else $rpthumb_qty = 5;
                $q_args = array(
                    'numberposts' => $rpthumb_qty,
                );
                $rpthumb_posts = get_posts($q_args);
                foreach ( $rpthumb_posts as $post ) :
                    setup_postdata($post);
            ?>
                <a href="<?php the_permalink(); ?>" class="rpthumb clear">
                    <?php if ( has_post_thumbnail() && !get_option('rpthumb_thumb') ) {
                        the_post_thumbnail('mini-thumbnail');
                        $offset = 'style="padding-left: 65px;"';
                    }
                    ?>
                    <span class="rpthumb-title" <?php echo $offset; ?>><?php the_title(); ?></span>
                    <span class="rpthumb-date" <?php echo $offset; unset($offset); ?>><?php the_time(__('M j, Y')) ?></span>
                </a>
            <?php endforeach; ?>
            <?php echo $after_widget; ?>
        <?php
    }
    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        update_option('rpthumb_qty', $_POST['rpthumb_qty']);
        update_option('rpthumb_thumb', $_POST['rpthumb_thumb']);
        return $instance;
    }
    function form($instance) {
        $title = esc_attr($instance['title']);
        ?>
            <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
            <p><label for="rpthumb_qty">Number of posts:  </label><input type="text" name="rpthumb_qty" id="rpthumb_qty" size="2" value="<?php echo get_option('rpthumb_qty'); ?>"/></p>
            <p><label for="rpthumb_thumb">Hide thumbnails:  </label><input type="checkbox" name="rpthumb_thumb" id="rpthumb_thumb" <?php echo (get_option('rpthumb_thumb'))? 'checked="checked"' : ''; ?>/></p>
        <?php
    }

}
add_action('widgets_init', create_function('', 'return register_widget("Recentposts_thumbnail");'));

function commentslist($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	<li>
        <div id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
            <table>
                <tr>
                    <td>
                        <?php echo get_avatar($comment, 70, get_bloginfo('template_url').'/images/icon/logo.png'); ?>
                    </td>
                    <td>
                        <div class="comment-meta">
                            <?php printf(__('<p class="comment-author"><span>%s</span></p>'), get_comment_author_link()) ?>
                            <?php printf(__('<p class="comment-date">%s</p>'), get_comment_date('M j, Y')) ?>
                            <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
                        </div>
                    </td>
                    <td>
                        <div class="comment-text">
                            <?php if ($comment->comment_approved == '0') : ?>
                                <p><?php _e('Your comment is awaiting moderation.') ?></p>
                                <br />
                            <?php endif; ?>
                            <?php comment_text() ?>
                        </div>
                    </td>
                </tr>
            </table>
         </div>
<?php
}

function comments_link_attributes(){
    return ' class="comments_popup_link"';
}
add_filter('comments_popup_link_attributes', 'comments_link_attributes');

function next_posts_attributes(){
    return 'class="nextpostslink"';
}
add_filter('next_posts_link_attributes', 'next_posts_attributes');

function milo_body_control() { 
global $post;
$postclass = $post->post_name;
if (is_home()) { 
echo 'id="home" class="bruce-theme-design-by-milo317"'; 
} elseif (is_single()) { 
echo 'id="single" class="' . $postclass . ' bruce-theme-design-by-milo317"';
} elseif (is_page()) { 
echo 'id="page" class=" ' . $postclass . ' bruce-theme-design-by-milo317"';
} elseif (is_category()) { 
echo 'id="single" class="category bruce-theme-design-by-milo317"';
} elseif (is_archive()) { 
echo 'id="single" class="arch bruce-theme-design-by-milo317"';
} elseif (is_404()) { 
echo 'id="single" class="error bruce-theme-design-by-milo317"';
} elseif (is_search()) { 
echo 'id="single" class="searchme bruce-theme-design-by-milo317"'; 
} 
}

function remove_footer_admin () {
    echo "Thank you for creating with <a href='http://3oneseven.com/'>milo</a>.";
} 
add_filter('admin_footer_text', 'remove_footer_admin'); 

add_action('admin_head', 'my_custom_logo');
function my_custom_logo() {
   echo '
      <style type="text/css">
         #header-logo { background-image: url('.get_bloginfo('template_directory').'/images/icon/favicon.png) !important; }
      </style>
   ';
}

function custom_login() { 
echo '<link rel="stylesheet" type="text/css" href="' . get_template_directory_uri() . '/log/log.css" />'; 
}   
add_action('login_head', 'custom_login');
function fb_login_headerurl() {
	$url = bloginfo('url');
	echo $url;
}
add_filter( 'login_headerurl', 'fb_login_headerurl' );
function fb_login_headertitle() {
	$name = get_option('blogname');
	echo $name;
}
add_filter( 'login_headertitle', 'fb_login_headertitle' );

function Bruce_remove_recent_comments_style() {
	global $wp_widget_factory;
	remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}
add_action( 'widgets_init', 'Bruce_remove_recent_comments_style' );

add_filter('get_comments_number', 'comment_count', 0);
function comment_count( $count ) {
        if ( ! is_admin() ) {
                global $id;
                $comments_by_type = &separate_comments(get_comments('status=approve&post_id=' . $id));
                return count($comments_by_type['comment']);
        } else {
                return $count;
        }
}

function unregister_default_wp_widgets() { 
	unregister_widget('WP_Widget_Meta');
	unregister_widget('WP_Widget_Search'); 
	unregister_widget('WP_Widget_Recent_Posts'); 
	unregister_widget('WP_Widget_Tag_Cloud');
} 
add_action('widgets_init', 'unregister_default_wp_widgets', 1);

$ThemeName = "rion";

// sidebar stuff
register_sidebars( 1,
	array( 
		'name' => 'Sidebar',
		'id' => 'sidebar',
			'description' => __('The single sidebar widget area.'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</ul></div></div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3><div class="list-bg"><ul class="list-4">'
	) 
);
register_sidebars( 1, 
	array( 
		'name' => __('Tag Box 1', 'Detox'),
		'id' => 'tag-column1',
		'description' => __('The 1st column tag widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h1 class="widgettitle">',
        'after_title' => '</h1>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => __('Tag Box 2', 'Detox'),
		'id' => 'tag-column2',
		'description' => __('The 2nd column tag widget area.', 'Detox'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '',
        'after_title' => ''
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Footer Box 1',
		'id' => 'footer-column1',
		'description' => __('The footer widget area 1st box.'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
register_sidebars( 1,
	array( 
		'name' => 'Footer Box 2',
		'id' => 'footer-column2',
		'description' => __('The footer widget area 2nd box.'),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);
function wp_pagenavi($before = '', $after = '', $prelabel = '', $nxtlabel = '', $pages_to_show = 5, $always_show = false) {
	global $request, $posts_per_page, $wpdb, $paged;
	if(empty($prelabel)) {
		$prelabel  = '<strong>&laquo;</strong>';
	}
	if(empty($nxtlabel)) {
		$nxtlabel = '<strong>&raquo;</strong>';
	}
	$half_pages_to_show = round($pages_to_show/2);
	if (!is_single()) {
		if(!is_category()) {
			preg_match('#FROM\s(.*)\sORDER BY#siU', $request, $matches);		
		} else {
			preg_match('#FROM\s(.*)\sGROUP BY#siU', $request, $matches);		
		}
		$fromwhere = $matches[1];
		$numposts = $wpdb->get_var("SELECT COUNT(DISTINCT ID) FROM $fromwhere");
		$max_page = ceil($numposts /$posts_per_page);
		if(empty($paged)) {
			$paged = 1;
		}
		if($max_page > 1 || $always_show) {
			echo "$before <div class='Nav'><span>Seiten ($max_page): </span>";
			if ($paged >= ($pages_to_show-1)) {
				echo '<a href="'.get_pagenum_link().'">&laquo; Erste Seite</a> ... ';
			}
			previous_posts_link($prelabel);
			for($i = $paged - $half_pages_to_show; $i  <= $paged + $half_pages_to_show; $i++) {
				if ($i >= 1 && $i <= $max_page) {
					if($i == $paged) {
						echo "<strong class='on'>$i</strong>";
					} else {
						echo ' <a href="'.get_pagenum_link($i).'">'.$i.'</a> ';
					}
				}
			}
			next_posts_link($nxtlabel, $max_page);
			if (($paged+$half_pages_to_show) < ($max_page)) {
				echo ' ... <a href="'.get_pagenum_link($max_page).'">Letzte Seite &raquo;</a>';
			}
			echo "</div> $after";
		}
	}
}

function dimox_breadcrumbs() { 
  $delimiter = '&raquo;';
  $home = 'Home'; // text for the 'Home' link
  $before = '<span class="current">'; // tag before the current crumb
  $after = '</span>'; // tag after the current crumb 
  if ( !is_home() && !is_front_page() || is_paged() ) {
    echo '<div id="crumbs">'; 
    global $post;
    $homeLink = get_bloginfo('url');
    echo '<a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' '; 
    if ( is_category() ) {
      global $wp_query;
      $cat_obj = $wp_query->get_queried_object();
      $thisCat = $cat_obj->term_id;
      $thisCat = get_category($thisCat);
      $parentCat = get_category($thisCat->parent);
      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
      echo $before . 'Archive by category "' . single_cat_title('', false) . '"' . $after; 
    } elseif ( is_day() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
      echo $before . get_the_time('d') . $after; 
    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo $before . get_the_time('F') . $after; 
    } elseif ( is_year() ) {
      echo $before . get_the_time('Y') . $after; 
    } elseif ( is_single() && !is_attachment() ) {
      if ( get_post_type() != 'post' ) {
        $post_type = get_post_type_object(get_post_type());
        $slug = $post_type->rewrite;
        echo '<a href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a> ' . $delimiter . ' ';
        echo $before . get_the_title() . $after;
      } else {
        $cat = get_the_category(); $cat = $cat[0];
        echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
        echo $before . get_the_title() . $after;
      } 
    } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
      $post_type = get_post_type_object(get_post_type());
      echo $before . $post_type->labels->singular_name . $after; 
    } elseif ( is_attachment() ) {
      $parent = get_post($post->post_parent);
      $cat = get_the_category($parent->ID); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
      echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';
      echo $before . get_the_title() . $after; 
    } elseif ( is_page() && !$post->post_parent ) {
      echo $before . get_the_title() . $after; 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
      echo $before . get_the_title() . $after; 
    } elseif ( is_search() ) {
      echo $before . 'Search results for "' . get_search_query() . '"' . $after; 
    } elseif ( is_tag() ) {
      echo $before . 'Posts tagged "' . single_tag_title('', false) . '"' . $after; 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo $before . 'Articles posted by ' . $userdata->display_name . $after;
    } elseif ( is_404() ) {
      echo $before . 'Error 404' . $after;
    }
    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
      echo __('Page') . ' ' . get_query_var('paged');
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
    } 
    echo '</div>'; 
  }
} // end dimox_breadcrumbs()
if ( !class_exists( 'Featured_Image_Column' ) ) {
	class Featured_Image_Column {		
		const domain  = 'featured-image-column';
		const version = '0.2.1';
		function __construct() {
			add_action( 'load-edit.php', array( $this, 'load' ) );
		}
		function load() {
			add_action( 'wp', array( $this, 'init' ) );
		}
		function init() {
			$post_type = get_post_type();						
			if ( !self::included_post_types( $post_type ) )
				return;
			add_action( 'admin_enqueue_scripts',					array( $this, 'style' ), 0 );
			add_filter( "manage_{$post_type}_posts_columns",		array( $this, 'columns' ) );
			add_action( "manage_{$post_type}_posts_custom_column",	array( $this, 'column_data' ), 10, 2 );	
			do_action( 'featured_image_column_loaded' );
		}
		function remove_post_type( $post_types ) {						
			foreach( $post_types as $key => $post_type ) {
				if ( 'page' === $post_type )
					unset( $post_types[$key] );
			}
			return $post_types;
		}
		function style() {
			wp_register_style( 'featured-image-column', apply_filters( 'featured_image_column_css', plugin_dir_url( __FILE__ ) . 'css/column.css' ), null, self::version );
			wp_enqueue_style( 'featured-image-column' );
		}
		function columns( $columns ) {
			if ( !is_array( $columns ) )
				$columns = array();			
			$new = array();			
			foreach( $columns as $key => $title ) {
				if ( $key == 'title' ) // Put the Thumbnail column before the Title column
					$new['featured-image'] = __( 'Image', self::domain );				
				$new[$key] = $title;
			}			
			return $new;
		}
		function column_data( $column_name, $post_id ) {
			global $post;			
			if ( 'featured-image' != $column_name )
				return;						
			$image_src = self::get_the_image( $post_id );						
			if ( empty( $image_src ) ) {
				echo "&nbsp;"; // This helps prevent issues with empty cells
				return;
			}			
			echo '<img alt="' . esc_attr( get_the_title() ) . '" src="' . esc_url( $image_src ) . '" />';
		}
		function included_post_types( $post_type ) {			
			$post_types = array();
			$get_post_types = get_post_types();			
			foreach ( $get_post_types as $type )
				if ( post_type_supports( $type, 'thumbnail' ) )
					$post_types[] = $type;			
			$post_types = apply_filters( 'featured_image_column_post_types', $post_types );			
			if ( defined( 'WP_LOCAL_DEV' ) && WP_LOCAL_DEV ) {
				print_r( $post_types );
			}			
			if ( in_array( $post_type, $post_types ) )
				return true;
			else
				return false;
		}
		function get_the_image( $post_id = false ) {			
			$post_id	= (int)$post_id;
			$cache_key	= "featured_image_post_id-{$post_id}-_thumbnail";
			$cache		= wp_cache_get( $cache_key, null );			
			if ( !is_array( $cache ) )
				$cache = array();		
			if ( !array_key_exists( $cache_key, $cache ) ) {
				if ( empty( $cache) || !is_string( $cache ) ) {
					$output = '';						
					if ( has_post_thumbnail( $post_id ) ) {
						$image_array = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), array( 36, 32 ) );						
						if ( is_array( $image_array ) && is_string( $image_array[0] ) )
							$output = $image_array[0];
					}					
					if ( empty( $output ) ) {
						$output = plugins_url( 'images/default.png', __FILE__ );
						$output = apply_filters( 'featured_image_column_default_image', $output );
					}					
					$output = esc_url( $output );
					$cache[$cache_key] = 
					$output;					
					wp_cache_set( $cache_key, $cache, null, 60 * 60 * 24 /* 24 hours */ );
				}
			}
			return $output;
		}
	}	
	$featured_image_column = new Featured_Image_Column();
};
if ( ! function_exists( 'catchids_column' ) ):
function catchids_column($cols) {
	$cols['catchids'] = 'ID';
	return $cols;
}
endif; // catchids_column
if ( ! function_exists( 'catchids_value' ) ) :
function catchids_value($column_name, $id) {
	if ($column_name == 'catchids')
		echo $id;
}
endif; // catchids_value
if ( ! function_exists( 'catchids_return_value' ) ) :
function catchids_return_value($value, $column_name, $id) {
	if ($column_name == 'catchids')
		$value = $id;
	return $value;
}
endif; // catchids_return_value
if ( ! function_exists( 'catchids_css' ) ) :
function catchids_css() {
?>
<style type="text/css">
	#catchids { 
		width: 50px; 
	}
</style>
<?php	
}
endif; // catchids_css
if ( ! function_exists( 'catchids_add' ) ) :
function catchids_add() {
	add_action('admin_head', 'catchids_css');
	add_filter('manage_pages_columns', 'catchids_column');
	add_action('manage_pages_custom_column', 'catchids_value', 10, 2);
	add_filter('manage_media_columns', 'catchids_column');
	add_action('manage_media_custom_column', 'catchids_value', 10, 2);
	add_filter('manage_link-manager_columns', 'catchids_column');
	add_action('manage_link_custom_column', 'catchids_value', 10, 2);
	add_action('manage_edit-link-categories_columns', 'catchids_column');
	add_filter('manage_link_categories_custom_column', 'catchids_return_value', 10, 3);
	foreach ( get_taxonomies() as $taxonomy ) {
		add_action("manage_edit-${taxonomy}_columns", 'catchids_column');			
		add_filter("manage_${taxonomy}_custom_column", 'catchids_return_value', 10, 3);
	}
	add_action('manage_users_columns', 'catchids_column');
	add_filter('manage_users_custom_column', 'catchids_return_value', 10, 3);
	add_action('manage_edit-comments_columns', 'catchids_column');
	add_action('manage_comments_custom_column', 'catchids_value', 10, 2);
}
endif; // catchids_add

function aldenta_get_images($size = 'full') {
global $post; 
$photos = get_children( array('post_parent' => $post->ID, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID') ); 
$results = array(); 
if ($photos) {
foreach ($photos as $photo) {
$results[] = wp_get_attachment_image($photo->ID, $size);
}
} 
return $results;
}
function myavatar_add_default_avatar( $url )
{
return get_stylesheet_directory_uri() .'/images/icon/logo.png';
}
add_filter( 'bp_core_mysteryman_src', 'myavatar_add_default_avatar' ); 
function my_default_get_group_avatar($avatar) {
global $bp, $groups_template;
if( strpos($avatar,'group-avatars') ) {
return $avatar;
}
else {
$custom_avatar = get_stylesheet_directory_uri() .'/images/icon/logo.png';
if($bp->current_action == "")
return '<img width="'.BP_AVATAR_THUMB_WIDTH.'" height="'.BP_AVATAR_THUMB_HEIGHT.'" src="'.$custom_avatar.'" class="avatar" alt="' . esc_attr( $groups_template->group->name ) . '" />';
else
return '<img width="'.BP_AVATAR_FULL_WIDTH.'" height="'.BP_AVATAR_FULL_HEIGHT.'" src="'.$custom_avatar.'" class="avatar" alt="' . esc_attr( $groups_template->group->name ) . '" />';
}
}
add_filter( 'bp_get_group_avatar', 'my_default_get_group_avatar');
add_filter( 'max_srcset_image_width', create_function( '', 'return 1;' ) );
add_action( 'wp_enqueue_scripts', 'child_manage_woocommerce_styles', 99 );
function child_manage_woocommerce_styles() {
	//remove generator meta tag
	remove_action( 'wp_head', array( $GLOBALS['woocommerce'], 'generator' ) );
	//first check that woo exists to prevent fatal errors
	if ( function_exists( 'is_woocommerce' ) ) {
		//dequeue scripts and styles
		if ( ! is_woocommerce() && ! is_cart() && ! is_checkout() ) {
      wp_dequeue_style( 'woocommerce-layout' );
      wp_dequeue_style( 'woocommerce-smallscreen' );
      wp_dequeue_style( 'woocommerce' );
      wp_dequeue_style( 'woocommerce-general' );
			wp_dequeue_style( 'woocommerce_frontend_styles' );
			wp_dequeue_style( 'woocommerce_fancybox_styles' );
			wp_dequeue_style( 'woocommerce_chosen_styles' );
			wp_dequeue_style( 'woocommerce_prettyPhoto_css' );
			wp_dequeue_script( 'wc_price_slider' );
			wp_dequeue_script( 'wc-single-product' );
			wp_dequeue_script( 'wc-add-to-cart' );
			wp_dequeue_script( 'wc-cart-fragments' );
			wp_dequeue_script( 'wc-checkout' );
			wp_dequeue_script( 'wc-add-to-cart-variation' );
			wp_dequeue_script( 'wc-single-product' );
			wp_dequeue_script( 'wc-cart' );
			wp_dequeue_script( 'wc-chosen' );
			wp_dequeue_script( 'woocommerce' );
			wp_dequeue_script( 'prettyPhoto' );
			wp_dequeue_script( 'prettyPhoto-init' );
			wp_dequeue_script( 'jquery-blockui' );
			wp_dequeue_script( 'jquery-placeholder' );
			wp_dequeue_script( 'fancybox' );
			wp_dequeue_script( 'jqueryui' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'child_manage_buddypress_styles', 99 );
function child_manage_buddypress_styles() {
	//first check that woo exists to prevent fatal errors
	if ( function_exists( 'is_buddypress' ) ) {
		//dequeue scripts and styles
		if ( ! is_buddypress() && ! is_buddypress() && ! !bp_is_blog_page() ) {
      wp_dequeue_style( 'bp-legacy-css' );
      wp_dequeue_style( 'bp-mentions-css' );
			wp_deregister_script( 'bp-confirm' );
			wp_deregister_script( 'bp-widget-members' );
			wp_deregister_script( 'bp-jquery-query' );
			wp_deregister_script( 'bp-jquery-cookie' );
			wp_deregister_script( 'bp-jquery-scroll-to' );
			wp_deregister_script( 'bp-buddypress' );
      wp_deregister_script( 'bp-jquery-caret' );
			wp_deregister_script( 'bp-jquery-atwho' );
			wp_deregister_script( 'bp-mentions' );
		}
	}
}
function your_theme_xprofile_cover_image( $settings = array() ) {
    $settings['default_cover'] = '/wp-content/themes/Bruce/images/cover.jpg'; 
    return $settings;
}
add_filter( 'bp_before_groups_cover_image_settings_parse_args', 'your_theme_xprofile_cover_image', 10, 1 );
function your_xtheme_xprofile_cover_image( $settings = array() ) {
    $settings['default_cover'] = '/wp-content/themes/Bruce/images/cover.jpg'; 
    return $settings;
}
add_filter( 'bp_before_xprofile_cover_image_settings_parse_args', 'your_xtheme_xprofile_cover_image', 10, 1 );
function vp_get_thumb_url($text, $size){
        global $post;
        $imageurl="";
        $featuredimg = get_post_thumbnail_id($post->ID);
        $img_src = wp_get_attachment_image_src($featuredimg, $size);
        $imageurl=$img_src[0];
        if (!$imageurl) {
                $allimages =&get_children('post_type=attachment&post_mime_type=image&post_parent=' . $post->ID );
                foreach ($allimages as $img){
                        $img_src = wp_get_attachment_image_src($img->ID, $size);
                        break;
                }
                $imageurl=$img_src[0];
        }
        if (!$imageurl) {
                preg_match('/<\s*img [^\>]*src\s*=\s*[\""\']?([^\""\'>]*)/i' ,  $text, $matches);
                $imageurl=$matches[1];
        }
        if (!$imageurl){
                preg_match("/([a-zA-Z0-9\-\_]+\.|)youtube\.com\/watch(\?v\=|\/v\/)([a-zA-Z0-9\-\_]{11})([^<\s]*)/", $text, $matches2);
                $youtubeurl = $matches2[0];
                $videokey = $matches2[3];
        if (!$youtubeurl) {
                preg_match("/([a-zA-Z0-9\-\_]+\.|)youtu\.be\/([a-zA-Z0-9\-\_]{11})([^<\s]*)/", $text, $matches2);
                $youtubeurl = $matches2[0];
                $videokey = $matches2[2];
        }
        if ($youtubeurl)
                $imageurl = "http://i.ytimg.com/vi/{$videokey}/0.jpg";
        }
        if (!$imageurl) {
                $dir = get_template_directory_uri() . '/images/'; // [SET MANUALLY!!!]
                $get_cat = get_the_category();
                $cat = $get_cat[0]->
                slug;
                $imageurl = $dir . $cat . '.jpg'; // [SET MANUALLY!!!]
                $array = array( 'cat_1', 'cat_2', 'cat_3',);
                if (!in_array($cat, $array))
                        $imageurl = $dir . 'cover.jpg'; // [SET MANUALLY!!!]
        }
        return $imageurl;
}
add_filter('next_posts_link_attributes', 'posts_link_attributes_1');
add_filter('previous_posts_link_attributes', 'posts_link_attributes_2');
function posts_link_attributes_1() {
    return 'rel="prev" class="prev"';
}
function posts_link_attributes_2() {
    return 'rel="next" class="next"';
} 
?>