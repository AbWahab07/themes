<?php $loop = new WP_Query( array( 'post_type' => 'product', 'posts_per_page' => 1 ) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>


<div class="ausgabe">
<div class="atext">
<h4><span><?php _e( 'Related') ?></span></h4>
<h2><a href="<?php the_permalink() ?>"><?php echo $product->get_price_html(); ?></a></h2>
<h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<div class="buy"><a href="<?php the_permalink() ?>"><?php _e( 'View Item') ?><div class="iconWrapper">
	    <div class="play icon"></div>
	</div>
</a></div>
</div>
<div class="asimg animated rotateInDownRight">
<a href="<?php the_permalink() ?>">
<?php if(has_post_thumbnail()) :?>
<?php $img = get_the_post_thumbnail($post->ID, 'specials'); ?><?php echo $img; ?>
<?php else :?>
<img src="<?php echo get_template_directory_uri(); ?>/images/img.jpg" alt="<?php the_title(); ?>" />
<?php endif;?>
</a>
</div>
</div>

<?php endwhile; ?>