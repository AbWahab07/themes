<?php get_header(); ?>
<div id="top"></div>
<?php get_template_part('item'); ?>
<?php
/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('shop');
} else {
get_template_part('front');
}
?>
<?php get_template_part('sgal'); ?>
<?php get_template_part('sfront'); ?>
<?php get_template_part('cam'); ?>
</div>
<?php get_footer(); ?>