<div class="wrapper animated fadeInLeftBig">
<div class="ren"></div>  	
<div class="hen"><h2>The Bruce theme</h2></div>

<div id="stfeatured"> 		

<div class="tl">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column1') ) : ?>
<h1>The Bruce Magazine Theme </h1>
<div class="ssread"><a class="a-btn" href="https://3oneseven.com/bruce-magazine-theme/">Download</a></div>
<div class="ssread"><a class="a-btn" href="https://wp.3oneseven.com/?wptheme=Bruce">Demo</a></div>
<?php endif; ?>
</div>
<div class="tr">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column2') ) : ?>
<a href="https://3oneseven.com/bruce-magazine-theme/"><img src="<?php echo get_template_directory_uri(); ?>/images/bruce-wordpres-theme.png" alt="Bruce Magazine Theme template" /></a></div>
<?php endif; ?>
</div>
</div>