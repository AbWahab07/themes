<?php get_header(); ?>
<div id="main">
<div id="cow" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/WebPage">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="content-title">
            <div itemprop="breadcrumb"><?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?></div>
          
</div>

<h1 itemprop="name headline"><?php the_title(); ?></h1>

<div class="entry" itemprop="articleBody">
<?php the_content('', ''); ?>
<div class="clearfix"></div><hr class="clear" />
<?php link_pages('<h4><strong>Pages:</strong> ', '</h4>', 'number'); ?>
<?php edit_post_link('<h3>Edit</h3>','',''); ?>
</div>
<div class="postspace"></div>
<hr class="clear" />
<?php get_template_part('shopbar'); ?>
<?php endwhile; endif; ?>

<div class="xcontent-title">
<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>

</div>
</div>
<?php get_footer(); ?>