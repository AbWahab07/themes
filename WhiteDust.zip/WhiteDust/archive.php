<?php
/*
Template Name: index
*/
?>
<?php get_header(); ?>
<div id="main">
<div id="cow">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="eregex">
<div class="col7 animated fadeIn">

<figure class="effect-layla">  
<div class="xxframe view view-first">
<a href="<?php the_permalink(); ?>">
 <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="xxy xk1" itemscope itemtype='http://schema.org/ImageObject' style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
</div>

<figcaption>
<div class="xdetails mask">
<h2><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
<div class="xlistview">
<p itemprop="description"><?php the_content_rss('', FALSE, '', 14); ?></p>
<form action="<?php the_permalink(); ?>" method="post" class="shopp productz">
<h4 class="addtocart"><?php _e('View more', 'Detox') ?></h4>
</form> 
</div>
</div>
</figcaption>
</a>
</div>
</figure>

<div class="xcenter">
<div class="ycenter">
<h4 itemprop="name"><a itemprop="url" href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
</div>
</div>

</div>
</div>

<?php endwhile; endif; ?>

<hr class="clear" /><div class="postspace"></div>
<div class="navigation">
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
</div>
</div>
</div>

<?php get_template_part('slider'); ?>
<?php get_template_part('rbar'); ?>
<?php get_footer(); ?>