<?php

function get_upload_field($id, $std = '', $desc = '') {

  $field = '<input id="' . $id . '" type="file" name="attachment_' . $id . '" />' .
           '<span class="submit"><input name="WhiteDust_upload" type="submit" value="Upload" class="button panel-upload-save" />
		   </span> <span class="description"> '. __($desc,'detox') .' </span>';

  return $field;
}

load_theme_textdomain('WhiteDust');
class WhiteDust {
	function addOptions () {
	
		if (isset($_POST['WhiteDust_reset'])) { WhiteDust::initOptions(true); }
		if (isset($_POST['WhiteDust_save'])) {

			$aOptions = WhiteDust::initOptions(false);
		
		$aOptions['featured1-image'] = stripslashes($_POST['featured1-image']);
    $aOptions['featured2-image'] = stripslashes($_POST['featured2-image']);
		$aOptions['featured3-image'] = stripslashes($_POST['featured3-image']);
		$aOptions['featured4-text'] = stripslashes($_POST['featured4-text']);
    			
			update_option('WhiteDust_theme', $aOptions);
		}
		if (isset($_POST['WhiteDust_upload'])) {

			$aOptions = WhiteDust::initOptions(false);

            $whitelist = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			
			if (!$_FILES['attachment_featured1-image']['type']=='') { 
				$up_file = 'featured1-image'; 
			}
			
			if (!$_FILES['attachment_featured2-image']['type']=='') { 
				$up_file = 'featured2-image'; 
			}
			
			if (!$_FILES['attachment_featured3-image']['type']=='') { 
				$up_file = 'featured3x-image'; 
			}
						
            $filetype = $_FILES['attachment_' . $up_file]['type'];

            if (in_array($filetype, $whitelist)) {
              $upload = wp_handle_upload($_FILES['attachment_' . $up_file], array('test_form' => false));
			  $aOptions[$up_file] = stripslashes($upload['url']);
			  update_option('WhiteDust_theme', $aOptions);
            }
		}
		add_theme_page(" WhiteDust Options", "WhiteDust Options", 'edit_themes', basename(__FILE__), array('WhiteDust', 'displayOptions'));
	}
	function initOptions ($bReset) {
		$aOptions = get_option('WhiteDust_theme');
		if (!is_array($aOptions) || $bReset) {
 
			$aOptions['featured1-image'] = get_bloginfo('url') . '/wp-content/themes/WhiteDust/images/favicon.png';
      $aOptions['featured2-image'] = get_bloginfo('url') . '/wp-content/themes/WhiteDust/images/logo.png';
			$aOptions['featured3-image'] = get_bloginfo('url') . '/wp-content/themes/WhiteDust/images/dior.gif';
			$aOptions['featured4-text'] = 'gdbr_2yY3tw';			
			update_option('WhiteDust_theme', $aOptions);
		}
		return $aOptions;
	}
	function displayOptions () {
		$aOptions = WhiteDust::initOptions(false);
?>
<div class="wrap">
	<h2>WhiteDust Theme Options</h2>
	<p>You can edit logo options by using the fields below.</p>

<div id="sideblock" style="float:right;width:220px;margin-left:10px;"> 
     <h3>Information</h3>
     <div id="dbx-content" style="text-decoration:none;">       
 		 <img src="<?php bloginfo('stylesheet_directory'); ?>/images/favicon.ico" width="20px" /><a style="text-decoration:none;" href="http://3oneseven.com/"> 3oneseven</a><br /><br />
		 <img src="<?php bloginfo('stylesheet_directory'); ?>/images/tweet.jpg" width="20px" /><a style="text-decoration:none;" href="http://twitter.com/milo317"> Follow on Twitter</a><br /><br />
    <img src="<?php bloginfo('stylesheet_directory'); ?>/images/fb.jpg" width="20px" /><a style="text-decoration:none;" href="https://www.facebook.com/3oneseven"> Follow on FaceBook</a><br /><br />			
</div>
</div> 
 
    <div style="margin-left:0px;">
    <form action="#" method="post" enctype="multipart/form-data" name="massive_form" id="massive_form">
		<fieldset name="general_options" class="options">
        <div style="border-bottom:1px solid #333;"></div>
        <h3 style="margin-bottom:0px;">Feature Options:</h3>
        <p style="margin-top:0px;">You can add by filling out the fields below.</p>
                	        
		<h3>Favicon</h3>
             
       Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured1-image" id="featured1-image" size="30" value="<?php echo($aOptions['featured1-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured1-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured1-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured1-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
    
     <div style="border-bottom:1px solid #333;"></div>
                  
        	<h3>Logo</h3>
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured2-image" id="featured1-image" size="30" value="<?php echo($aOptions['featured2-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured2-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured2-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured2-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
                	
		 <div style="border-bottom:1px solid #333;"></div>
		 
        <h3>Footer</h3>
	 
         Image Location:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured3-image" id="featured3-image" size="30" value="<?php echo($aOptions['featured3-image']); ?>"></input> 
        </div><br />

        or upload an Image:<br />
		<tr valign="top" class="upload <?php echo ($aOptions['featured3-image']); ?>">
          <th scope="row"><label for="<?php echo ($aOptions['featured3-image']); ?>"><?php echo __($value['name'],'detox'); ?></label></th>
          <td>
		  <div id='imgupload'>
            <?php print get_upload_field('featured3-image', '', $aOptions['desc']); ?>
			</div>
          </td>
        </tr>
                
<div style="border-bottom:1px solid #333;"></div>

<h3>Youtube Video</h3>
        Set the youtube video:<br />
		<div style="margin:0;padding:0;">
        <input style="margin:0;padding:0;width:80% !important;height:22px !important;border:1px solid #ccc !important;"  name="featured4-text" id="featured4-text" value="<?php echo($aOptions['featured4-text']); ?>"></input>
        </div><br />

<div style="border-bottom:1px solid #333;"></div>

		</fieldset>
		<p class="submit"><input type="submit" name="WhiteDust_reset" value="Reset" /></p>
		<p class="submit"><input type="submit" name="WhiteDust_save" value="Save" /></p>
	</form>      
</div>
<?php
	}
}
// Register functions
add_action('admin_menu', array('WhiteDust', 'addOptions'));
?>