<div id="xmow">

<ul class="ca-menu">

                    <?php 
	$slidecat = get_option('NewYorker_slicer_category'); 
	$my_query = new WP_Query('showposts=1&offset=2');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>                      <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
                    <li class="one" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
                        <a href="<?php the_permalink() ?>">
                           
                            <div class="ca-content">
                                <h2 class="ca-main"><?php the_title() ?></h2>
                                <h3 class="ca-sub"><?php the_title() ?></h3>
                            </div>
                             <span class="ca-icon"><?php
$category = get_the_category();
echo $category[0]->cat_name;
?></span>
                        </a>
                    </li>
                    <?php endwhile; ?>
                    
                    <?php 
	$slidecat = get_option('NewYorker_slicer_category'); 
	$my_query = new WP_Query('showposts=1&offset=3');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>                       <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
                    <li class="two" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
                        <a href="<?php the_permalink() ?>">
                            
                            <div class="ca-content">
                                <h2 class="ca-main"><?php the_title() ?></h2>
                                <h3 class="ca-sub"><?php the_title() ?></h3>
                            </div>
                            <span class="ca-icon"><?php
$category = get_the_category();
echo $category[0]->cat_name;
?></span>
                        </a>
                    </li>
                    <?php endwhile; ?>
                    
                    <?php 
	$slidecat = get_option('NewYorker_slicer_category'); 
	$my_query = new WP_Query('showposts=1&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>                       <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
                    <li class="three" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"> 
                        <a href="<?php the_permalink() ?>">
                            
                            <div class="ca-content">
                                <h2 class="ca-main"><?php the_title() ?></h2>
                                <h3 class="ca-sub"><?php the_title() ?></h3>
                            </div>
                            <span class="ca-icon"><?php
$category = get_the_category();
echo $category[0]->cat_name;
?></span>
                        </a>
                    </li>
                    <?php endwhile; ?>
                    
                    <?php 
	$slidecat = get_option('NewYorker_slicer_category'); 
	$my_query = new WP_Query('showposts=1&offset=5');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>                            <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
                    <li class="four" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
                        <a href="<?php the_permalink() ?>">
                            
                            <div class="ca-content">
                                <h2 class="ca-main"><?php the_title() ?></h2>
                                <h3 class="ca-sub"><?php the_title() ?></h3>
                            </div>
                            <span class="ca-icon"><?php
$category = get_the_category();
echo $category[0]->cat_name;
?></span>
                        </a>
                    </li>
                    <?php endwhile; ?>
                    
</ul>

</div>