<div class="col7x full">

<div class="smain">
<div class="ron">
<div class="titles">
<?php $aOptions = WhiteDust::initOptions(false); ?>
<img class="logo" itemprop="image" property="contentURL" src="<?php echo($aOptions['featured2-image']); ?>" title="<?php bloginfo('name'); ?>" alt="<?php bloginfo('name'); ?>" />
<h1 itemprop="headline"><a title="<?php _e('Homepage', 'Detox') ?>" href="<?php echo get_settings('home'); ?>/">Subscribe to updates</a></h1>
</div>
</div>
</div>

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column1') ) : ?>

<form class="aweber_form" method="post" action=""><input type="hidden" name="listname" value="bruce" />
<input type="hidden" name="redirect" value="" />
<input type="hidden" name="meta_adtracking" value="sidebar_form" />
<input type="hidden" name="meta_message" value="1" />
<input type="hidden" name="meta_required" value="email" />
<input type="hidden" name="meta_forward_vars" value="0" />
<input type="text" class="name" name="name" value="Your Name" onfocus="if (this.value == 'Your Name') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Name';}" />
<input type="text" class="email" name="email" value="Your Email" onfocus="if (this.value == 'Your Email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Email';}" />
<input type="submit" class="submit" name="submit" value="Subscribe" />
</form>
<?php endif; ?>
</div>

<div id="featured">

<div class="smain">
<div class="ron">
<div class="titles">
<?php $aOptions = WhiteDust::initOptions(false); ?>
<img class="logo" itemprop="image" property="contentURL" src="<?php echo($aOptions['featured2-image']); ?>" title="<?php bloginfo('name'); ?>" alt="<?php bloginfo('name'); ?>" />
<h1 itemprop="headline"><a title="<?php _e('Homepage', 'Detox') ?>" href="<?php echo get_settings('home'); ?>/">News</a></h1>
</div>
</div>
</div>

<div id="slider1" class="sliderwrapper">

<?php 
	$my_query = new WP_Query('showposts=1&offset=0&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
                
<div class="contentdiv"> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="h-f" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="cis">
<div class="h-t">
<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
<div class="ctitle"><?php the_category(' <span>/</span> '); ?></div>
<p><?php the_content_rss('', FALSE, ' ', 12); ?></p>
</div>
<a href="<?php the_permalink() ?>"></a>
</div>
</div> 

</div> 
               
<?php endwhile; ?>                           
                
<div id="paginate-slider1" class="pagination"></div>
<script type="text/javascript">
featuredcontentslider.init({
id: "slider1", 
contentsource: ["inline", ""], 
toc: "#increment", 
nextprev: ["", ""], 
revealtype: "mouseover", 
enablefade: [true, 0.9], 
autorotate: [true, 9000], 
onChange: function(previndex, curindex){ 
}
})
</script>
</div>
</div>

<?php if ( (is_home())  ) { ?>

<div class="smain">
<div class="ron">
<div class="titles">
<?php $aOptions = WhiteDust::initOptions(false); ?>
<img class="logo" itemprop="image" property="contentURL" src="<?php echo($aOptions['featured2-image']); ?>" title="<?php bloginfo('name'); ?>" alt="<?php bloginfo('name'); ?>" />
<h1 itemprop="headline"><a title="<?php _e('Homepage', 'Detox') ?>" href="<?php echo get_settings('home'); ?>/">#Featured on White Dust</a></h1>
</div>
</div>
</div>

<div class="wrapper">
<?php 
	$my_query = new WP_Query('showposts=3&offset=6');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
<div class="col7 animated fadeIn">

<figure class="effect-layla">  
<div class="xxframe view view-first">
<a href="<?php the_permalink(); ?>">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="xxy xk1" itemscope itemtype='http://schema.org/ImageObject' style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">

</div>

<figcaption>
<div class="xdetails mask">
<h2><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
<div class="xlistview">
<p itemprop="description"><?php the_content_rss('', FALSE, '', 14); ?></p>
<form action="<?php the_permalink(); ?>" method="post" class="shopp productz">
<h4 class="addtocart"><?php _e('View more', 'Detox') ?></h4>
</form> 
</div>
</div>
</figcaption>
</a>
</div>
</figure>

<div class="xcenter">
<div class="ycenter">
<h4 itemprop="name"><a itemprop="url" href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
</div>
</div>

</div>
<?php endwhile; ?>
</div>
<?php } else { ?><?php } ?>