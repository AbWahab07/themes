<div id="slider1" class="contentslide">
<div class="opacitylayer">

<?php 
	$my_query = new WP_Query('showposts=1&offset=0&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="contentdiv" role="main" itemscope="itemscope" itemType="http://schema.org/BlogPosting">
<div class="slideimg">
<div class="slimg" itemscope itemtype='http://schema.org/ImageObject'>
<a itemprop="url" href="<?php the_permalink() ?>"><?php $img = get_the_post_thumbnail($post->ID, 'slider'); ?><?php echo $img; ?></a>
</div>

<div class="slidetxt">

<div class="post-date" datetime="<?php the_date('F jS, Y'); ?>" itemprop="datePublished" pubdate>
<span class="post-day"><?php the_time('d') ?></span>
<span class="post-month"><?php the_time('M') ?></span> 
<span class="post-cat" itemprop="genre"><?php the_category(', ') ?></span> 
</div>

<h2 itemprop="name headline"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="sentry" itemprop="articleBody"><?php the_content_rss('', FALSE, ' ', 20); ?></div>
<h4><a href="<?php the_permalink() ?>">Read more</a></h4>
</div>
</div>
</div>

<?php endwhile; ?>

</div>

<div class="pagination" id="paginate-slider1"></div>

<script type="text/javascript">
//Define: ContentSlider("slider_ID", [autorotate_miliseconds], [custompaginatelinkstext], [customnextlinktext])
ContentSlider("slider1", 16000) 
</script>

</div>