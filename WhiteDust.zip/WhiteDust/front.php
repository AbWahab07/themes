<?php $loop = new WP_Query( array( 'post_type' => 'product', 'posts_per_page' => 6 ) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<div class="col7 animated fadeIn" itemscope itemtype="http://data-vocabulary.org/Product">

<figure class="effect-layla">
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>  
<div class="xxframe view view-first">
<a href="<?php the_permalink(); ?>">
<div class="xxy xk1" itemscope itemtype='http://schema.org/ImageObject'>
<?php if ( has_post_thumbnail() ) {the_post_thumbnail();} ?>
</div>

<figcaption>
<div class="xdetails mask">
<h2><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
<div class="xlistview">
<p itemprop="description"><?php the_content_rss('', FALSE, '', 14); ?></p>
<span itemprop="offerDetails" itemscope itemtype="http://data-vocabulary.org/Offer">
<h4><span itemprop="price"><?php echo $product->get_price_html(); ?></span></h4>
</span>
<form action="<?php the_permalink(); ?>" method="post" class="shopp productz">
<h4 class="addtocart"><?php _e('Details', 'Detox') ?></h4>
</form> 
</div>
</div>
</figcaption>
</a>
</div>
</figure>

<div class="xcenter">
<div class="ycenter">
<h4 itemprop="name"><a itemprop="url" href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
<span itemprop="price"><?php echo $product->get_price_html(); ?></span>
</div>
</div>

</div>
<?php endwhile; wp_reset_query(); ?>