</div>


<?php
  $orig_post = $post;
  global $post;
  $tags = wp_get_post_tags($post->ID);   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>1, // Number of related posts to display.
  'orderby'=>rand,
  'caller_get_posts'=>1
  
  );   
  $my_query = new wp_query( $args ); 
  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div id="xslider" class="contentslide animated fadeIn" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="slidetxt">

<div class="xpost-cat" itemprop="genre"><?php the_category(' / '); ?></div>
<h2 itemprop="name headline"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="arrow"><a href="<?php the_permalink() ?>"><?php _e('View more', 'Detox') ?></a></div>
</div>
</div>
<? }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>