<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="https://www.w3.org/1999/xhtml"><head profile="https://gmpg.org/xfn/11"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<?php $aOptions = WhiteDust::initOptions(false); ?>
<link rel="shortcut icon" type="image/ico" href="<?php echo($aOptions['featured1-image']); ?>" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />

<?php wp_head(); ?>        


<script  type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/modernizr.custom.js"></script>
</head>
<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="https://schema.org/WebPage">
<progress value="0" id="progressBar"><div class="progress-container"><span class="progress-bar"></span></div></progress>
<div class="container">	        
<div id="wrapper">

<div id="fheader">
<div id="header" class="xanimated fadeIn" role="banner" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
<div class="titles">
<?php $aOptions = WhiteDust::initOptions(false); ?>
<a title="<?php _e('Homepage', 'Detox') ?>" href="<?php echo get_settings('home'); ?>/"><img class="logo" itemprop="image" property="contentURL" src="<?php echo($aOptions['featured2-image']); ?>" title="<?php bloginfo('name'); ?>" alt="<?php bloginfo('name'); ?>" /></a>
<h1 itemprop="headline"><a title="<?php _e('Homepage', 'Detox') ?>" href="<?php echo get_settings('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
</div>
<div class="head" itemprop="description">
<h3><?php bloginfo('description'); ?></h3>
</div>

<div id="cnav" class="animated fadeIn">

</div>

<div id="sb-search">
<a href="#form" class="search-toggle bx" rel="ibox"><?php _e('Search', 'Detox') ?></a>
<div id="form" style="display: none;" >
<form id="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e('What are you looking for?', 'Detox'); ?>" name="s" id="s" onfocus="if (this.value == 'Search...', 'Detox') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search', 'Detox';}" />
</form>

<h3>Most Popular Posts</h3>
<?php
  $orig_post = $post;
  global $post;
  $tags = wp_get_post_tags($post->ID);   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>3, // Number of related posts to display.
  'orderby'=>rand,
  'caller_get_posts'=>1
  
  );   
  $my_query = new wp_query( $args ); 
  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>
<div class="col7 animated fadeIn">
<figure class="effect-layla">  
<div class="xxframe view view-first">
<a href="<?php the_permalink(); ?>">
 <?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="xxy xk1" itemscope itemtype='http://schema.org/ImageObject' style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
</div>
<figcaption>
<div class="xdetails mask">
<div class="xlistview">
 
</div>
</div>
</figcaption>
</a>
</div>
</figure>
<div class="xcenter">
<div class="ycenter">
<h4 itemprop="name"><a itemprop="url" href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
</div>
</div>
</div>
<? }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>
</div>
</div>

<div class="xtow2 animated slideInDown">
<div id="xnavbar" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<button id="trigger-overlay" type="button"><span style="display:none"><?php _e('Menu', 'Detox') ?></span></button>
</div>
</div>
</div>
</div>

<?php if ( (is_home())  ) { ?>
<?php get_template_part('top'); ?>
<?php } ?>