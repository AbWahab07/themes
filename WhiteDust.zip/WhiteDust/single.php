<?php
/*
Template Name: single
*/
?>
<?php get_template_part('header'); ?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div id="xslider" class="contentslide animated fadeIn" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="xcontentdiv">

<div class="slidetxt">

<div class="xpost-cat" itemprop="genre"><?php the_category(' / '); ?></div>
<h1 itemprop="name headline"><?php the_title(); ?></a></h1>
<div class="arrow"><?php the_time('M'); ?><span class="bigdate"><?php the_time('j'); ?></span> <?php the_time('Y'); ?></div>
</div>

</div>
</div>

<div id="main">
<div id="cow" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/WebPage">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="content-title">
            <div itemprop="breadcrumb"><?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?></div>
            <a href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;t=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="f" title="Share on Facebook"></a>
            <a href="http://twitter.com/home?status=<?php the_title(); ?> <?php the_permalink() ?>" target="_blank" class="t" title="Spread the word on Twitter"></a>
            <a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" class="di" title="Bookmark on Del.icio.us"></a>
            <a href="http://stumbleupon.com/submit?url=<?php the_permalink() ?>&amp;title=<?php echo urlencode(the_title('','', false)) ?>" target="_blank" class="su" title="Share on StumbleUpon"></a>
</div>

<div class="entry" itemprop="articleBody">
<?php the_content('', ''); ?>
<div class="clearfix"></div><hr class="clear" />
<?php link_pages('<h4><strong>Pages:</strong> ', '</h4>', 'number'); ?>
<?php edit_post_link('<h3>Edit</h3>','',''); ?>
</div>

</div>
</div>

<div class="smain">
<div class="ron">
<div class="titles">
<?php $aOptions = WhiteDust::initOptions(false); ?>
<img class="logo" itemprop="image" property="contentURL" src="<?php echo($aOptions['featured2-image']); ?>" title="<?php bloginfo('name'); ?>" alt="<?php bloginfo('name'); ?>" />
<h1 itemprop="headline"><a title="<?php _e('Homepage', 'Detox') ?>" href="<?php echo get_settings('home'); ?>/">Related</a></h1>
</div>
</div>
</div>
<?php
  $orig_post = $post;
  global $post;
  $tags = wp_get_post_tags($post->ID);   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>1, // Number of related posts to display.
  'caller_get_posts'=>1
  );   
  $my_query = new wp_query( $args ); 
  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div id="xslider" class="contentslide animated fadeIn" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="xcontentdiv">

<div class="slidetxt">

<div class="xpost-cat" itemprop="genre"><?php the_category(' / '); ?></div>
<h1 itemprop="name headline"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></a></h1>
<div class="arrow"><?php the_time('M'); ?><span class="bigdate"><?php the_time('j'); ?></span> <?php the_time('Y'); ?></div>
</div>

</div>
</div>
  <? }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>
  
<div class="smain">

<div class="post-navigation clear">
                <?php
                    $prev_post = get_adjacent_post(false, '', true);
                    $next_post = get_adjacent_post(false, '', false); ?>
                    <?php if ($prev_post) : $prev_post_url = get_permalink($prev_post->ID); $prev_post_title = $prev_post->post_title; ?>
                        <a class="post-prev" href="<?php echo $prev_post_url; ?>"><em><?php _e('Previous', 'Detox') ?></em><span><?php echo $prev_post_title; ?></span></a>
                    <?php endif; ?>
                    <?php if ($next_post) : $next_post_url = get_permalink($next_post->ID); $next_post_title = $next_post->post_title; ?>
                        <a class="post-next" href="<?php echo $next_post_url; ?>"><em><?php _e('Next', 'Detox') ?></em><span><?php echo $next_post_title; ?></span></a>
                    <?php endif; ?>
                
</div>

<?php endwhile; endif; ?>
<?php get_template_part('shopbar'); ?>
 <?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>
</div>
</div>
</div>
</div>
<nav class="nav-slide">
<?php 
$prev_post = get_adjacent_post(false, '', true);
if(!empty($prev_post)) {
echo '<a class="prev" href="' . get_permalink($prev_post->ID) . '"><span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>' . $prev_post->post_title . ' <span> Previously</span></h3></div></a>'; }
 ?>
<?php
$next_post = get_adjacent_post(false, '', false);
if(!empty($next_post)) {
echo '<a class="next" href="' . get_permalink($next_post->ID) . '">	<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>' . $next_post->post_title . ' <span>Next</span></h3></div></a>'; }
?>
</nav>
<?php get_template_part('slider'); ?>
<?php get_template_part('rbar'); ?>
<?php get_template_part('footer'); ?>