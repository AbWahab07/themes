<div id="sidebar">

<div id="feed">
<div class="rss">
<a href="<?php bloginfo('rss2_url'); ?>">Subscribe to the RSS Feed</a>
</div>
<div class="twit">
<a href="http://twitter.com/temperoUK">Follow us on twitter</a>
</div>
</div>

<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>

<h2>Recent Posts</h2>
<ul>
<?php get_archives('postbypost', 4); ?>
</ul>

<h2>Categories</h2>
<ul>
<?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?>
</ul>
		
<h2>Archives</h2>
<ul>
<?php wp_get_archives('type=monthly&show_post_count=true'); ?>
</ul>
        
<?php endif; ?>

</div>