<?php get_header(); ?>

<?php if ( (is_home())  ) { ?>
<div id="main">
<?php } else { ?>
<?php } ?>

<div class="ron">
<div class="titles">
<?php $aOptions = WhiteDust::initOptions(false); ?>
<img class="logo" itemprop="image" property="contentURL" src="<?php echo($aOptions['featured2-image']); ?>" title="<?php bloginfo('name'); ?>" alt="<?php bloginfo('name'); ?>" />
<h1 itemprop="headline"><a href="<?php echo get_settings('home'); ?>/">About</a></h1>
</div>
</div>

<?php get_template_part('slider'); ?>

<div class="ron">
<div class="titles">
<?php $aOptions = WhiteDust::initOptions(false); ?>
<img class="logo" itemprop="image" property="contentURL" src="<?php echo($aOptions['featured2-image']); ?>" title="<?php bloginfo('name'); ?>" alt="<?php bloginfo('name'); ?>" />
<h1 itemprop="headline"><a href="<?php echo get_settings('home'); ?>/">New Items</a></h1>
</div>
</div>

<div id="fow" class="animated fadeIn">
<?php
/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	get_template_part('front');
} else {
get_template_part('post');
}
?>
</div>

</div>

<?php get_template_part('rbar'); ?>
<?php get_footer(); ?>