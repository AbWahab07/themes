<?php
/*
Template Name: blog template
*/
?>
<?php get_header(); ?>
<div id="content">
<div class="ren"></div>
<div class="hen"><h2>Blog</h2></div>

<div class="sl"></div>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="slate">

<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a> </h2>

<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

<div class="ctitle"><?php _e('by', 'Detox') ?> <?php the_author() ?> | <?php _e('on', 'Detox') ?> <?php the_time('M'); ?> <?php the_time('j'); ?></div>
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<div class="read"><a title="<?php _e('Read more here', 'Detox') ?>" href="<?php the_permalink() ?>"><?php _e('Read on', 'Detox') ?> </a></div>
</div>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>

<?php endif; ?>

</div>
</div>
<nav class="nav-slide">
<?php next_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>Older<span> Entries</span></h3></div>', 0); ?>
<?php previous_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>Newer<span> Entries</span></h3></div></a>', 0) ?>
</nav>

<?php get_footer(); ?>