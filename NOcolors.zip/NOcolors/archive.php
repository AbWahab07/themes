<?php get_header(); ?>
<div id="content">
<div class="ren"></div>
<div class="hen"><h2>Archives</h2></div>
<div class="ren"></div>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="contentdiv"> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="h-f" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"><a href="<?php the_permalink() ?>"></a></div>
<div class="cis">
<div class="h-t">
<div class="ctitle"><?php the_category(' <span>, </span> '); ?></div>
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
</div>
<span class="hdate"><?php the_time('M'); ?><span class="hbigdate"><?php the_time('j'); ?></span></span>
<a href="<?php the_permalink() ?>"></a>
</div> 

</div>  
<div class="ren"></div><div class="ren"></div>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>

<?php endif; ?>

</div>
</div>
<nav class="nav-slide">
<?php next_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>Older<span> Entries</span></h3></div>', 0); ?>
<?php previous_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>Newer<span> Entries</span></h3></div></a>', 0) ?>
</nav>
<?php get_footer(); ?>