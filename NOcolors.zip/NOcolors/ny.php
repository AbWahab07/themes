<div class="ren"></div>  	
<div class="hen"><h2>NO colors</h2></div>

<div id="stfeatured"> 		

<div class="tl">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column1') ) : ?>
<h1>NOcolors Theme</h1>
<div class="ssread"><a class="a-btn" href="https://3oneseven.com/nocolors-wp-theme/">Download</a></div>
<div class="ssread"><a class="a-btn" href="https://wp.3oneseven.com/?wptheme=NOcolors">Demo</a></div>
<?php endif; ?>
</div>
<div class="tr">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column2') ) : ?>
<a href="https://3oneseven.com/nocolors-wp-theme/"><img src="<?php echo get_template_directory_uri(); ?>/images/NOcolors.png" alt="NOcolors wordpress theme" /></a></div>
<?php endif; ?>
</div>
<div class="ren"></div>
<div class="ren"></div>  	