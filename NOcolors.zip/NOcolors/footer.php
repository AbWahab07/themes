<div class="wrap">
<?php get_template_part('slide'); ?>
<?php get_template_part('nyer'); ?>
</div>
<div id="footer">

<div class="finner">

<div class="col4">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column1') ) : ?>

<h3><?php _e( 'Topi', 'Detox') ?><span><?php _e( 'cs', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_list_categories('orderby=name&show_count=0&title_li=&number=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>

<div class="col5">

<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column2') ) : ?>

<h3><?php _e( 'Page', 'Detox') ?><span><?php _e( 's', 'Detox') ?></span></h3>
<ul>
  <?php wp_list_pages('sort_column=menu_order&title_li=&number=8'); ?>
</ul>

<?php endif; ?>

</div>

<div class="col6">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column3') ) : ?>

<h3><?php _e( 'Pop', 'Detox') ?><span><?php _e( 'ular', 'Detox') ?></span></h3>

<ul id="popular-comments">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>

<li>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> <small>&#38; <?php comments_popup_link('No Comments;', '1 Comment', '% Comments'); ?></small>
</li>

<?php endwhile; ?>
</ul>


<?php endif; ?>
</div>

<div class="col7">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column4') ) : ?>

<h3><?php _e( 'Archi', 'Detox') ?><span><?php _e( 'ves', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_get_archives('type=monthly&show_post_count=0&limit=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>

</div>
</div>

<div class="clearfix"></div>

<div class="credits">
<div class="finner">

<div class="navbarf">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'footernav',
'container' => 'moo',
'container_id' => 'moo',
'menu_id' => 'moo',
'fallback_cb' => 'footernav_fallback',
));
} else {
?>
<?php
}
?>
</div>

<div class="fix">
<h1><?php bloginfo('name'); ?></h1>
</div>

<div class="creditsl">
<?php _e( 'Copyright', 'Detox') ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?><br />
<a title="Design by milo" href="https://3oneseven.com/">Design by milo</a> 
<br /><div id="gnavigation" style="font-size:10px"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/nocolors-wp-theme/" >Theme</a> <span>NOcolors theme</span>
</span>
</span>
</span>
</div>
</div>

<div class="creditsr">
<p><?php _e( 'Get updates', 'Detox') ?> <br /><?php _e( 'via', 'Detox') ?> <a href="<?php bloginfo('rss2_url'); ?>" class="rss"><?php _e( 'Email', 'Detox') ?></a></p>
</div>

</div>
</div>
</div>

<?php wp_footer(); ?>

<div class="overlays overlay-contentscale">
<button type="button" class="overlay-close"><?php _e('Close', 'Detox'); ?></button>
<h1><a title="<?php _e( 'Home is where the heart is', 'Detox') ?>" href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1>
<div class="navi">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'mnav',
'container' => '',
'container_id' => 'top',
'menu_id' => 'navx',
'fallback_cb' => 'mnav_fallback',
));
} else {
?>
<?php
}
?>
</div>
</div>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/classie.js"></script> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/demo7.js"></script> 

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
<script type="text/javascript">$(document).ready(function(){var a=function(){return $(document).height()-$(window).height()},b=function(){return $(window).scrollTop()};if("max"in document.createElement("progress")){var c=$("progress");c.attr({max:a()}),$(document).on("scroll",function(){c.attr({value:b()})}),$(window).resize(function(){c.attr({max:a(),value:b()})})}else{var e,f,c=$(".progress-bar"),d=a(),g=function(){return e=b(),f=e/d*100,f+="%"},h=function(){c.css({width:g()})};$(document).on("scroll",h),$(window).on("resize",function(){d=a(),h()})}}),$(document).ready(function(){$("#flat").addClass("active"),$("#progressBar").addClass("flat"),$("#flat").on("click",function(){$("#progressBar").removeClass().addClass("flat"),$(this).preventDefault()}),$("#single").on("click",function(){$("#progressBar").removeClass().addClass("single"),$(this).preventDefault()}),$("#multiple").on("click",function(){$("#progressBar").removeClass().addClass("multiple"),$(this).preventDefault()}),$("#semantic").on("click",function(){$("#progressBar").removeClass().addClass("semantic"),$(this).preventDefault(),alert("hello")}),$(document).on("scroll",function(){maxAttr=$("#progressBar").attr("max"),valueAttr=$("#progressBar").attr("value"),percentage=valueAttr/maxAttr*100,percentage<49?(document.styleSheets[0].addRule(".semantic","color: blue"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: blue"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: blue")):percentage<98?(document.styleSheets[0].addRule(".semantic","color: blue"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: blue"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: blue")):(document.styleSheets[0].addRule(".semantic","color: blue"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: blue"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: blue"))})});</script>
<script type="text/javascript">
var scrolltotop={setting:{startline:100,scrollto:0,scrollduration:1e3,fadeduration:[500,100]},controlHTML:'<img src="<?php echo get_template_directory_uri(); ?>/images/nav.jpg" style="filter:alpha(opacity=70); -moz-opacity:0.7;" width="72" height="72" />',controlattrs:{offsetx:0,offsety:40},anchorkeyword:"#top",state:{isvisible:!1,shouldvisible:!1},scrollup:function(){this.cssfixedsupport||this.$control.css({opacity:0});var a=isNaN(this.setting.scrollto)?this.setting.scrollto:parseInt(this.setting.scrollto);a="string"==typeof a&&1==jQuery("#"+a).length?jQuery("#"+a).offset().top:0,this.$body.animate({scrollTop:a},this.setting.scrollduration)},keepfixed:function(){var a=jQuery(window),b=a.scrollLeft()+a.width()-this.$control.width()-this.controlattrs.offsetx,c=a.scrollTop()+a.height()-this.$control.height()-this.controlattrs.offsety;this.$control.css({left:b+"px",top:c+"px"})},togglecontrol:function(){var a=jQuery(window).scrollTop();this.cssfixedsupport||this.keepfixed(),this.state.shouldvisible=a>=this.setting.startline?!0:!1,this.state.shouldvisible&&!this.state.isvisible?(this.$control.stop().animate({opacity:1},this.setting.fadeduration[0]),this.state.isvisible=!0):0==this.state.shouldvisible&&this.state.isvisible&&(this.$control.stop().animate({opacity:0},this.setting.fadeduration[1]),this.state.isvisible=!1)},init:function(){jQuery(document).ready(function(a){var b=scrolltotop,c=document.all;b.cssfixedsupport=!c||c&&"CSS1Compat"==document.compatMode&&window.XMLHttpRequest,b.$body=a(window.opera?"CSS1Compat"==document.compatMode?"html":"body":"html,body"),b.$control=a('<div id="topcontrol">'+b.controlHTML+"</div>").css({position:b.cssfixedsupport?"fixed":"absolute",bottom:b.controlattrs.offsety,right:b.controlattrs.offsetx,opacity:0,cursor:"pointer"}).attr({title:"back to top"}).click(function(){return b.scrollup(),!1}).appendTo("body"),document.all&&!window.XMLHttpRequest&&""!=b.$control.text()&&b.$control.css({width:b.$control.width()}),b.togglecontrol(),a('a[href="'+b.anchorkeyword+'"]').click(function(){return b.scrollup(),!1}),a(window).bind("scroll resize",function(){b.togglecontrol()})})}};scrolltotop.init();
</script>
<script src="<?php echo get_template_directory_uri(); ?>/js/instant.js" type="text/javascript"></script>
<noscript><a href="https://statcounter.com/shopify/" target="_blank"><img class="statcounter" src="https://c.statcounter.com/1709362/0/a95d8c44/1/" alt="analytics"></a></noscript>
<div class="svg-wrap">
			<svg width="64" height="64" viewBox="0 0 64 64">
				<path id="arrow-left-1" d="M46.077 55.738c0.858 0.867 0.858 2.266 0 3.133s-2.243 0.867-3.101 0l-25.056-25.302c-0.858-0.867-0.858-2.269 0-3.133l25.056-25.306c0.858-0.867 2.243-0.867 3.101 0s0.858 2.266 0 3.133l-22.848 23.738 22.848 23.738z" />
			</svg>
			<svg width="64" height="64" viewBox="0 0 64 64">
				<path id="arrow-right-1" d="M17.919 55.738c-0.858 0.867-0.858 2.266 0 3.133s2.243 0.867 3.101 0l25.056-25.302c0.858-0.867 0.858-2.269 0-3.133l-25.056-25.306c-0.858-0.867-2.243-0.867-3.101 0s-0.858 2.266 0 3.133l22.848 23.738-22.848 23.738z" />
			</svg>
		</div>
    
 
</body>
</html>