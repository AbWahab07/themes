<?php get_template_part('header'); ?>

<div id="content" class="animated fadeInLeftBig"> 	
<div id="middle">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div id="teaser">
<div class="entry">
<div class="msentry"><b><?php the_category(' <span>, </span> '); ?></b>  <?php the_content_rss('', FALSE, ' ', 22); ?></div>
</div>
<h1><?php the_title() ?></h1>
</div> 

<div class="ren"></div><div class="ren"></div>
<div class="animated fadeInLeftBig">
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
 	
<div class="entry">
<div class="sentry"><?php the_content(__('Read more', 'Detox'));?></div>
</div>
</div>

<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div class="navigation">&after=</div>'); ?>

<div class="clearfix"></div><hr class="clear" />

<div class="ren"></div>	
<div class="hen"><h2><?php printf( esc_attr__( 'About %s', 'Bruce' ), get_the_author() ); ?></h2></div>

<div class="rel">
<?php if ( get_the_author_meta( 'description' ) ) :  ?>
<div class="author-avatar alignright">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 90 ) ); ?>
</div>

<div id="author-description">
<?php the_author_meta( 'description' ); ?> | <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'View all posts by %s <span class="meta-nav">&rarr;</span>', 'Bruce' ), get_the_author() ); ?><?php edit_post_link(' | Edit','',''); ?></a>
</div>
<?php endif; ?>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>

<div id="navigation">
<p><?php _e('You are here', 'Detox') ?>: <a href="<?php home_url(); ?>/">Home</a> >> <?php the_category(' <span>>> </span> '); ?> >> <?php the_title(); ?></p>
</div>

<div class="ren"></div>	
<div class="hen"><h2>Related</h2></div>
</div> 

<div id="tfeatured"> 		
<div id="slider2" class="sliderwrapper">

<?php
  $orig_post = $post;
  global $post;
  $tags = wp_get_post_tags($post->ID);   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>1, // Number of related posts to display.
  'caller_get_posts'=>1
  );   
  $my_query = new wp_query( $args ); 
  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>

<div class="contentdiv"> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="h-f" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"><a href="<?php the_permalink() ?>"></a></div>
<div class="cis">
<div class="h-t">
<div class="ctitle"><?php the_category(' <span>, </span> '); ?></div>
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
</div>
<span class="hdate"><?php the_time('M'); ?><span class="hbigdate"><?php the_time('j'); ?></span></span>
<a href="<?php the_permalink() ?>"></a>
</div> 

</div> 
 
</div>
 <? }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>

</div>


<div class="postspace"></div>
<?php
              // If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                comments_template();
            ?>	

</div>
</div>
</div>
<nav class="nav-slide">
<?php 
$prev_post = get_adjacent_post(false, '', true);
if(!empty($prev_post)) {
echo '<a class="prev" href="' . get_permalink($prev_post->ID) . '"><span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>' . $prev_post->post_title . ' <span> Previously</span></h3></div></a>'; }
 ?>
<?php
$next_post = get_adjacent_post(false, '', false);
if(!empty($next_post)) {
echo '<a class="next" href="' . get_permalink($next_post->ID) . '">	<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>' . $next_post->post_title . ' <span>Next</span></h3></div></a>'; }
?>
</nav>
<div class="wrap">
<?php get_template_part('ny'); ?>
</div>

<?php get_footer(); ?>