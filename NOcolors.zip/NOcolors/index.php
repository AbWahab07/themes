<?php get_header(); ?>

<?php get_template_part('feature'); ?>

<div class="ren"></div>

<?php get_template_part('middle'); ?>

<div class="ren"></div><div class="ren"></div>
<div class="hen"><h2>Most Read</h2></div>
<?php get_template_part('hmain'); ?>
<?php get_template_part('tfeature'); ?>

<div class="ren"></div><div class="ren"></div>
<div class="col4">
<?php 
	$my_query = new WP_Query('showposts=1&offset=4');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

<p><b><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></b> <?php the_content_rss('', FALSE, ' ', 12); ?></p>
</div>
<div class="florida"><?php the_category(', ') ?></div>
<?php endwhile; ?>
</div>

<div class="col5">
<?php 
	$my_query = new WP_Query('showposts=1&offset=5');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

<p><b><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></b> <?php the_content_rss('', FALSE, ' ', 12); ?></p>
</div>
<div class="florida"><?php the_category(', ') ?></div>
<?php endwhile; ?>
</div>

<div class="col6">
<?php 
	$my_query = new WP_Query('showposts=1&offset=6');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

<p><b><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></b> <?php the_content_rss('', FALSE, ' ', 12); ?></p>
</div>
<div class="florida"><?php the_category(', ') ?></div>
<?php endwhile; ?>
</div>

<div class="col7">
<?php 
	$my_query = new WP_Query('showposts=1&offset=7');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="entry">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>

<p><b><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></b> <?php the_content_rss('', FALSE, ' ', 12); ?></p>
</div>
<div class="florida"><?php the_category(', ') ?></div>
<?php endwhile; ?>
</div>

<div class="ren"></div><div class="ren"></div>
<div class="hen"><h2>Brandnew</h2></div>
<div class="ren"></div><div class="ren"></div>

<div class="down">
<div class="col4">
<?php 
	$my_query = new WP_Query('showposts=1&offset=7');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_time('j'); ?>. <?php the_time('M'); ?> <?php the_time('Y'); ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">
<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">
<span class="article-progress-bar" style="width:90%"></span><span class="article-progress-bar" style="width:80%"></span><span class="article-progress-bar" style="width:70%"></span>
</div>
<?php endwhile; ?>
</div>

<div class="col5">
<?php 
	$my_query = new WP_Query('showposts=1&offset=8');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_time('j'); ?>. <?php the_time('M'); ?> <?php the_time('Y'); ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">
<span class="article-progress-bar" style="width:90%"></span><span class="article-progress-bar" style="width:80%"></span><span class="article-progress-bar" style="width:70%"></span>
</div>
<?php endwhile; ?>
</div>

<div class="col6">
<?php 
	$my_query = new WP_Query('showposts=1&offset=9');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_time('j'); ?>. <?php the_time('M'); ?> <?php the_time('Y'); ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">
<span class="article-progress-bar" style="width:90%"></span><span class="article-progress-bar" style="width:80%"></span><span class="article-progress-bar" style="width:70%"></span>
</div>
<?php endwhile; ?>
</div>

<div class="col7">
<?php 
	$my_query = new WP_Query('showposts=1&offset=10');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_time('j'); ?>. <?php the_time('M'); ?> <?php the_time('Y'); ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">
<span class="article-progress-bar" style="width:90%"></span><span class="article-progress-bar" style="width:80%"></span><span class="article-progress-bar" style="width:70%"></span>
</div>
<?php endwhile; ?>
</div>
</div>

<div class="ren"></div>
<?php get_template_part('ny'); ?>
<?php get_template_part('tmiddle'); ?>
<?php get_template_part('tslide'); ?>
<?php get_template_part('posts'); ?>
</div>
<?php get_footer(); ?>