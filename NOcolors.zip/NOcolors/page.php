<?php get_template_part('header'); ?>

<div class="wrap animated fadeInLeftBig">
<div id="content">
<div id="middle">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div id="teaser">
<div class="entry">
<div class="msentry"><b><?php printf( esc_attr__( 'By %s', 'Bruce' ), get_the_author() ); ?> </b>  <?php the_content_rss('', FALSE, ' ', 12); ?></div>
</div>
<h1><?php the_title() ?></h1>
</div> 

<div class="ren"></div><div class="ren"></div>
	
<div class="entry">
<div class="sentry"><?php the_content(__('Read more', 'Detox'));?></div>
</div>


<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>
<div class="clearfix"></div>
<div id="navigation">
<p><?php _e('You are here', 'Detox') ?>: <a href="<?php home_url(); ?>/">Home</a> >> <?php the_title(); ?></p>
</div>
<div class="sl"></div>
<div class="postspace"></div>
</div>
</div>

<?php get_template_part('ny'); ?>

</div>
<?php get_footer(); ?>