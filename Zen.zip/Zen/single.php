<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<section class="ae-container-fluid ae-container-fluid--full animated fadeInDown">
   <?php if(has_post_thumbnail()) :?>
            <header class="rk-portfolio-cover post-inside-1"  style="background-image:url(<?php if (function_exists('vp_get_thumb_url')) {  $thumb=vp_get_thumb_url($post->post_content, 'zcover');}?><?php if ($thumb!='') echo $thumb; ?>)">
           <div class="crong"></div>

              <?php else :?>
<header class="rk-portfolio-cover post-inside-1"  style="background-image:url(<?php echo get_template_directory_uri(); ?>/assets/img/img.jpg)">
 <div class="crong"></div>

<?php endif;?>
        <div class="item-inside__meta">
          <h1 class="ae-u-bolder rk-portfolio-title "><?php the_title(); ?></h1>
          <p class="ae-theta rk-portfolio-category "><span class="ae-u-bolder"><?php _e('By', 'Detox')?> <?php the_author_posts_link(); ?></span></p>
        </div>
</header>

</section>

<section class="ae-container-fluid ae-container-fluid--inner rk-blog animated fadeInDown">
<div class="rk-blog__items">
<div class="rk-blog__item">

<div class="blog-info">

<div class="blog-info__excerpt">
<div class="ss"><?php the_content(__('Read more', 'Detox'));?></div>
<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
<h3><?php edit_post_link('Edit','',''); ?></h3>
     
<div class="blog-meta">
<div class="ae-u-bolder blog-meta__comments"><?php comments_popup_link(__('No Comment', 'Detox'), __('1 Comment', 'Detox'), __('% Comments', 'Detox'), '', __('Closed', 'Detox')); ?></div>
<span class="ae-kappa ae-u-bold blog-meta__date"><?php the_time('M', 'Detox'); ?><?php the_time('j', 'Detox'); ?></span>
</div>

<div class="ae-grid ae-grid--collapse">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('pagebar') ) : ?>
          
<?php if ( get_the_author_meta( 'description' ) ) :  ?>
<div class="rk-comment__avatar" style="float:left;margin:10px 10px 10px 0;display:inline-block;">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 90 ) ); ?>
</div>

<div id="author-description" style="float:left;margin:10px 10px 10px 0;display:inline-block;">
<h4><?php printf( esc_attr__( 'About %s', 'Bruce' ), get_the_author() ); ?> :</h4>
<?php the_author_meta( 'description' ); ?> | <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'View all posts by %s <span class="meta-nav">&rarr;</span>', 'Bruce' ), get_the_author() ); ?><?php edit_post_link(' | Edit','',''); ?></a>
</div>
<?php endif; ?>

<?php endif; ?>
</div>

</div>
</div>
</div>
</div>
</section>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p>
<?php endif; ?> 

<?php
  $orig_post = $post;
  global $post;
  $tags = wp_get_post_tags($post->ID);   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'orderby' => 'rand',
  'post__not_in' => array($post->ID),
  'posts_per_page'=>1, // Number of related posts to display.
  'caller_get_posts'=>1
  );   
  $my_query = new wp_query( $args ); 
  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>
  
<section class="ae-container-fluid ae-container-fluid--full animated fadeInDown">
   <?php if(has_post_thumbnail()) :?>
            <header class="rk-portfolio-cover post-inside-1"  style="background-image:url(<?php if (function_exists('vp_get_thumb_url')) {  $thumb=vp_get_thumb_url($post->post_content, 'zcover');}?><?php if ($thumb!='') echo $thumb; ?>)">
           <div class="crong"></div>

              <?php else :?>
<header class="rk-portfolio-cover post-inside-1"  style="background-image:url(<?php echo get_template_directory_uri(); ?>/assets/img/img.jpg)">
 <div class="crong"></div>

<?php endif;?>
        <div class="item-inside__meta">
                                 <p class="ae-theta rk-portfolio-category "><span class="ae-u-bolder">Related</span></p>
          <h1 class="ae-u-bolder rk-portfolio-title "><?php the_title(); ?></h1>
          
        </div>
</header>

</section>
  <? }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>


   
<section class="ae-container-fluid ae-container-fluid--inner rk-blog animated fadeInDown">
<div class="rk-blog__items">
<div class="rk-blog__item">

<div class="blog-info">

<div class="blog-info__excerpt">
<?php comments_template(); ?>

</div>
</div>
</div>
</div>
</section>

<nav class="nav-slide">
<?php 
$prev_post = get_adjacent_post(false, '', true);
if(!empty($prev_post)) {
echo '<a class="prev" href="' . get_permalink($prev_post->ID) . '"><span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>' . $prev_post->post_title . ' <span> Previously</span></h3></div></a>'; }
 ?>
<?php
$next_post = get_adjacent_post(false, '', false);
if(!empty($next_post)) {
echo '<a class="next" href="' . get_permalink($next_post->ID) . '">	<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>' . $next_post->post_title . ' <span>Next</span></h3></div></a>'; }
?>
</nav>
<?php get_footer(); ?>