<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<section class="ae-container-fluid ae-container-fluid--inner rk-blog animated fadeInDown">
<div class="rk-blog__items">
<div class="rk-blog__item">

<div class="blog-info">
<h2 class="blog-info__title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<h5 class="blog-info__author"><div  class="ae-u-bolder"><?php _e('Community', 'Detox'); ?></div></h5>
<div class="blog-info__excerpt">
<?php the_content(__('Read more', 'Detox'));?>
    
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p>
<?php endif; ?>       

</div>
</div>
</div>
</div>
</section>
<?php get_footer(); ?>