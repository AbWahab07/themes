<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<section class="ae-container-fluid ae-container-fluid--inner rk-blog animated fadeInDown">
<div class="rk-blog__items">
<div class="rk-blog__item">

<div class="blog-info">
<h2 class="blog-info__title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<h5 class="blog-info__author"><div  class="ae-u-bolder"><?php _e('By', 'Detox')?> <?php the_author_posts_link(); ?></div></h5>
<div class="blog-info__excerpt">
<?php the_content(__('Read more', 'Detox'));?>
<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
<h3><?php edit_post_link('Edit','',''); ?></h3>
     
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox'); ?></p>
<?php endif; ?>       

</div>
</div>
</div>
</div>
</section>
<?php get_footer(); ?>