<?php get_header(); ?>

<section class="ae-container-fluid rk-main animated fadeInDown">
     <input type="radio" name="layout-ctrl" checked id="layout-grid" class="layout-ctrl-input">
      <div class="ae-container-fluid rk-layout-ctrl-cont">
        <label for="layout-base" class="rk-layout-ctrl">
          <svg>
            <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/img/symbols.svg#icon-view-full"></use>
          </svg>
        </label>
      </div>
      <input type="radio" name="layout-ctrl" id="layout-base" class="layout-ctrl-input">
      <div class="ae-container-fluid rk-layout-ctrl-cont">
        <label for="layout-grid" class="rk-layout-ctrl">
          <svg>
            <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/img/symbols.svg#icon-view-alt"></use>
          </svg>
        </label>
      </div>
      <div class="rk-layout-ctrl-mobile  layout-blog">
        <svg viewBox="0 0 9 9" class="layout-mob-1">
          <rect width="100%" height="100%" fill="currentColor"></rect>
        </svg>
        <svg viewBox="0 0 9 9" class="layout-mob-2">
          <rect width="100%" height="100%" fill="currentColor"></rect>
        </svg>
        <svg viewBox="0 0 9 9" class="layout-mob-3">
          <rect width="100%" height="100%" fill="currentColor"></rect>
        </svg>
        <svg viewBox="0 0 9 9" class="layout-mob-4">
          <rect width="100%" height="100%" fill="currentColor"></rect>
        </svg>
      </div>

    
      <section class="ae-container-fluid ae-container-fluid--inner rk-blog animated fadeInDown">
        <div class="rk-blog__items">
        
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="rk-blog__item">
            <?php if(has_post_thumbnail()) :?>
            <div class="post-img post-1 rk-landscape-alt rk-tosquare" style="background-image:url(<?php if (function_exists('vp_get_thumb_url')) {  $thumb=vp_get_thumb_url($post->post_content, 'zcover');}?><?php if ($thumb!='') echo $thumb; ?>)">
              <?php else :?>
<div class="post-img post-1 rk-landscape-alt rk-tosquare" style="background-image:url(<?php echo get_template_directory_uri(); ?>/assets/img/img.jpg)">
<?php endif;?>
              <div class="item-meta">
                <p><a href="<?php the_permalink() ?>" class="arrow-button"><?php _e('View more', 'Detox')?>
                  </a></p>
              </div>
            </div>
            <div class="blog-info">
              <h2 class="blog-info__title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
              <h5 class="blog-info__author"><div  class="ae-u-bolder"><?php _e('By', 'Detox')?> <?php the_author_posts_link(); ?></div></h5>
              <p class="blog-info__excerpt">
             <?php the_content_rss('', FALSE, ' ', 26); ?>
              </p>
            </div>
            <div class="blog-meta"><div class="ae-u-bolder blog-meta__comments"><?php comments_popup_link(__('No Comment', 'Detox'), __('1 Comment', 'Detox'), __('% Comments', 'Detox'), '', __('Closed', 'Detox')); ?></div><span class="ae-kappa ae-u-bold blog-meta__date"><?php the_time('M', 'Detox'); ?><?php the_time('j', 'Detox'); ?></span>
              <button class="arrow-button blog-meta__read-more">
              <a href="<?php the_permalink() ?>" class="arrow-button"><?php _e('View more', 'Detox')?>
               </a>
              </button>
            </div>
          </div>

<?php endwhile; else: ?>
<div class="xleft"><?php _e('Sorry, no posts matched your criteria.'); ?></div>
<?php endif; ?>

</section>
</div>
</section>

<nav class="nav-slide">
<?php next_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>Older<span> Entries</span></h3></div>', 0); ?>
<?php previous_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>Newer<span> Entries</span></h3></div></a>', 0) ?>
</nav>
<?php get_footer(); ?>