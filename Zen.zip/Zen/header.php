<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="https://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="shortcut icon" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/favicon.png" />
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/styles.css">

<?php if(is_front_page()): ?><?php elseif (is_singular()): ?>
<link rel="prefetch" href="<?php echo get_permalink(get_adjacent_post(true,'',true)); ?>">
<link rel="prerender" href="<?php echo get_permalink(get_adjacent_post(true,'',false)); ?>">
<?php else: ?>
<link rel="prefetch" href="<?php echo home_url(); ?>">
<link rel="prerender" href="<?php echo home_url(); ?>">
<?php endif; ?>



<?php wp_head(); ?>        

</head>

<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="https://schema.org/WebPage">
<progress value="0" id="progressBar"><div class="progress-container"><span class="progress-bar"></span></div></progress>

<header class="ae-container-fluid ae-container-fluid--full rk-header animated fadeIn" role="banner" itemscope="itemscope"  itemtype="https://schema.org/WPHeader">

      <input type="checkbox" id="mobile-menu" class="rk-mobile-menu">
      <label for="mobile-menu">
        <svg>
          <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/img/symbols.svg#bar"></use>
        </svg>
        <svg>
          <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/img/symbols.svg#bar"></use>
        </svg>
        <svg>
          <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/img/symbols.svg#bar"></use>
        </svg>
      </label>
      <div class="ae-container-fluid ae-container-fluid--inner rk-topbar">
        <h1 class="rk-logo"><a href="<?php bloginfo('url'); ?>/"><?php bloginfo('name'); ?></a></h1>
        <div class="rk-navigation">

<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'top-nav',
'container' => '',
'container_id' => 'top-nav',
'menu_id' => 'nav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>         

          <form id="searchform" class="rk-search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
            <input type="text" id="urku-search" class="rk-search-field" placeholder="Search" value="<?php _e('To search, type and hit enter...', 'Detox'); ?>" name="s" onfocus="if (this.value == 'To search, type and hit enter...', 'Detox') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search anything', 'Detox';}" />
            <label for="urku-search">
              <svg>
                <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/img/symbols.svg#icon-search"></use>
              </svg>
            </label>
          </form>
         
        </div>
      </div>
</header>