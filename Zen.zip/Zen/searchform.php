<form id="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e('To search, type and hit enter...', 'Detox'); ?>" name="s" id="s" onfocus="if (this.value == 'To search, type and hit enter...', 'Detox') {this.value = '';}"
 onblur="if (this.value == '') {this.value = 'Search anything', 'Detox';}" />
 </form>