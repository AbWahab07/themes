<?php get_template_part('header'); ?>
<div id="smain" class="animated slideInDown" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
<div id="post">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="wrapper">

<div class="breaks one">
<div class="post-cat"><a href=""><?php the_title(); ?></a></div> 
</div>

<div class="entry" itemprop="text">
<?php the_content(__('Read more', 'Detox'));?>
<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
<?php edit_post_link('<h3 class="alignright">Edit</h3>','',''); ?>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>

<div class="clearfix"></div><hr class="clear" />

<div id="navigation" itemprop="breadcrumb">
<?php _e('You are here', 'Detox') ?>: <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>
</div>
</div>
</div>

<?php get_template_part('footer'); ?>