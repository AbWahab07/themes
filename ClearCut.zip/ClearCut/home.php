<?php get_template_part('header'); ?>
<div class="wrapper">
<div id="smain" class="animated slideInDown">

<?php get_template_part('post'); ?>
<?php get_template_part('post2'); ?>
<?php get_template_part('post'); ?>
<?php get_template_part('post2'); ?>
<?php get_template_part('post'); ?>
<?php get_template_part('post2'); ?>
<?php get_template_part('post'); ?>
<?php get_template_part('post3'); ?>
<?php get_template_part('post'); ?>
<?php get_template_part('post3'); ?>
</div>
</div>
<?php get_footer(); ?>