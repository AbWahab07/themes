<div id="xfooter">

<div id="logo"><h1 itemprop="headline"><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1></div

<div class="wrapper">

<div class="clearfix"></div><hr class="clear" />
<div class="milo"><p><?php _e( 'Copyright', 'Detox') ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> | <a class="no-link" href="https://3oneseven.com/">Website design by milo</a>

<br /><div id="gnavigation" style="font-size:10px"> 
<span xmlns:v="http://rdf.data-vocabulary.org/#">
<span typeof="v:Breadcrumb">
<a class="sh" rel="v:url" property="v:title" href="https://3oneseven.com">Home</a> 
<span rel="v:child" typeof="v:Breadcrumb"><a rel="v:url" property="v:title"  href="https://3oneseven.com/clear-cut-typography-theme/" >Theme</a> <span>Clear Cut theme</span>
</span>
</span>
</span>
</div>
</p></div>

</div>

</div>
</div>
</div>
</div>
</main>

<a href="#cd-nav" class="cd-nav-trigger">Menu 
		<span class="cd-nav-icon"></span>

		<svg x="0px" y="0px" width="54px" height="54px" viewBox="0 0 54 54">
			<circle fill="transparent" stroke="#656e79" stroke-width="1" cx="27" cy="27" r="25" stroke-dasharray="157 157" stroke-dashoffset="157"></circle>
		</svg>
	</a>
	
	<div id="cd-nav" class="cd-nav">
		<div class="cd-navigation-wrapper">
			<div class="cd-half-block">
				<h2>Navigation</h2>

				<div class="pnav">
				<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'sec-nav',
'container' => '',
'container_id' => '',
'menu_id' => 'sec-nav',
'fallback_cb' => 'secnav_fallback',
));
} else {
?>
<?php
}
?>
				</div>
			</div><!-- .cd-half-block -->
			
			<div class="cd-half-block">
				<address>
					<ul class="cd-contact-info">
						<li><?php bloginfo('description'); ?></li>
					</ul>
				</address>
			</div> <!-- .cd-half-block -->
		</div> <!-- .cd-navigation-wrapper -->
	</div> <!-- .cd-nav -->
  

<script src="<?php echo get_template_directory_uri(); ?>/js/jquery-2.1.1.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/main.js" type="text/javascript"></script>
<script type="text/javascript">$(document).ready(function(){var a=function(){return $(document).height()-$(window).height()},b=function(){return $(window).scrollTop()};if("max"in document.createElement("progress")){var c=$("progress");c.attr({max:a()}),$(document).on("scroll",function(){c.attr({value:b()})}),$(window).resize(function(){c.attr({max:a(),value:b()})})}else{var e,f,c=$(".progress-bar"),d=a(),g=function(){return e=b(),f=e/d*100,f+="%"},h=function(){c.css({width:g()})};$(document).on("scroll",h),$(window).on("resize",function(){d=a(),h()})}}),$(document).ready(function(){$("#flat").addClass("active"),$("#progressBar").addClass("flat"),$("#flat").on("click",function(){$("#progressBar").removeClass().addClass("flat"),$(this).preventDefault()}),$("#single").on("click",function(){$("#progressBar").removeClass().addClass("single"),$(this).preventDefault()}),$("#multiple").on("click",function(){$("#progressBar").removeClass().addClass("multiple"),$(this).preventDefault()}),$("#semantic").on("click",function(){$("#progressBar").removeClass().addClass("semantic"),$(this).preventDefault(),alert("hello")}),$(document).on("scroll",function(){maxAttr=$("#progressBar").attr("max"),valueAttr=$("#progressBar").attr("value"),percentage=valueAttr/maxAttr*100,percentage<49?(document.styleSheets[0].addRule(".semantic","color: blue"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: blue"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: blue")):percentage<98?(document.styleSheets[0].addRule(".semantic","color: blue"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: blue"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: blue")):(document.styleSheets[0].addRule(".semantic","color: blue"),document.styleSheets[0].addRule(".semantic::-webkit-progress-value","background-color: blue"),document.styleSheets[0].addRule(".semantic::-moz-progress-bar","background-color: blue"))})});</script>
<script type="text/javascript">
var scrolltotop={setting:{startline:100,scrollto:0,scrollduration:1e3,fadeduration:[500,100]},controlHTML:'<img src="<?php echo get_template_directory_uri(); ?>/images/nav.jpg" style="filter:alpha(opacity=70); -moz-opacity:0.7;z-index:9999!important" width="72" height="72" />',controlattrs:{offsetx:0,offsety:40},anchorkeyword:"#top",state:{isvisible:!1,shouldvisible:!1},scrollup:function(){this.cssfixedsupport||this.$control.css({opacity:0});var a=isNaN(this.setting.scrollto)?this.setting.scrollto:parseInt(this.setting.scrollto);a="string"==typeof a&&1==jQuery("#"+a).length?jQuery("#"+a).offset().top:0,this.$body.animate({scrollTop:a},this.setting.scrollduration)},keepfixed:function(){var a=jQuery(window),b=a.scrollLeft()+a.width()-this.$control.width()-this.controlattrs.offsetx,c=a.scrollTop()+a.height()-this.$control.height()-this.controlattrs.offsety;this.$control.css({left:b+"px",top:c+"px"})},togglecontrol:function(){var a=jQuery(window).scrollTop();this.cssfixedsupport||this.keepfixed(),this.state.shouldvisible=a>=this.setting.startline?!0:!1,this.state.shouldvisible&&!this.state.isvisible?(this.$control.stop().animate({opacity:1},this.setting.fadeduration[0]),this.state.isvisible=!0):0==this.state.shouldvisible&&this.state.isvisible&&(this.$control.stop().animate({opacity:0},this.setting.fadeduration[1]),this.state.isvisible=!1)},init:function(){jQuery(document).ready(function(a){var b=scrolltotop,c=document.all;b.cssfixedsupport=!c||c&&"CSS1Compat"==document.compatMode&&window.XMLHttpRequest,b.$body=a(window.opera?"CSS1Compat"==document.compatMode?"html":"body":"html,body"),b.$control=a('<div id="topcontrol">'+b.controlHTML+"</div>").css({position:b.cssfixedsupport?"fixed":"absolute",bottom:b.controlattrs.offsety,right:b.controlattrs.offsetx,opacity:0,cursor:"pointer"}).attr({title:"back to top"}).click(function(){return b.scrollup(),!1}).appendTo("body"),document.all&&!window.XMLHttpRequest&&""!=b.$control.text()&&b.$control.css({width:b.$control.width()}),b.togglecontrol(),a('a[href="'+b.anchorkeyword+'"]').click(function(){return b.scrollup(),!1}),a(window).bind("scroll resize",function(){b.togglecontrol()})})}};scrolltotop.init();
</script>
<script src="<?php echo get_template_directory_uri(); ?>/js/instant.js" type="text/javascript"></script>


</body>
</html>