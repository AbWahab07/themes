<?php $loop = new WP_Query( array( 'post_type' => 'product', 'posts_per_page' => 6 ) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>
<div class="breaks">
<div class="col">
<div class="hc5 view view-first" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
<div class="hp">
<a href="<?php the_permalink() ?>">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div itemscope itemtype='http://schema.org/ImageObject'><img itemprop="image" property="contentURL" src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></div>
</div>

<div class="mask">
<h3><a href="<?php the_permalink() ?>"><?php echo get_the_title(); ?></a></h3>
<a itemprop="url" href="<?php the_permalink() ?>" class="sinfo"><?php _e('View item', 'Detox') ?></a>
<div class="xminfo"><a href="<?php the_permalink() ?>"><?php _e('View item', 'Detox') ?></a></div>
</div>

</div>
</div>

<div class="col2">

<div class="entryH">
<?php echo apply_filters( 'woocommerce_short_description', $post->post_excerpt ) ?>
</div>

</div>

<div class="col3">
<div class="post-date">
<div class="post-day"><?php the_time('d') ?></div>
<div class="post-month"><?php the_time('M') ?></div> 

<div class="post-cat"><?php echo $product->get_categories( ', ', '<span class="posted_in">' . _n( '', '', sizeof( get_the_terms( $post->ID, 'product_cat' ) ), 'woocommerce' ) . ' ', '.</span>' ); ?></div> 
<h2><a href="<?php the_permalink() ?>"><?php echo get_the_title(); ?></a></h2>

<div class="post-cc"><?php echo $product->get_price_html(); ?></div>
<?php edit_post_link('<span class="post-month">[ Edit ]</span>','',''); ?>
</div>
</div>
<div class="more"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php _e('View item', 'Detox') ?></a></div>
</div>
<?php endwhile; wp_reset_query(); ?>