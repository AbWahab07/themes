<div class="breaks two">
<div class="post-cat"><?php the_category(' > ') ?></div> 
<?php $my_query = new WP_Query('showposts=1&offset=0&orderby=rand'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="col">
<div class="hp">
<a href="<?php the_permalink() ?>">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div itemscope itemtype='http://schema.org/ImageObject'><img itemprop="image" property="contentURL" src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></div>
</div>

<div class="set">
<div class="post-ccc"><?php the_category(' <span>, </span> '); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="post-cccc"><?php _e( 'by', 'Detox') ?> <?php the_author_posts_link(); ?> </div>
</div>
</div>
<?php endwhile; ?>


<?php $my_query = new WP_Query('showposts=1&offset=0&orderby=rand'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<div class="col2">
<div class="hp">
<a href="<?php the_permalink() ?>">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div itemscope itemtype='http://schema.org/ImageObject'><img itemprop="image" property="contentURL" src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></div>
</div>

<div class="set">
<div class="post-ccc"><?php the_category(' <span>, </span> '); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="post-cccc"><?php _e( 'by', 'Detox') ?> <?php the_author_posts_link(); ?> </div>
</div>
</div>
<?php endwhile; ?>

<?php $my_query = new WP_Query('showposts=1&offset=0&orderby=rand'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<div class="col3">
<div class="hp">
<a href="<?php the_permalink() ?>">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div itemscope itemtype='http://schema.org/ImageObject'><img itemprop="image" property="contentURL" src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></div>
</div>

<div class="set">
<div class="post-ccc"><?php the_category(' <span>, </span> '); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="post-cccc"><?php _e( 'by', 'Detox') ?> <?php the_author_posts_link(); ?> </div>
</div>
</div>
<?php endwhile; ?>




</div>