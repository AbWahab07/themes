<div class="bpbreak">

<div class="c1">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('buddybar-left') ) : ?> 
            
<h3>Widgetized Sidebar</h3>

<?php endif; ?>
</div>

<div class="c11">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('buddybar-right') ) : ?> 
            
<h3>Widgetized Sidebar</h3>

<?php endif; ?>
</div>

</div>