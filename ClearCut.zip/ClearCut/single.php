<?php get_template_part('header'); ?>

<div id="smain">
<div id="post" class="animated slideInDown">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="entry">
<div class="wrapper">

<div class="breaks one">
<div class="post-cat"><?php the_category(' > ') ?></div> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="col" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="hc5 view view-first" >
<div class="hp">
<a href="<?php the_permalink() ?>">

</div>


</div>
</div>

<div class="col3">

<div class="post-ccc"><?php the_category(' <span>, </span> '); ?></div>
<h1><?php the_title(); ?></h1>
<div class="post-ccc"><?php _e( 'by', 'Detox') ?> <?php the_author_posts_link(); ?> <?php comments_popup_link('0 Comments', '1 Comment', '% Comments'); ?> <a href="#comments"><?php _e('Add your reply?', 'Detox'); ?></a></div>

<?php edit_post_link('<span class="post-month">[ Edit ]</span>','',''); ?>

</div>
</div>

<div class="wrapper">
<?php the_content(__('Read more', 'Detox'));?>
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
<?php edit_post_link('<h3 class="alignright">Edit</h3>','',''); ?>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>

<div class="meta animated slideInRight">

<div class="breaks two">
<div class="post-cat"><a href="">Related</a></div>
<div class="rel">
<?php $orig_post = $post;
global $post;
$categories = get_the_category($post->ID);
if ($categories) {
$category_ids = array();
foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
$args=array(
'category__in' => $category_ids,
'post__not_in' => array($post->ID),
'posts_per_page'=> 3, // Number of related posts that will be displayed.
'caller_get_posts'=>1,
'orderby'=>'rand' // Randomize the posts
);
$my_query = new wp_query( $args );
if( $my_query->have_posts() ) {
echo '<div id="related_posts">';
while( $my_query->have_posts() ) {
$my_query->the_post(); ?>
<div class="col">
<div class="hp">
<a href="<?php the_permalink() ?>">
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div itemscope itemtype='http://schema.org/ImageObject'><img itemprop="image" property="contentURL" src="<?php if ($thumb!='') echo $thumb; ?>" alt="<?php the_title(); ?>" /></div>
</div>

<div class="set">
<div class="post-ccc"><?php the_category(' <span>, </span> '); ?></div>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="post-cccc"><?php _e( 'by', 'Detox') ?> <?php the_author_posts_link(); ?> </div>
</div>
</div>
<? }
echo '</div>';
} }
$post = $orig_post;
wp_reset_query(); ?>
</div>
</div>
</div>


<div id="navigation" itemprop="breadcrumb">
<?php _e('You are here', 'Detox') ?>: <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>

<div class="spost-navigation">
<?php 
    the_post();
?>
<div class="lfloat animated slideInRight"> 
<em><?php _e( '<b><</b> Prev', 'Detox') ?></em>
<?php
        $prevPost = get_previous_post();
        $prevthumbnail = get_the_post_thumbnail($prevPost->ID);
        previous_post_link('%link',''.$prevthumbnail.'');
?>  </div>

<div class="rfloat animated slideInRight"> 
<em><?php _e( 'Next <b>></b>', 'Detox') ?></em>
<?php
        $nextPost = get_next_post();
        $nextthumbnail = get_the_post_thumbnail($nextPost->ID);
        next_post_link('%link',''.$nextthumbnail.'');
?></div>
</div>

<?php comments_template(); ?>

</div>
</div>
</div>

<?php get_template_part('footer'); ?>