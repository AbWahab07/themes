<?php $my_query = new WP_Query('showposts=1&offset=0&orderby=rand'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>

<div class="breaks one">
<div class="post-cat"><?php the_category(' > ') ?></div> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="col" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="hc5 view view-first" >
<div class="hp">
<a href="<?php the_permalink() ?>">

</div>

<div class="mask">
<h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
<a itemprop="url" href="<?php the_permalink() ?>" class="sinfo"><?php _e('View the article', 'Detox') ?></a>
<div class="xminfo"><a href="<?php the_permalink() ?>"><?php _e('View the article', 'Detox') ?></a></div>
</div>

</div>
</div>

<div class="col3">

<div class="post-ccc"><?php the_category(' <span>, </span> '); ?></div>
<h1><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>
<div class="post-ccc"><?php _e( 'by', 'Detox') ?> <?php the_author_posts_link(); ?> <?php comments_popup_link('0 Comments', '1 Comment', '% Comments'); ?> <a href="#comments"><?php _e('Add your reply?', 'Detox'); ?></a></div>

<?php edit_post_link('<span class="post-month">[ Edit ]</span>','',''); ?>

</div>
</div>
<?php endwhile; ?>