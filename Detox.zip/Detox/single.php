<?php get_template_part('header'); ?>

<div id="smain" <?php post_class(); ?>>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php if (function_exists('vp_get_thumb_url')) {  $thumb=vp_get_thumb_url($post->post_content, 'gallerie');}?>
<div class="xxf1" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="xover">
<span class="macky"><?php the_category(', ') ?></span>
<h1><?php the_title(); ?></h1>

<small><span class="sigdate">{</span>  <span class="post-comments">
<?php comments_popup_link(__('0 Reply', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?>
</span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?> \ 
<?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?> }</span></small>
</div>
</div>

<?php edit_post_link('edit', '<p>', '</p>'); ?>

<div class="entry">
<?php the_content(__('Read more', 'Detox'));?>
<div class="clearfix"></div><hr class="clear" />
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
<?php edit_post_link('<h3>Edit</h3>','',''); ?>
</div>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.', 'Detox') ?></p>
<?php endif; ?>

<div id="sharer">

<div class="s1">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('sidebar') ) : ?>
<h3><?php _e('Widgetized', 'Detox') ?></h3>
<p>Place any widget here and have fun!</p>
<?php endif; ?>
</div>

<div class="s2">
<h3><?php _e('Share it', 'Detox') ?></h3>
<a title="<?php _e('Share it', 'Detox') ?>" href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&#38;t=<?php the_title(); ?>">
<img src="<?php echo get_stylesheet_directory_uri() ?>/images/fb.jpg" alt="del" /></a>
<a title="<?php _e('Share it', 'Detox') ?>" href="http://twitter.com/home?status=Currently reading <?php the_permalink(); ?>">
<img src="<?php echo get_stylesheet_directory_uri() ?>/images/twi.jpg" alt="tech" /></a>
</div>

</div>

<div id="navigation">
<p><?php _e('You are here', 'Detox') ?>: <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?></p>
</div>


<div class="fo">
<div id="slider1" class="sliderwrapper">

<?php
  $orig_post = $post;
  global $post;
  $tags = wp_get_post_tags($post->ID);   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>1, // Number of related posts to display.
  'caller_get_posts'=>1
  );   
  $my_query = new wp_query( $args ); 
  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>

<div class="contentdiv">

<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'gallerie');
}
?>
<div class="fimg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<div class="sll">
<small><span class="sigdate">{</span>  <span class="post-comments">
<?php comments_popup_link(__('No Comment', 'Detox'), __('1 Comment', 'Detox'), __('% Comments', 'Detox'), '', __('Closed', 'Detox')); ?>
</span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?> \ 
<?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?> }</span></small>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
	
<div class="sentry">
<?php the_excerpt(); ?>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
</div>
</div>
<div class="relx"><h2>Related</h2></div>
<a href="<?php the_permalink() ?>"></a>
</div>

</div>
  <? }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>
</div>

<div id="paginate-slider1" class="pagination"></div>
<script type="text/javascript">
featuredcontentslider.init({
id: "slider1", 
contentsource: ["inline", ""], 
toc: "#increment", 
nextprev: ["", ""], 
revealtype: "mouseover", 
enablefade: [true, 0.6], 
autorotate: [true, 9500], 
onChange: function(previndex, curindex){ 
}
})
</script>

</div>
</div>


<?php get_template_part('ny'); ?>
<?php comments_template(); ?> 

</div>
</div>
</div>
</div>

<nav class="nav-slide">
<?php 
$prev_post = get_adjacent_post(false, '', true);
if(!empty($prev_post)) {
echo '<a class="prev" href="' . get_permalink($prev_post->ID) . '"><span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>' . $prev_post->post_title . ' <span> Previously</span></h3></div></a>'; }
 ?>
<?php
$next_post = get_adjacent_post(false, '', false);
if(!empty($next_post)) {
echo '<a class="next" href="' . get_permalink($next_post->ID) . '">	<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>' . $next_post->post_title . ' <span>Next</span></h3></div></a>'; }
?>
</nav>

<?php get_template_part('footer'); ?>