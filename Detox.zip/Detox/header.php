<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="https://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />	

<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="shortcut icon" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico" />

<script src="<?php echo get_template_directory_uri(); ?>/js/contentslider.js" type="text/javascript"></script> 

<?php wp_head(); ?>        

<?php if(is_front_page()): ?><?php elseif (is_singular()): ?>
<link rel="prefetch" href="<?php echo get_permalink(get_adjacent_post(false,'',true)); ?>">
<link rel="prerender" href="<?php echo get_permalink(get_adjacent_post(false,'',false)); ?>">
<?php else: ?>
<link rel="prefetch" href="<?php echo home_url(); ?>">
<link rel="prerender" href="<?php echo home_url(); ?>">
<?php endif; ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/modernizr.custom.js"></script>
</head>
<body <?php body_class(); ?> id="detox_theme_by_milo317">
<progress value="0" id="progressBar"><div class="progress-container"><span class="progress-bar"></span></div></progress>
<div class="xtow2">
<h1><a href="<?php home_url(); ?>/">De<span>tox</span></a></h1>
<div id="xnavbar" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<button id="trigger-overlay" type="button"><span style="display:none"><?php _e('Menu', 'Detox') ?></span></button>
</div>
</div>

<div id="fheader">
<div class="wrap">
<div class="mainmenu">
<div class="menu-header">

<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'top-nav',
'container' => '',
'container_id' => 'logo-inner',
'menu_id' => 'top-nav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>
</div>
</div>
</div>
</div>
<div id="wrapper" class="animated fadeInLeftBig">

<div id="main">
<div class="wrap">

<div id="header">

<div class="head">
<div id="logo"><h1><a href="<?php home_url(); ?>/"><?php bloginfo('name'); ?></a></h1></div>
<div class="des"><?php bloginfo('description'); ?></div>
</div>

<div class="clock">
<?php echo strftime("%a"); ?>,&nbsp;
<?php echo strftime("%b"); ?>&nbsp;
<?php echo strftime("%d"); ?>,&nbsp;<?php echo strftime("%y"); ?>&nbsp;&nbsp;<?php echo strftime("%T"); ?>
</div>

<div id="login">
<?php 
	global $user_identity, $user_ID;	
	if (is_user_logged_in()) { 
?>
<a id="open" class="open" href="<?php home_url(); ?>/wp-admin/index.php"><?php _e('Dashboard', 'Detox') ?></a>	
<?php 
	} else {	
?>
<a id="open" class="open" href="<?php home_url(); ?>/wp-login.php"><?php _e('Log In', 'Detox') ?></a> | <a href="<?php home_url(); ?>/wp-register.php"><?php _e('Register here', 'Detox') ?></a>
<?php } ?>
</div>

<div class="soc">
<div class="hsoc">
<form id="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="<?php _e( 'Search...', 'Detox') ?>" name="s" id="s" onfocus="if (this.value == '<?php _e( 'Search...', 'Detox') ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e( 'Search more', 'Detox') ?>';}" />
</form>
</div>
<div class="social">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'secnav',
'container' => '',
'container_id' => 'linner',
'menu_id' => 'secnav',
'fallback_cb' => 'secnav_fallback',
));
} else {
?>
<?php
}
?>
</div>
</div>

</div>