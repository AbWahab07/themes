<?php get_template_part('header'); ?>

<div id="smain">

<?php if ( (is_home())  ) { ?><?php get_template_part('front'); ?><?php } else { ?><?php } ?>
 
<div class="break">

<?php $my_query = new WP_Query('showposts=3&offset=4'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<div class="hc1">
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?></span>
 \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> 
 <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>
<div class="sentry"><?php the_excerpt(); ?></div>
</div>
<?php endwhile; ?>

<div class="hc2">
<?php $my_query = new WP_Query('showposts=1&offset=7'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?>
</span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> 
<?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>
<div class="sentry"><?php the_excerpt(); ?></div>
<?php endwhile; ?>
</div>

</div>
<?php get_template_part('fcom'); ?>
<div class="breaks">

<?php $my_query = new WP_Query('showposts=3&offset=8'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<div class="hc1">
<div class="inner">
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sbrowse');
}
?>
<div class="hp" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"><a href="<?php the_permalink() ?>">
</a></div>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?>
</span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> 
<?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>
<div class="sentry"><?php the_excerpt(); ?></div>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
</div>
</div>
<?php endwhile; ?>

<div class="hc2">

<?php $my_query = new WP_Query('showposts=1&offset=9'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sbrowse');
}
?>
<div class="hp" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"><a href="<?php the_permalink() ?>">
</a></div>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?>
</span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> 
<?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>
<div class="sentry"><?php the_excerpt(); ?></div>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
<?php endwhile; ?>
</div>
</div>

<?php get_template_part('mid'); ?>

<div class="breaks">

<div class="hc3">
<?php $my_query = new WP_Query('showposts=4&offset=11'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>

<div class="yinner">
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sbrowse');
}
?>
<div class="hps" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"></a></div>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?></span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>


<div class="sentry"><?php the_excerpt(); ?></div>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
</div>
<div class="bready"></div>
<?php endwhile; ?>
</div>

<div class="hc4">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column4') ) : ?>
            
<h3><?php _e( 'Pop', 'Detox') ?><span><?php _e( 'ular', 'Detox') ?></span></h3>

<ul id="popular-comments">
<?php
$pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat=');
?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>

<li>
<?php the_title(); ?> <small>&#38; <?php comments_popup_link('No Comments;', '1 Comment', '% Comments'); ?></small>
</li>

<?php endwhile; ?>
</ul>

<h3><?php _e( 'Archi', 'Detox') ?><span><?php _e( 'ves', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_get_archives('type=monthly&show_post_count=0&limit=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>
</div>
<?php get_template_part('ny'); ?>
<?php get_template_part('video'); ?>

<div id="xy">
<div class="break">

<div class="hc1">
<?php $my_query = new WP_Query('showposts=1&offset=15'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?></span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>
<div class="sentry"><?php the_excerpt(); ?></div>
<?php endwhile; ?>
</div>

<div class="hc1">
<?php $my_query = new WP_Query('showposts=1&offset=16'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?></span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>
<div class="sentry"><?php the_excerpt(); ?></div>
<?php endwhile; ?>
</div>

<div class="hc1">
<?php $my_query = new WP_Query('showposts=1&offset=17'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?></span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>
<?php the_excerpt(); ?>
<?php endwhile; ?>
</div>

<div class="hc2">
<?php $my_query = new WP_Query('showposts=1&offset=18'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<small><span class="sigdate">{</span><span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?></span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="sigdate">}</span></small>
<div class="sentry"><?php the_excerpt(); ?></div>
<?php endwhile; ?>
</div>

</div>
</div>

<?php get_template_part('ecom'); ?>
<?php get_template_part('ff'); ?>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>