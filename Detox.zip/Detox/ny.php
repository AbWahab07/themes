<div class="ren"></div>  	

<div id="xyz"> 		

<div class="tl">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column1') ) : ?>
<h1>Detox Magazine Theme</h1>
<div class="ssread"><a class="a-btn" href="https://3oneseven.com/detox-magazine-theme/">Download</a></div>
<div class="ssread"><a class="a-btn" href="https://wp.3oneseven.com/?wptheme=Detox">Demo</a></div>
<?php endif; ?>
</div>
<div class="tr">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column2') ) : ?>
<a href="https://3oneseven.com/detox-magazine-theme/"><img src="<?php echo get_template_directory_uri(); ?>/images/detox.png" alt="detox template" /></a></div>
<?php endif; ?>
</div>