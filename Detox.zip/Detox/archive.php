<?php get_header(); ?>

<div id="smain">

<?php if (have_posts()) : ?>

<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
<?php /* If this is a category archive */ if (is_category()) { ?>
<h1 class="entry-title"><?php echo single_cat_title(); ?></h1>
<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
<h1 class="entry-title"><?php the_time('F jS, Y'); ?> Archive</h1>
<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
<h1 class="entry-title"><?php the_time('F, Y'); ?> Archive</h1>
<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
<h1 class="entry-title"><?php the_time('Y'); ?> Archive</h1>
<?php /* If this is an author archive */ } elseif (is_author()) { ?>
<h1 class="entry-title"><?php _e('Author Archive', 'Detox') ?></h1>
<?php /* If this is an author archive */ } elseif (is_tag()) { ?>
<h1 class="entry-title"><?php single_tag_title('Tag Archive for ', 'Detox') ?></h1>
<?php } ?>

<div class="breaks">
<?php while (have_posts()) : the_post(); ?>

<div class="xhc1">
<div class="yinner">
<span class="macky"><?php the_category(', ') ?></span><div class="t2"><?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?></span></div>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sbrowse');
}
?>
<div class="hp" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"><a href="<?php the_permalink() ?>">
</a></div>
<small><span class="sigdate">{</span>  <span class="post-comments"><?php comments_popup_link(__('0 Replies', 'Detox'), __('1 Reply', 'Detox'), __('% Replies', 'Detox'), '', __('Closed', 'Detox')); ?></span>
 \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> 
 <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?><span class="bigdate">}</span></small>
<div class="sentry"><?php the_excerpt(); ?></div>
<div class="more"><span class="bigdate">{</span> <a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?> &#187; &#187;</a> <span class="bigdate">}</span></div>
</div>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry', 'Detox') ?></p>
<?php endif; ?>
</div>
<div class="postspace"></div>
<div class="clearfix"></div><hr class="clear" />


</div>
</div>
</div>
</div>
  
<nav class="nav-slide">
<?php next_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-left-1"></svg></span><div><h3>Older<span> Entries</span></h3></div>', 0); ?>
<?php previous_posts_link('<span class="icon-wrap"><svg class="icon" width="32" height="32" viewBox="0 0 64 64"><use xlink:href="#arrow-right-1"></svg></span><div><h3>Newer<span> Entries</span></h3></div></a>', 0) ?>
</nav>
<?php get_template_part('footer'); ?>