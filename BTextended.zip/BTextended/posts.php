<div class="down">
<div class="col4">
<?php 
	$my_query = new WP_Query('showposts=1&offset=11');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_time('j'); ?>. <?php the_time('M'); ?> <?php the_time('Y'); ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">
<span class="article-progress-bar" style="width:90%"></span><span class="article-progress-bar" style="width:80%"></span><span class="article-progress-bar" style="width:70%"></span>
</div>
<?php endwhile; ?>
</div>

<div class="col5">
<?php 
	$my_query = new WP_Query('showposts=1&offset=12');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_time('j'); ?>. <?php the_time('M'); ?> <?php the_time('Y'); ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">
<span class="article-progress-bar" style="width:90%"></span><span class="article-progress-bar" style="width:80%"></span><span class="article-progress-bar" style="width:70%"></span>
</div>
<?php endwhile; ?>
</div>

<div class="col6">
<?php 
	$my_query = new WP_Query('showposts=1&offset=13');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_time('j'); ?>. <?php the_time('M'); ?> <?php the_time('Y'); ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">
<span class="article-progress-bar" style="width:90%"></span><span class="article-progress-bar" style="width:80%"></span><span class="article-progress-bar" style="width:70%"></span>
</div>
<?php endwhile; ?>
</div>

<div class="col7">
<?php 
	$my_query = new WP_Query('showposts=1&offset=14');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>		        
<div class="orlando"><?php the_time('j'); ?>. <?php the_time('M'); ?> <?php the_time('Y'); ?></div>

<h4><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title() ?></a></h4>
<div class="entry">

<p><?php the_content_rss('', FALSE, ' ', 18); ?></p>
</div>
<div class="hc">
<span class="article-progress-bar" style="width:90%"></span><span class="article-progress-bar" style="width:80%"></span><span class="article-progress-bar" style="width:70%"></span>
</div>
<?php endwhile; ?>
</div>
</div>