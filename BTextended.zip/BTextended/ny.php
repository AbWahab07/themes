<div class="ren"></div>  	
<div class="hen"><h2>NO colors</h2></div>

<div id="stfeatured"> 		

<div class="tl">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column1') ) : ?>
<h1>BT Extended Theme</h1>
<div class="ssread"><a class="a-btn" href="https://3oneseven.com/bt-extended-wordpress-theme/">Download</a></div>
<div class="ssread"><a class="a-btn" href="https://wp.3oneseven.com/?wptheme=BTextended">Demo</a></div>
<?php endif; ?>
</div>
<div class="tr">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column2') ) : ?>
<a href="https://3oneseven.com/bt-extended-wordpress-theme/"><img src="<?php echo get_template_directory_uri(); ?>/images/BT-Extended-Wordpress-Theme.png" alt="BT Extended Theme" /></a></div>
<?php endif; ?>
</div>
<div class="ren"></div>
<div class="ren"></div>  	