<div class="ren"></div>  	
<div class="hen"><h2>Subscribe</h2></div>

<div id="stsfeatured"> 		

<div class="tl">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column3') ) : ?>
<h1>Stay up to date with the latest from <?php bloginfo('name'); ?></h1>
<?php endif; ?>
</div>
<div class="tr">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('tag-column4') ) : ?>
<div class="form-wrapper">
<div class="form-item form-type-textfield form-item-mergevars-EMAIL">
<input placeholder="Your email address" type="text" id="edit-mergevars-email" name="mergevars[EMAIL]" value="" size="25" maxlength="128" class="form-text" />
</div>
<div class="form-actions" id="edit-actions">
<input type="submit" id="edit-submit" name="op" value="Sign Up" class="form-submit" /></div>
<div class="newsletter-signup-tandc"><small>See our <a href="/">terms and conditions</a> for more information.<br>You can unsubscribe at any time and if you have any queries, please 
<a href="/contact">contact&nbsp;us</a>.</small></div>
</div>
<?php endif; ?>
</div>

</div>