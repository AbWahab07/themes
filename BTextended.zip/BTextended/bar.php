<div id="bar">	

<div class="col4">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('sidebar1') ) : ?>
          
<div id="slider1" class="sliderwrapper">

<?php 
	$my_query = new WP_Query('showposts=1&offset=0');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
                
<div class="contentdiv"> 

<div class="cis">
<h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'sth');
}
?>
<div class="hg" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)">
<a href="<?php the_permalink() ?>"></a>
</div>
</div> 
<div class="read"><a title="<?php _e( 'Read more here', 'NewYorker') ?>" href="<?php the_permalink() ?>"><?php _e( 'Read on', 'NewYorker') ?> </a></div>
</div> 
               
<?php endwhile; ?>                           
                
</div>

<?php endif; ?>
</div>


<div class="col5">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('sidebar2') ) : ?>
          	        
<h3><?php _e( 'Topi', 'NewYorker') ?><span><?php _e( 'cs', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_list_categories('orderby=name&show_count=0&title_li=&number=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>

<div class="col6">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('sidebar3') ) : ?>
          	        
<h3><?php _e( 'Pop', 'Detox') ?><span><?php _e( 'ular', 'Detox') ?></span></h3>

<ul id="popular-comments">
<?php $pc = new WP_Query('orderby=comment_count&posts_per_page=6&cat='); ?>
<?php while ($pc->have_posts()) : $pc->the_post(); ?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> <small>&#38; <?php comments_popup_link('No Comments;', '1 Comment', '% Comments'); ?></small></li>
<?php endwhile; ?>
</ul>

<?php endif; ?>
</div>

<div class="col7">

<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('sidebar4') ) : ?>
          	        
<h3><?php _e( 'Archi', 'Detox') ?><span><?php _e( 'ves', 'Detox') ?></span></h3>
<div class="cats">
<ul>
<?php wp_get_archives('type=monthly&show_post_count=0&limit=8'); ?>
</ul>
</div>

<?php endif; ?>
</div>
	       
</div>