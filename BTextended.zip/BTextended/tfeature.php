<div id="tfeatured" class="animated fadeInLeftBig"> 		
<div id="slider2" class="sliderwrapper">

<?php 
	$my_query = new WP_Query('showposts=1&offset=0&orderby=rand');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>
                
<div class="contentdiv"> 
<?php
if (function_exists('vp_get_thumb_url')) {
        $thumb=vp_get_thumb_url($post->post_content, 'bigg');
}
?>
<div class="h-f" style="background-image:url(<?php if ($thumb!='') echo $thumb; ?>)"><a href="<?php the_permalink() ?>"></a></div>
<div class="cis">
<div class="h-t">
<div class="ctitle"><?php the_category(' <span>, </span> '); ?></div>
<p><?php the_content_rss('', FALSE, ' ', 20); ?></p>
<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
</div>
<span class="hdate"><?php the_time('M'); ?><span class="hbigdate"><?php the_time('j'); ?></span></span>
<a href="<?php the_permalink() ?>"></a>
</div> 

</div> 
               
<?php endwhile; ?>                           
                

</div>

</div>