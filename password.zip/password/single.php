<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="x-left post">
<h1><?php the_title(); ?></h1>

<div class="metadata">
<div class="rel">
<?php if ( get_the_author_meta( 'description' ) ) :  ?>
<div class="author-avatar alignright">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'author_bio_avatar_size', 90 ) ); ?>
</div>

<div id="author-description">
<h4><?php printf( esc_attr__( 'About %s', 'Bruce' ), get_the_author() ); ?></h4>
<?php the_author_meta( 'description' ); ?> | <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php printf( __( 'View all posts by %s <span class="meta-nav">&rarr;</span>', 'Bruce' ), get_the_author() ); ?><?php edit_post_link(' | Edit','',''); ?></a>
</div>
<?php endif; ?>
</div>

<div class="social">
<h4>Related Posts</h4>
<?php 
$max_articles = 4; // How many articles to display 
echo '<ul class="list columns">'; 
$cnt = 0; $article_tags = get_the_tags(); 
$tags_string = ''; 
if ($article_tags) { 
foreach ($article_tags as $article_tag) { 
$tags_string .= $article_tag->slug . ','; 
} 
} 
$tag_related_posts = get_posts('exclude=' . $post->ID . '&numberposts=' . $max_articles . '&tag=' . $tags_string); 
if ($tag_related_posts) { 
foreach ($tag_related_posts as $related_post) { 
$cnt++; 
echo '<li class="child-' . $cnt . '">'; 
echo '<a href="' . get_permalink($related_post->ID) . '">'; 
echo $related_post->post_title . '</a></li>'; 
} 
} 
if ($cnt < $max_articles) { 
$article_categories = get_the_category($post->ID); 
$category_string = ''; 
foreach($article_categories as $category) { 
$category_string .= $category->cat_ID . ','; 
} 
$cat_related_posts = get_posts('exclude=' . $post->ID . '&numberposts=' . $max_articles . '&category=' . $category_string); 
if ($cat_related_posts) { 
foreach ($cat_related_posts as $related_post) { 
$cnt++; 
if ($cnt > $max_articles) break; 
echo '<li class="child-' . $cnt . '">'; 
echo '<a href="' . get_permalink($related_post->ID) . '">'; 
echo $related_post->post_title . '</a></li>'; 
} 
} 
} 
echo '</ul>'; 
?>
</div>
</div>

<div class="post-navigation clear">
                <?php
                    $prev_post = get_adjacent_post(false, '', true);
                    $next_post = get_adjacent_post(false, '', false); ?>
                    <?php if ($prev_post) : $prev_post_url = get_permalink($prev_post->ID); $prev_post_title = $prev_post->post_title; ?>
                        <a class="post-prev" href="<?php echo $prev_post_url; ?>"><em>Previous post</em><span><?php echo $prev_post_title; ?></span></a>
                    <?php endif; ?>
                    <?php if ($next_post) : $next_post_url = get_permalink($next_post->ID); $next_post_title = $next_post->post_title; ?>
                        <a class="post-next" href="<?php echo $next_post_url; ?>"><em>Next post</em><span><?php echo $next_post_title; ?></span></a>
                    <?php endif; ?>
                <div class="line"></div>
</div>
</div>

<div class="narrowcolumn">
<div class="spost" id="post-<?php the_ID(); ?>">

<div class="content-title">
<small><span class="bigdate">{</span>  <span class="post-comments">
<?php the_category(', ') ?>
</span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?> \ 
<?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?> }</span></small>
</div>


<div class="entry">
<?php the_content(__('Read more'));?>
<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
<div class="clearfix"></div><hr class="clear" />
<h3><?php edit_post_link('Edit','',''); ?></h3>
</div>

<div class="content-title">
<small><span class="bigdate">{</span> <span class="post-comments"> {<?php comments_number('0', '1', '%' );?>}</span> 
<a href="#comments"><?php _e('Add your reply?', 'Detox'); ?></a><span class="bigdate"> }</span></span></small>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>

<div class="clearfix"></div><hr class="clear" />
<?php comments_template(); ?>

</div>

</div>

<?php get_template_part('bar'); ?>
<?php get_footer(); ?>