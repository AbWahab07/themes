<?php 
add_action('admin_head', 'my_custom_logo');
function my_custom_logo() {
   echo '
      <style type="text/css">
         #header-logo { background-image: url('.get_bloginfo('template_directory').'/images/favicon.ico) !important; }
      </style>
   ';
} 
function custom_colors() {
   echo '<style type="text/css">#wphead{background:#fafafa !important;border-bottom:6px solid #4F1100;color:#4F1100;text-shadow:#fff 0 1px 1px;}#footer{background:#fafafa !important;border-top:6px solid #4F1100;color:#333;}#user_info p,#user_info p a,#wphead a{color:#4F1100 !important;}</style>';
}
add_action('admin_head', 'custom_colors');
function remove_footer_admin () {
    echo "Thank you for creating with <a href='http://3oneseven.com/'>milo</a>.";
} 
add_filter('admin_footer_text', 'remove_footer_admin'); 

add_action( 'after_setup_theme', 'regMyMenus' );
function regMyMenus() {
// This theme uses wp_nav_menu() in four locations.
register_nav_menus( array(
'top-nav' => __( 'Top-Level Navigation', 'Detox' ),
'sec-nav' => __( 'Footer Navigation', 'Detox' ),
) );
}

function topnav_fallback() {
?>

<ul id="nav">
<li class="<?php if ( is_home() or is_archive() or is_single() or is_paged() or is_search() or (function_exists('is_tag') and is_tag()) ) { ?>current_page_item<?php } else { ?>page_item<?php } ?>"><a href="<?php home_url(); ?>/"><?php _e('Frontpage', 'Detox'); ?></a></li>
<?php wp_list_pages('title_li=&depth=4'); ?>
<li class="<?php if ( is_home() or is_archive() or is_single() or is_paged() or is_search() or (function_exists('is_tag') and is_tag()) ) { ?>current_page_item<?php } else { ?>page_item<?php } ?>">
<a href="http://3oneseven.com/grunge-style-wordpress-theme/"><?php _e('Download', 'Detox'); ?></a></li>

</ul> 
<?php
}
function secnav_fallback() {
?>

<ul id="snav">
<?php wp_list_pages('title_li=&depth=1&number=6'); ?>
</ul> 
<?php
}
function admin_favicon() {
	echo '<link rel="Shortcut Icon" type="image/x-icon" href="'.get_bloginfo('stylesheet_directory').'/images/favicon.ico" />';
}
add_action('admin_head', 'admin_favicon');

add_action('login_head', 'custom_login');
function fb_login_headerurl() {
	$url = bloginfo('url');
	echo $url;
}
add_filter( 'login_headerurl', 'fb_login_headerurl' );
function fb_login_headertitle() {
	$name = get_option('blogname');
	echo $name;
}
add_filter( 'login_headertitle', 'fb_login_headertitle' );

add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );
add_image_size( 'cover', 173, 243 );
add_image_size( 'slider', 500, 350 );
add_image_size( 'teaser', 40, 40 );
add_image_size( 'browse', 155, 155 );
add_image_size( 'fthumb', 70, 70 ); 

remove_action('wp_head', 'wp_generator');

// sidebar stuff
register_sidebars( 1, 
	array( 
		'name' => 'Footer Box 1',
		'id' => 'footer-column1',
    'description' => __('The footer 1st column widget area for your txt etc.'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);

register_sidebars( 1,
	array( 
		'name' => 'Footer Box 2',
		'id' => 'footer-column2',
    'description' => __('The footer 2nd column widget area for your txt etc.'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);

register_sidebars( 1,
	array( 
		'name' => 'Footer Box 3',
		'id' => 'footer-column3',
    'description' => __('The footer 3rd column widget area for your txt etc.'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
	) 
);

function initial_cap($content){
    // Regular Expression, matches a single letter
    // * even if it's inside a link tag.
    $searchfor = '/>(<a [^>]+>)?([^<\s])/';
    // The string we're replacing the letter for
    $replacewith = '>$1<span class="drop">$2</span>';
    // Replace it, but just once (for the very first letter of the post)
    $content = preg_replace($searchfor, $replacewith, $content, 1);
    // Return the result
    return $content;
}
// Add this function to the WordPress hook
add_filter('the_excerpt', 'initial_cap');
function custom_login() { 
echo '<link rel="stylesheet" type="text/css" href="' . get_bloginfo('template_directory') . '/log/log.css" />'; 
}   
add_action('login_head', 'custom_login');

function milo_body_control() { 
global $post; 
$postclass = $post->post_name;
if (is_home()) { 
echo 'id="home" class="password_theme_by_milo317"'; 
} elseif (is_single()) { 
echo 'id="single" class="password_theme_by_milo317"';
} elseif (is_page()) { 
echo 'id="single" class="password_theme_by_milo317"';
} elseif (is_category()) { 
echo 'id="single" class="password_theme_by_milo317"';
} elseif (is_archive()) { 
echo 'id="single" class="password_theme_by_milo317"';
} elseif (is_404()) { 
echo 'id="single" class="password_theme_by_milo317"';
} elseif (is_search()) { 
echo 'id="single" class="password_theme_by_milo317"'; 
} 
} 

function Bruce_remove_recent_comments_style() {
	global $wp_widget_factory;
	remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}
add_action( 'widgets_init', 'Bruce_remove_recent_comments_style' );

function unregister_default_wp_widgets() { 
	unregister_widget('WP_Widget_Meta');
	unregister_widget('WP_Widget_Search'); 
} 
add_action('widgets_init', 'unregister_default_wp_widgets', 1);

add_filter( 'max_srcset_image_width', create_function( '', 'return 1;' ) );
add_action( 'wp_enqueue_scripts', 'child_manage_woocommerce_styles', 99 );
function child_manage_woocommerce_styles() {
	//remove generator meta tag
	remove_action( 'wp_head', array( $GLOBALS['woocommerce'], 'generator' ) );
	//first check that woo exists to prevent fatal errors
	if ( function_exists( 'is_woocommerce' ) ) {
		//dequeue scripts and styles
		if ( ! is_woocommerce() && ! is_cart() && ! is_checkout() ) {
      wp_dequeue_style( 'woocommerce-layout' );
      wp_dequeue_style( 'woocommerce-smallscreen' );
      wp_dequeue_style( 'woocommerce' );
      wp_dequeue_style( 'woocommerce-general' );
			wp_dequeue_style( 'woocommerce_frontend_styles' );
			wp_dequeue_style( 'woocommerce_fancybox_styles' );
			wp_dequeue_style( 'woocommerce_chosen_styles' );
			wp_dequeue_style( 'woocommerce_prettyPhoto_css' );
			wp_dequeue_script( 'wc_price_slider' );
			wp_dequeue_script( 'wc-single-product' );
			wp_dequeue_script( 'wc-add-to-cart' );
			wp_dequeue_script( 'wc-cart-fragments' );
			wp_dequeue_script( 'wc-checkout' );
			wp_dequeue_script( 'wc-add-to-cart-variation' );
			wp_dequeue_script( 'wc-single-product' );
			wp_dequeue_script( 'wc-cart' );
			wp_dequeue_script( 'wc-chosen' );
			wp_dequeue_script( 'woocommerce' );
			wp_dequeue_script( 'prettyPhoto' );
			wp_dequeue_script( 'prettyPhoto-init' );
			wp_dequeue_script( 'jquery-blockui' );
			wp_dequeue_script( 'jquery-placeholder' );
			wp_dequeue_script( 'fancybox' );
			wp_dequeue_script( 'jqueryui' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'child_manage_buddypress_styles', 99 );
function child_manage_buddypress_styles() {
	//first check that woo exists to prevent fatal errors
	if ( function_exists( 'is_buddypress' ) ) {
		//dequeue scripts and styles
		if ( ! is_buddypress() && ! is_buddypress() && ! !bp_is_blog_page() ) {
      wp_dequeue_style( 'bp-legacy-css' );
      wp_dequeue_style( 'bp-mentions-css' );
			wp_deregister_script( 'bp-confirm' );
			wp_deregister_script( 'bp-widget-members' );
			wp_deregister_script( 'bp-jquery-query' );
			wp_deregister_script( 'bp-jquery-cookie' );
			wp_deregister_script( 'bp-jquery-scroll-to' );
			wp_deregister_script( 'bp-buddypress' );
      wp_deregister_script( 'bp-jquery-caret' );
			wp_deregister_script( 'bp-jquery-atwho' );
			wp_deregister_script( 'bp-mentions' );
		}
	}
}
function your_theme_xprofile_cover_image( $settings = array() ) {
    $settings['default_cover'] = '/wp-content/themes/password/images/cover.jpg'; 
    return $settings;
}
add_filter( 'bp_before_groups_cover_image_settings_parse_args', 'your_theme_xprofile_cover_image', 10, 1 );
function your_xtheme_xprofile_cover_image( $settings = array() ) {
    $settings['default_cover'] = '/wp-content/themes/password/images/cover.jpg'; 
    return $settings;
}
add_filter( 'bp_before_xprofile_cover_image_settings_parse_args', 'your_xtheme_xprofile_cover_image', 10, 1 );
function commentslist($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	<li>
      <ul>
							   <li class="clearfix" data-animated="fadeInUp">
                        	<div class="pull-left avatar">
                          <?php echo get_avatar($comment, 70, get_bloginfo('template_url').'/images/1.jpg'); ?>
                   	</div>
                    <div class="comment_right">
										<div class="comment_info dclearfix">
                            <div class="pull-left comment_author"><?php printf(__('%s</p>'), get_comment_author_link()) ?></div>
                            <div class="pull-left comment_inf_sep">|</div>
											<div class="pull-left comment_date"><?php printf(__('<p class="comment-date">%s</p>'), get_comment_date('M j, Y')) ?></div>
                            <div class="pull-left comment_inf_sep">|</div>
											<div class="pull-left comment_date"><?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></div>
                        </div>
                            <?php if ($comment->comment_approved == '0') : ?>
                                <p><?php _e('Your comment is awaiting moderation.') ?></p>
                            <?php endif; ?>
                            <?php comment_text() ?>
           </div>                 
   </li>
   </ul>
   </li>
<?php
}

add_filter('get_comments_number', 'comment_count', 0);
function comment_count( $count ) {
        if ( ! is_admin() ) {
                global $id;
                $comments_by_type = &separate_comments(get_comments('status=approve&post_id=' . $id));
                return count($comments_by_type['comment']);
        } else {
                return $count;
        }
}
function myavatar_add_default_avatar( $url )
{
return get_stylesheet_directory_uri() .'/images/1.jpg';
}
add_filter( 'bp_core_mysteryman_src', 'myavatar_add_default_avatar' ); 
function my_default_get_group_avatar($avatar) {
global $bp, $groups_template;
if( strpos($avatar,'group-avatars') ) {
return $avatar;
}
else {
$custom_avatar = get_stylesheet_directory_uri() .'/images/1.jpg';
if($bp->current_action == "")
return '<img width="'.BP_AVATAR_THUMB_WIDTH.'" height="'.BP_AVATAR_THUMB_HEIGHT.'" src="'.$custom_avatar.'" class="avatar" alt="' . esc_attr( $groups_template->group->name ) . '" />';
else
return '<img width="'.BP_AVATAR_FULL_WIDTH.'" height="'.BP_AVATAR_FULL_HEIGHT.'" src="'.$custom_avatar.'" class="avatar" alt="' . esc_attr( $groups_template->group->name ) . '" />';
}
}
add_filter( 'bp_get_group_avatar', 'my_default_get_group_avatar');

?>