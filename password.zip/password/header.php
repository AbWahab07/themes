<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title>PassWord theme | Typography style responsive two column layout featuring black colorscheme & beautiful typography. | <?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:bold,normal|Alfa+Slab+One|Droid+Sans" />
<link href="<?php echo get_template_directory_uri(); ?>/animate.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/mobi.css" type="text/css" media="handheld" />
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/mobi.css" type="text/css" media="only screen and (max-width: 780px), only screen and (max-device-width: 780px)" />
<link rel="shortcut icon" type="image/ico" href="<?php bloginfo('template_url'); ?>/images/favicon.ico" />

<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />

<?php
			wp_enqueue_script('jquery');
            if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
		?>
<?php wp_head(); ?>
<!--[if lt IE 9]><script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js" type="text/javascript"></script><![endif]-->
<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>

<body <?php milo_body_control(); ?> itemscope="itemscope" itemtype="http://schema.org/WebPage">

<div id="page">
<div id="header" class="animated slideInDown">
<div class="wrap">
<h1><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a></h1>
<div class="description"><div class="head"><?php bloginfo('description'); ?></div></div>
<div id="zeit">
<p class="one"><?php echo strftime("%d"); ?></p>
<p class="two"><?php echo strftime("%y"); ?></p>
</div>
<div id="menu" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'top-nav',
'container' => '',
'container_id' => 'top-nav',
'menu_id' => 'nav',
'fallback_cb' => 'topnav_fallback',
));
} else {
?>
<?php
}
?>

</div>
</div>
</div>
<div id="wrap" class="animated fadeIn" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/WebPage">
<div class="wrap">