<div id="s_footer">

<div class="col1">

<h2><?php _e('Popular Tags'); ?></h2>
<ul class="ul-tag">
<li>
<?php if ( function_exists('wp_tag_cloud') ) : ?>
<?php wp_tag_cloud('smallest=8&largest=22&number=30&orderby=count'); ?>
<?php endif; ?>
</li></ul>

</div>

<div class="col2">

<h2><?php _e('Popular'); ?></h2>
<ul><?php get_hottopics(); ?></ul>
</div>

<div class="col3">

<h2>Updated</h2>
<ul><?php gte_recent_updated_posts(); ?></ul>

</div>

</div>


