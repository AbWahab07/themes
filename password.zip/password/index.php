<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="x-left post">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
</div>

<div class="narrowcolumn">
<div class="spost" id="post-<?php the_ID(); ?>">

<div class="content-title">
<small><span class="bigdate">{</span>  <span class="post-comments">
<?php the_category(', ') ?>
</span> \ <?php if(function_exists('the_tags')) {$my_tags = get_the_tags();if ( $my_tags != "" ){ the_tags('Tags: ', ', ', ''); } else {echo "";} }?> <?php if(function_exists('UTW_ShowTagsForCurrentPost')) { echo 'Tags: ';UTW_ShowTagsForCurrentPost("commalist");echo ''; } ?> \ 
<?php the_time('M', 'Detox'); ?><span class="bigdate"><?php the_time('j', 'Detox'); ?> }</span></small>
</div>

<div class="entry">
<?php the_excerpt(); ?>
</div>

<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
<div class="clearfix"></div><hr class="clear" />
<h3><?php edit_post_link('Edit','',''); ?></h3>

</div>
</div>
<div class="xtitle">
<div class="more"><a href="<?php the_permalink() ?>"><?php _e('Read more', 'Detox')?></a></div>
<div class="post-comments"><?php comments_number('0', '1', '%' );?></div>
<div class="xdate"><a href="<?php the_permalink() ?>#comments"><?php _e('Add your reply?', 'Detox'); ?></a></div>
</div>

<?php endwhile; else: ?>
<div class="xleft"><?php _e('Sorry, no posts matched your criteria.'); ?></div>
<?php endif; ?>

<div class="navigation">
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi('', '', '', '', 3, false);} ?>
</div>

<?php get_template_part('bar'); ?>
<?php get_footer(); ?>