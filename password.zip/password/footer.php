<div id="s_footer">

<div class="col1">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column1') ) : ?>	
		        
<h3><?php _e('Recently', 'Detox'); ?></h3>
<div class="cat">
<ul><?php wp_get_archives('type=postbypost&limit=3'); ?></ul>
</div>

<?php endif; ?>
</div>

<div class="col2">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column2') ) : ?>	
		        
<h3><?php _e('Recently', 'Detox'); ?></h3>
<div class="cat">
<ul><?php wp_get_archives('type=postbypost&limit=3'); ?></ul>
</div>

<?php endif; ?>
</div>

<div class="col3">
<?php if ( !function_exists('dynamic_sidebar')
		        || !dynamic_sidebar('footer-column3') ) : ?>	
		        
<h3><?php _e('Recently', 'Detox'); ?></h3>
<div class="cat">
<ul><?php wp_get_archives('type=postbypost&limit=3'); ?></ul>
</div>

<?php endif; ?>
</div>

</div>

<div id="footer">

<h1><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a></h1>
<div class="description"><div class="head"><?php bloginfo('description'); ?></div></div>
<div id="smenu" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
<?php
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array(
'theme_location' => 'sec-nav',
'container' => '',
'container_id' => 'sec-nav',
'menu_id' => 'snav',
'fallback_cb' => 'secnav_fallback',
));
} else {
?>
<?php
}
?>
</div>

<p>
<?php _e("Copyright"); ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> <?php _e("All Rights reserved"); ?>
<br />
<a title="Design by milo" href="http://3oneseven.com/">Design by milo</a>
</p>
</div>

<?php do_action('wp_footer'); ?>

<script type="text/javascript">
//<![CDATA[
var sc_project=10909980; 
var sc_invisible=1; 
var sc_security="71bf4d48"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter_xhtml.js'></"+"script>");
//]]>
</script>
<noscript><div class="statcounter"><a title="hits counter"
href="http://statcounter.com/free-hit-counter/"
class="statcounter"><img class="statcounter"
src="http://c.statcounter.com/10909980/0/71bf4d48/1/"
alt="hits counter" /></a></div></noscript>

</body>
</html>