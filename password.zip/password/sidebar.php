<div id="sidebar">
<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('sidebar') ) : ?>

<h3>Search</h3>
<form id="searchform" method="get" action="<?php bloginfo('home'); ?>/"><input type="text" value="Search..." name="s" id="s" onfocus="if (this.value == 'Search...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search me';}" /></form>


<?php /* If this is the frontpage */ if ( is_home()  ) { ?>
<h3>Recent</h3>
<ul>
<?php wp_get_archives('type=postbypost&limit=8'); ?>
</ul>
<?php } ?>

<h3>Categories</h3>
<ul>
<?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?>
</ul>

<div class="sos"></div>

<?php /* If this is the frontpage */ if ( is_single() || is_page() ) { ?>
<h3>Latest Comments</h3>

				<?php
		//This grabs recent comments
		global $wpdb;
		$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
			comment_post_ID, comment_author, comment_date_gmt, comment_approved,
			comment_type,comment_author_url,
			SUBSTRING(comment_content,1,30) AS com_excerpt
			FROM $wpdb->comments
			LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
			$wpdb->posts.ID )
			WHERE comment_approved = '1' AND comment_type = '' AND
			post_password = ''
			ORDER BY comment_date_gmt DESC
			LIMIT 4";
		$comments = $wpdb->get_results($sql);
		$output = $pre_HTML;
		$output .= "\n<ul>";
		foreach ($comments as $comment) {
			$output .= "\n<li>".strip_tags($comment->comment_author)
			.": " . "<a href=\"" . get_permalink($comment->ID) .
			"#comment-" . $comment->comment_ID . "\" title=\"on " . 
			$comment->post_title . "\"> &quot;" . strip_tags($comment->com_excerpt)
			."...&quot;</a></li>";
		}
		$output .= "\n</ul>";
		$output .= $post_HTML;
		echo $output;
		?>

<h3>Archives</h3>
<ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>

<div class="sos"></div>

<?php } ?>
<?php endif; ?>
</div>