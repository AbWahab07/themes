<?php
/*
Template Name: Single Page Template
*/
?>
<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="x-left post">
<h1><?php the_title(); ?></h1>
</div>

<div class="narrowcolumn">

<div class="post" id="post-<?php the_ID(); ?>">

<div class="entry">
<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
</div>

<p class="postmetadata"><?php edit_post_link('Edit this page', '', ''); ?></p>

</div>
</div>
<?php endwhile; endif; ?>
<?php get_template_part('bar'); ?>
<?php get_footer(); ?>